--
-- PostgreSQL database dump
--

\restrict YPRpNgUqCDmiRvDcuC5twFSOhBddap89hacxEJA28jGMvkDkiAayp6gUBVhkuzK

-- Dumped from database version 17.12
-- Dumped by pg_dump version 17.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: barcode_cache; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.barcode_cache (
    barcode text NOT NULL,
    source text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.barcode_cache OWNER TO drinkwatch;

--
-- Name: barcodes; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.barcodes (
    barcode text NOT NULL,
    product_id integer NOT NULL,
    source text DEFAULT 'scrape'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.barcodes OWNER TO drinkwatch;

--
-- Name: caffeine_entries; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.caffeine_entries (
    id bigint NOT NULL,
    device_id integer NOT NULL,
    product_id integer,
    label text,
    qty integer DEFAULT 1 NOT NULL,
    mg_caffeine integer NOT NULL,
    consumed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT caffeine_entries_mg_caffeine_check CHECK (((mg_caffeine >= 0) AND (mg_caffeine <= 5000))),
    CONSTRAINT caffeine_entries_qty_check CHECK (((qty > 0) AND (qty <= 24)))
);


ALTER TABLE public.caffeine_entries OWNER TO drinkwatch;

--
-- Name: caffeine_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.caffeine_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.caffeine_entries_id_seq OWNER TO drinkwatch;

--
-- Name: caffeine_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.caffeine_entries_id_seq OWNED BY public.caffeine_entries.id;


--
-- Name: chains; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.chains (
    id integer NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(80) NOT NULL,
    kind character varying(24) NOT NULL,
    scrape_enabled boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chains OWNER TO drinkwatch;

--
-- Name: chains_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.chains_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chains_id_seq OWNER TO drinkwatch;

--
-- Name: chains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.chains_id_seq OWNED BY public.chains.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    display_name character varying(60),
    platform character varying(20),
    app_version character varying(20),
    reputation integer NOT NULL,
    is_banned boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone
);


ALTER TABLE public.devices OWNER TO drinkwatch;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.devices_id_seq OWNER TO drinkwatch;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: listings; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.listings (
    id integer NOT NULL,
    product_id integer,
    chain_id integer NOT NULL,
    external_sku character varying(120) NOT NULL,
    url character varying(500),
    title_raw character varying(300),
    size_text character varying(60),
    pack_count integer NOT NULL,
    barcode character varying(32),
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.listings OWNER TO drinkwatch;

--
-- Name: listings_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.listings_id_seq OWNER TO drinkwatch;

--
-- Name: listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.listings_id_seq OWNED BY public.listings.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    device_id integer NOT NULL,
    kind text DEFAULT 'alert'::text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO drinkwatch;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO drinkwatch;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: observation_votes; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.observation_votes (
    observation_id bigint NOT NULL,
    device_id integer NOT NULL,
    vote smallint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.observation_votes OWNER TO drinkwatch;

--
-- Name: observations; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.observations (
    id bigint NOT NULL,
    store_id integer,
    product_id integer NOT NULL,
    listing_id integer,
    price_cents integer NOT NULL,
    was_price_cents integer,
    unit_price_cents_per_l integer,
    promo_kind character varying(16) NOT NULL,
    promo_qty integer,
    promo_total_cents integer,
    in_stock boolean,
    source character varying(10) NOT NULL,
    price_scope character varying(10) NOT NULL,
    device_id integer,
    note character varying(300),
    photo_url character varying(500),
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(16) NOT NULL,
    dedupe_key character varying(160),
    chain_id integer NOT NULL,
    photo_id bigint,
    ocr_text text,
    CONSTRAINT ck_obs_price_positive CHECK ((price_cents > 0))
);


ALTER TABLE public.observations OWNER TO drinkwatch;

--
-- Name: observations_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.observations_id_seq OWNER TO drinkwatch;

--
-- Name: observations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.observations_id_seq OWNED BY public.observations.id;


--
-- Name: photos; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.photos (
    id bigint NOT NULL,
    token text NOT NULL,
    filename text NOT NULL,
    content_type text DEFAULT 'image/jpeg'::text NOT NULL,
    bytes integer DEFAULT 0 NOT NULL,
    sha256 text NOT NULL,
    width integer,
    height integer,
    uploaded_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.photos OWNER TO drinkwatch;

--
-- Name: photos_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.photos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.photos_id_seq OWNER TO drinkwatch;

--
-- Name: photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.photos_id_seq OWNED BY public.photos.id;


--
-- Name: price_alerts; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.price_alerts (
    id integer NOT NULL,
    device_id integer NOT NULL,
    product_id integer,
    family_slug text,
    chain_code text,
    store_id integer,
    max_price_cents integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_notified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_alert_target CHECK (((product_id IS NOT NULL) OR (family_slug IS NOT NULL))),
    CONSTRAINT price_alerts_max_price_cents_check CHECK ((max_price_cents > 0))
);


ALTER TABLE public.price_alerts OWNER TO drinkwatch;

--
-- Name: price_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.price_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.price_alerts_id_seq OWNER TO drinkwatch;

--
-- Name: price_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.price_alerts_id_seq OWNED BY public.price_alerts.id;


--
-- Name: price_daily; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.price_daily (
    day date NOT NULL,
    chain_id integer NOT NULL,
    product_id integer NOT NULL,
    price_cents integer NOT NULL,
    was_price_cents integer,
    promo_kind text DEFAULT 'none'::text NOT NULL,
    source text DEFAULT 'scrape'::text NOT NULL
);


ALTER TABLE public.price_daily OWNER TO drinkwatch;

--
-- Name: products; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.products (
    id integer NOT NULL,
    slug character varying(160) NOT NULL,
    brand character varying(60) NOT NULL,
    name character varying(160) NOT NULL,
    variant character varying(80),
    size_ml integer,
    pack_count integer NOT NULL,
    barcode character varying(32),
    category character varying(40) NOT NULL,
    source character varying(16) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    canonical_product_id integer,
    family_slug text,
    caffeine_mg_per_100ml numeric(5,2) DEFAULT 32 NOT NULL,
    status text DEFAULT 'verified'::text NOT NULL,
    image_url text,
    normalised_barcode text
);


ALTER TABLE public.products OWNER TO drinkwatch;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO drinkwatch;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.reports (
    id bigint NOT NULL,
    observation_id bigint,
    device_id integer,
    reason character varying(40) NOT NULL,
    note text,
    resolved boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reports OWNER TO drinkwatch;

--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reports_id_seq OWNER TO drinkwatch;

--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.schema_migrations (
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO drinkwatch;

--
-- Name: scrape_runs; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.scrape_runs (
    id bigint NOT NULL,
    chain_code character varying(32) NOT NULL,
    store_id integer,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    status character varying(16) NOT NULL,
    items_seen integer NOT NULL,
    observations_written integer NOT NULL,
    products_created integer NOT NULL,
    error text
);


ALTER TABLE public.scrape_runs OWNER TO drinkwatch;

--
-- Name: scrape_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.scrape_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scrape_runs_id_seq OWNER TO drinkwatch;

--
-- Name: scrape_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.scrape_runs_id_seq OWNED BY public.scrape_runs.id;


--
-- Name: stores; Type: TABLE; Schema: public; Owner: drinkwatch
--

CREATE TABLE public.stores (
    id integer NOT NULL,
    chain_id integer NOT NULL,
    name character varying(160) NOT NULL,
    suburb character varying(80),
    state character varying(8),
    postcode character varying(8),
    lat double precision,
    lon double precision,
    website character varying(300),
    external_ref character varying(120),
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stores OWNER TO drinkwatch;

--
-- Name: stores_id_seq; Type: SEQUENCE; Schema: public; Owner: drinkwatch
--

CREATE SEQUENCE public.stores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stores_id_seq OWNER TO drinkwatch;

--
-- Name: stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drinkwatch
--

ALTER SEQUENCE public.stores_id_seq OWNED BY public.stores.id;


--
-- Name: caffeine_entries id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.caffeine_entries ALTER COLUMN id SET DEFAULT nextval('public.caffeine_entries_id_seq'::regclass);


--
-- Name: chains id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.chains ALTER COLUMN id SET DEFAULT nextval('public.chains_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: listings id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.listings ALTER COLUMN id SET DEFAULT nextval('public.listings_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: observations id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations ALTER COLUMN id SET DEFAULT nextval('public.observations_id_seq'::regclass);


--
-- Name: photos id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.photos ALTER COLUMN id SET DEFAULT nextval('public.photos_id_seq'::regclass);


--
-- Name: price_alerts id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_alerts ALTER COLUMN id SET DEFAULT nextval('public.price_alerts_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: scrape_runs id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.scrape_runs ALTER COLUMN id SET DEFAULT nextval('public.scrape_runs_id_seq'::regclass);


--
-- Name: stores id; Type: DEFAULT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.stores ALTER COLUMN id SET DEFAULT nextval('public.stores_id_seq'::regclass);


--
-- Data for Name: barcode_cache; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.barcode_cache (barcode, source, payload, created_at) FROM stdin;
9342866002025	openfoodfacts	{"found": false, "source": "openfoodfacts"}	2026-11-18 06:58:34.98901+00
9312345678907	openfoodfacts	{"name": "BANANA YOGHURT", "brand": "Danone", "found": true, "source": "openfoodfacts", "quantity": "500 g", "image_url": "https://images.openfoodfacts.org/images/products/931/234/567/8907/front_en.125.400.jpg", "caffeine_mg_per_100ml": null}	2026-11-18 06:58:36.108358+00
9342866004964	openfoodfacts	{"found": false, "source": "openfoodfacts"}	2026-11-18 06:59:00.064759+00
9999999999994	openfoodfacts	{"name": "Light & Free SKYR A BOIRE", "brand": "", "found": true, "source": "openfoodfacts", "quantity": "", "image_url": "https://images.openfoodfacts.org/images/products/999/999/999/9994/front_fr.29.400.jpg", "caffeine_mg_per_100ml": null}	2026-11-18 07:00:04.658092+00
0425835084865	openfoodfacts	{"found": false, "source": "openfoodfacts"}	2026-11-18 07:03:24.180833+00
90435324	openfoodfacts	{"name": "Energy Drink", "brand": "Red Bull", "found": true, "source": "openfoodfacts", "quantity": "250ml", "image_url": "https://images.openfoodfacts.org/images/products/000/009/043/5324/front_en.37.400.jpg", "caffeine_mg_per_100ml": null}	2026-11-18 07:26:44.553065+00
0668952360897	openfoodfacts	{"found": false, "source": "openfoodfacts"}	2026-11-18 07:29:17.00399+00
0498346836042	openfoodfacts	{"found": false, "source": "openfoodfacts"}	2026-11-18 07:31:54.482867+00
9342866000635	openfoodfacts	{"name": "Mango Loco", "brand": "Monster", "found": true, "source": "openfoodfacts", "quantity": "500ml", "image_url": "https://images.openfoodfacts.org/images/products/934/286/600/0635/front_en.8.400.jpg", "caffeine_mg_per_100ml": 31.0}	2026-11-18 11:25:58.539468+00
9326860000983	openfoodfacts	{"found": false, "source": "openfoodfacts"}	2026-11-18 11:31:34.047416+00
9310246045835	openfoodfacts	{"name": "Community Co Spring Water", "brand": null, "found": true, "source": "openfoodfacts", "quantity": null, "image_url": "https://images.openfoodfacts.org/images/products/931/024/604/5835/front_en.5.400.jpg", "caffeine_mg_per_100ml": null}	2026-11-18 11:31:42.362024+00
9310179009034	openfoodfacts	{"name": "Sunshine Punch Fruit Drink 1L", "brand": "golden circle", "found": true, "source": "openfoodfacts", "quantity": null, "image_url": "https://images.openfoodfacts.org/images/products/931/017/900/9034/front_fr.4.400.jpg", "caffeine_mg_per_100ml": null}	2026-11-18 11:32:05.691961+00
\.


--
-- Data for Name: barcodes; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.barcodes (barcode, product_id, source, created_at) FROM stdin;
19342866000502	272	scrape	2026-11-18 06:59:45.082965+00
9342866000502	272	scrape	2026-11-18 06:59:45.082965+00
19342866000496	273	scrape	2026-11-18 06:59:45.082965+00
9342866000496	273	scrape	2026-11-18 06:59:45.082965+00
19342866003282	274	scrape	2026-11-18 06:59:45.082965+00
9342866003282	274	scrape	2026-11-18 06:59:45.082965+00
9002490298548	278	scrape	2026-11-18 06:59:45.082965+00
09002490298548	278	scrape	2026-11-18 06:59:45.082965+00
9002490292621	282	scrape	2026-11-18 06:59:45.082965+00
09002490292621	282	scrape	2026-11-18 06:59:45.082965+00
9002490305680	283	scrape	2026-11-18 06:59:45.082965+00
09002490305680	283	scrape	2026-11-18 06:59:45.082965+00
9002490297398	285	scrape	2026-11-18 06:59:45.082965+00
09002490297398	285	scrape	2026-11-18 06:59:45.082965+00
9002490202088	286	scrape	2026-11-18 06:59:45.082965+00
09002490202088	286	scrape	2026-11-18 06:59:45.082965+00
9002490297046	287	scrape	2026-11-18 06:59:45.082965+00
09002490297046	287	scrape	2026-11-18 06:59:45.082965+00
9002490285395	288	scrape	2026-11-18 06:59:45.082965+00
09002490285395	288	scrape	2026-11-18 06:59:45.082965+00
19415767624105	299	scrape	2026-11-18 06:59:45.082965+00
9415767624105	299	scrape	2026-11-18 06:59:45.082965+00
19415767014975	300	scrape	2026-11-18 06:59:45.082965+00
9415767014975	300	scrape	2026-11-18 06:59:45.082965+00
19415767015279	301	scrape	2026-11-18 06:59:45.082965+00
9415767015279	301	scrape	2026-11-18 06:59:45.082965+00
9415767116764	302	scrape	2026-11-18 06:59:45.082965+00
09415767116764	302	scrape	2026-11-18 06:59:45.082965+00
19415767677583	303	scrape	2026-11-18 06:59:45.082965+00
9415767677583	303	scrape	2026-11-18 06:59:45.082965+00
19415767018959	304	scrape	2026-11-18 06:59:45.082965+00
9415767018959	304	scrape	2026-11-18 06:59:45.082965+00
19415767676111	305	scrape	2026-11-18 06:59:45.082965+00
9415767676111	305	scrape	2026-11-18 06:59:45.082965+00
9415767116399	306	scrape	2026-11-18 06:59:45.082965+00
09415767116399	306	scrape	2026-11-18 06:59:45.082965+00
9415767119222	307	scrape	2026-11-18 06:59:45.082965+00
09415767119222	307	scrape	2026-11-18 06:59:45.082965+00
9415767011298	308	scrape	2026-11-18 06:59:45.082965+00
09415767011298	308	scrape	2026-11-18 06:59:45.082965+00
9415767913981	309	scrape	2026-11-18 06:59:45.082965+00
09415767913981	309	scrape	2026-11-18 06:59:45.082965+00
19414789968266	310	scrape	2026-11-18 06:59:45.082965+00
9414789968266	310	scrape	2026-11-18 06:59:45.082965+00
19415767015606	314	scrape	2026-11-18 06:59:45.082965+00
9415767015606	314	scrape	2026-11-18 06:59:45.082965+00
19310199080843	315	scrape	2026-11-18 06:59:45.082965+00
9310199080843	315	scrape	2026-11-18 06:59:45.082965+00
19310232958979	316	scrape	2026-11-18 06:59:45.082965+00
9310232958979	316	scrape	2026-11-18 06:59:45.082965+00
19310232957545	317	scrape	2026-11-18 06:59:45.082965+00
9310232957545	317	scrape	2026-11-18 06:59:45.082965+00
19310232961184	318	scrape	2026-11-18 06:59:45.082965+00
9310232961184	318	scrape	2026-11-18 06:59:45.082965+00
19310232959235	319	scrape	2026-11-18 06:59:45.082965+00
9310232959235	319	scrape	2026-11-18 06:59:45.082965+00
19310232962471	320	scrape	2026-11-18 06:59:45.082965+00
9310232962471	320	scrape	2026-11-18 06:59:45.082965+00
19310232957552	321	scrape	2026-11-18 06:59:45.082965+00
9310232957552	321	scrape	2026-11-18 06:59:45.082965+00
20818094004620	311	scrape	2026-11-18 06:59:45.082965+00
67290113763014	312	scrape	2026-11-18 06:59:45.082965+00
9002490289942	289	scrape	2026-11-18 06:59:45.082965+00
09002490289942	289	scrape	2026-11-18 06:59:45.082965+00
19415767014517	291	scrape	2026-11-18 06:59:45.082965+00
9415767014517	291	scrape	2026-11-18 06:59:45.082965+00
19415767013633	292	scrape	2026-11-18 06:59:45.082965+00
9415767013633	292	scrape	2026-11-18 06:59:45.082965+00
19415767015095	293	scrape	2026-11-18 06:59:45.082965+00
9415767015095	293	scrape	2026-11-18 06:59:45.082965+00
9415767011830	294	scrape	2026-11-18 06:59:45.082965+00
09415767011830	294	scrape	2026-11-18 06:59:45.082965+00
19415767013848	295	scrape	2026-11-18 06:59:45.082965+00
9415767013848	295	scrape	2026-11-18 06:59:45.082965+00
19415767677118	297	scrape	2026-11-18 06:59:45.082965+00
9415767677118	297	scrape	2026-11-18 06:59:45.082965+00
9342866000215	40	scrape	2026-11-18 06:59:45.082965+00
09342866000215	40	scrape	2026-11-18 06:59:45.082965+00
9002490206147	54	scrape	2026-11-18 06:59:45.082965+00
09002490206147	54	scrape	2026-11-18 06:59:45.082965+00
9002490239442	53	scrape	2026-11-18 06:59:45.082965+00
09002490239442	53	scrape	2026-11-18 06:59:45.082965+00
9002490200190	51	scrape	2026-11-18 06:59:45.082965+00
09002490200190	51	scrape	2026-11-18 06:59:45.082965+00
9002490275143	29	scrape	2026-11-18 06:59:45.082965+00
09002490275143	29	scrape	2026-11-18 06:59:45.082965+00
9002490200398	42	scrape	2026-11-18 06:59:45.082965+00
09002490200398	42	scrape	2026-11-18 06:59:45.082965+00
9002490100445	52	scrape	2026-11-18 06:59:45.082965+00
09002490100445	52	scrape	2026-11-18 06:59:45.082965+00
9002490100476	30	scrape	2026-11-18 06:59:45.082965+00
09002490100476	30	scrape	2026-11-18 06:59:45.082965+00
1934286603817	15	scrape	2026-11-18 06:59:45.082965+00
01934286603817	15	scrape	2026-11-18 06:59:45.082965+00
9002490212131	1	scrape	2026-11-18 06:59:45.082965+00
09002490212131	1	scrape	2026-11-18 06:59:45.082965+00
9002490223670	7	scrape	2026-11-18 06:59:45.082965+00
09002490223670	7	scrape	2026-11-18 06:59:45.082965+00
9002490264383	55	scrape	2026-11-18 06:59:45.082965+00
09002490264383	55	scrape	2026-11-18 06:59:45.082965+00
9002490200237	33	scrape	2026-11-18 06:59:45.082965+00
09002490200237	33	scrape	2026-11-18 06:59:45.082965+00
9002490242213	56	scrape	2026-11-18 06:59:45.082965+00
09002490242213	56	scrape	2026-11-18 06:59:45.082965+00
9002490245948	32	scrape	2026-11-18 06:59:45.082965+00
09002490245948	32	scrape	2026-11-18 06:59:45.082965+00
9002490230227	34	scrape	2026-11-18 06:59:45.082965+00
09002490230227	34	scrape	2026-11-18 06:59:45.082965+00
9002490289874	66	scrape	2026-11-18 06:59:45.082965+00
09002490289874	66	scrape	2026-11-18 06:59:45.082965+00
9002490279448	8	scrape	2026-11-18 06:59:45.082965+00
09002490279448	8	scrape	2026-11-18 06:59:45.082965+00
9342866003596	21	scrape	2026-11-18 06:59:45.082965+00
09342866003596	21	scrape	2026-11-18 06:59:45.082965+00
09342866000502	272	scrape	2026-11-18 06:59:45.082965+00
9342866003893	12	scrape	2026-11-18 06:59:45.082965+00
09342866003893	12	scrape	2026-11-18 06:59:45.082965+00
9342866003367	4	scrape	2026-11-18 06:59:45.082965+00
09342866003367	4	scrape	2026-11-18 06:59:45.082965+00
9342866002025	14	scrape	2026-11-18 06:59:45.082965+00
09342866002025	14	scrape	2026-11-18 06:59:45.082965+00
9342866001202	39	scrape	2026-11-18 06:59:45.082965+00
09342866001202	39	scrape	2026-11-18 06:59:45.082965+00
09342866000496	273	scrape	2026-11-18 06:59:45.082965+00
9342866003336	38	scrape	2026-11-18 06:59:45.082965+00
09342866003336	38	scrape	2026-11-18 06:59:45.082965+00
9342866003794	48	scrape	2026-11-18 06:59:45.082965+00
09342866003794	48	scrape	2026-11-18 06:59:45.082965+00
9300675039918	37	scrape	2026-11-18 06:59:45.082965+00
09300675039918	37	scrape	2026-11-18 06:59:45.082965+00
9300675057219	45	scrape	2026-11-18 06:59:45.082965+00
09300675057219	45	scrape	2026-11-18 06:59:45.082965+00
9342866003329	49	scrape	2026-11-18 06:59:45.082965+00
09342866003329	49	scrape	2026-11-18 06:59:45.082965+00
9342866003350	67	scrape	2026-11-18 06:59:45.082965+00
09342866003350	67	scrape	2026-11-18 06:59:45.082965+00
9342866002933	20	scrape	2026-11-18 06:59:45.082965+00
09342866002933	20	scrape	2026-11-18 06:59:45.082965+00
9342866003862	19	scrape	2026-11-18 06:59:45.082965+00
09342866003862	19	scrape	2026-11-18 06:59:45.082965+00
9342866001301	3	scrape	2026-11-18 06:59:45.082965+00
09342866001301	3	scrape	2026-11-18 06:59:45.082965+00
9342866003848	44	scrape	2026-11-18 06:59:45.082965+00
09342866003848	44	scrape	2026-11-18 06:59:45.082965+00
9342866003824	47	scrape	2026-11-18 06:59:45.082965+00
09342866003824	47	scrape	2026-11-18 06:59:45.082965+00
9342866003299	5	scrape	2026-11-18 06:59:45.082965+00
09342866003299	5	scrape	2026-11-18 06:59:45.082965+00
9342866003718	22	scrape	2026-11-18 06:59:45.082965+00
09342866003718	22	scrape	2026-11-18 06:59:45.082965+00
9342866003480	61	scrape	2026-11-18 06:59:45.082965+00
09342866003480	61	scrape	2026-11-18 06:59:45.082965+00
9342866003770	18	scrape	2026-11-18 06:59:45.082965+00
09342866003770	18	scrape	2026-11-18 06:59:45.082965+00
9342866003602	11	scrape	2026-11-18 06:59:45.082965+00
09342866003602	11	scrape	2026-11-18 06:59:45.082965+00
9415767915640	57	scrape	2026-11-18 06:59:45.082965+00
09415767915640	57	scrape	2026-11-18 06:59:45.082965+00
9002490223656	41	scrape	2026-11-18 06:59:45.082965+00
09002490223656	41	scrape	2026-11-18 06:59:45.082965+00
09342866003282	274	scrape	2026-11-18 06:59:45.082965+00
9342866003725	43	scrape	2026-11-18 06:59:45.082965+00
09342866003725	43	scrape	2026-11-18 06:59:45.082965+00
9415767624204	60	scrape	2026-11-18 06:59:45.082965+00
09415767624204	60	scrape	2026-11-18 06:59:45.082965+00
09415767014517	291	scrape	2026-11-18 06:59:45.082965+00
9415767676685	59	scrape	2026-11-18 06:59:45.082965+00
09415767676685	59	scrape	2026-11-18 06:59:45.082965+00
9415767624686	57	scrape	2026-11-18 06:59:45.082965+00
09415767624686	57	scrape	2026-11-18 06:59:45.082965+00
09415767013633	292	scrape	2026-11-18 06:59:45.082965+00
9415767677682	58	scrape	2026-11-18 06:59:45.082965+00
09415767677682	58	scrape	2026-11-18 06:59:45.082965+00
09415767015095	293	scrape	2026-11-18 06:59:45.082965+00
09415767013848	295	scrape	2026-11-18 06:59:45.082965+00
09415767677118	297	scrape	2026-11-18 06:59:45.082965+00
09415767624105	299	scrape	2026-11-18 06:59:45.082965+00
09415767014975	300	scrape	2026-11-18 06:59:45.082965+00
09415767015279	301	scrape	2026-11-18 06:59:45.082965+00
09415767677583	303	scrape	2026-11-18 06:59:45.082965+00
09415767015606	314	scrape	2026-11-18 06:59:45.082965+00
09415767018959	304	scrape	2026-11-18 06:59:45.082965+00
09415767676111	305	scrape	2026-11-18 06:59:45.082965+00
9300675038550	25	scrape	2026-11-18 06:59:45.082965+00
09300675038550	25	scrape	2026-11-18 06:59:45.082965+00
1220000062921	62	scrape	2026-11-18 06:59:45.082965+00
01220000062921	62	scrape	2026-11-18 06:59:45.082965+00
1220000060750	68	scrape	2026-11-18 06:59:45.082965+00
01220000060750	68	scrape	2026-11-18 06:59:45.082965+00
1220000063003	50	scrape	2026-11-18 06:59:45.082965+00
01220000063003	50	scrape	2026-11-18 06:59:45.082965+00
1220000060347	37	scrape	2026-11-18 06:59:45.082965+00
01220000060347	37	scrape	2026-11-18 06:59:45.082965+00
1220000063348	27	scrape	2026-11-18 06:59:45.082965+00
01220000063348	27	scrape	2026-11-18 06:59:45.082965+00
1220000063287	28	scrape	2026-11-18 06:59:45.082965+00
01220000063287	28	scrape	2026-11-18 06:59:45.082965+00
1220000060774	46	scrape	2026-11-18 06:59:45.082965+00
01220000060774	46	scrape	2026-11-18 06:59:45.082965+00
09414789968266	310	scrape	2026-11-18 06:59:45.082965+00
09310199080843	315	scrape	2026-11-18 06:59:45.082965+00
09310232958979	316	scrape	2026-11-18 06:59:45.082965+00
09310232957545	317	scrape	2026-11-18 06:59:45.082965+00
9310232961238	315	scrape	2026-11-18 06:59:45.082965+00
09310232961238	315	scrape	2026-11-18 06:59:45.082965+00
09310232961184	318	scrape	2026-11-18 06:59:45.082965+00
09310232959235	319	scrape	2026-11-18 06:59:45.082965+00
9310232957507	319	scrape	2026-11-18 06:59:45.082965+00
09310232957507	319	scrape	2026-11-18 06:59:45.082965+00
9310232962310	317	scrape	2026-11-18 06:59:45.082965+00
09310232962310	317	scrape	2026-11-18 06:59:45.082965+00
9310232957491	318	scrape	2026-11-18 06:59:45.082965+00
09310232957491	318	scrape	2026-11-18 06:59:45.082965+00
9310232960583	315	scrape	2026-11-18 06:59:45.082965+00
09310232960583	315	scrape	2026-11-18 06:59:45.082965+00
09310232962471	320	scrape	2026-11-18 06:59:45.082965+00
9310232957514	320	scrape	2026-11-18 06:59:45.082965+00
09310232957514	320	scrape	2026-11-18 06:59:45.082965+00
9310232959075	318	scrape	2026-11-18 06:59:45.082965+00
09310232959075	318	scrape	2026-11-18 06:59:45.082965+00
09310232957552	321	scrape	2026-11-18 06:59:45.082965+00
9310232961993	319	scrape	2026-11-18 06:59:45.082965+00
09310232961993	319	scrape	2026-11-18 06:59:45.082965+00
9310232962303	317	scrape	2026-11-18 06:59:45.082965+00
09310232962303	317	scrape	2026-11-18 06:59:45.082965+00
09999999999994	299	crowd	2026-11-18 07:00:06.141107+00
9300633099999	325	scrape	2026-11-18 07:01:57.124226+00
09300633099999	325	scrape	2026-11-18 07:01:57.124226+00
90435324	30	crowd	2026-11-18 07:27:13.285041+00
9342866000635	3	crowd	2026-11-18 11:26:46.380023+00
09342866000635	3	crowd	2026-11-18 11:26:46.380023+00
29415767677207	336	scrape	2026-11-18 21:20:00.001424+00
9415767119062	338	scrape	2026-11-18 21:20:04.249755+00
09415767119062	338	scrape	2026-11-18 21:20:04.249755+00
\.


--
-- Data for Name: caffeine_entries; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.caffeine_entries (id, device_id, product_id, label, qty, mg_caffeine, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: chains; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.chains (id, code, name, kind, scrape_enabled, created_at) FROM stdin;
1	woolworths	Woolworths	supermarket	t	2026-11-18 05:53:02.165912+00
2	coles	Coles	supermarket	t	2026-11-18 05:53:02.165912+00
3	spudshed	SpudShed	supermarket	t	2026-11-18 05:53:02.165912+00
4	iga	IGA	supermarket	f	2026-11-18 05:53:02.165912+00
5	7eleven	7-Eleven	convenience	f	2026-11-18 05:53:02.165912+00
6	vibe	Vibe	convenience	f	2026-11-18 05:53:02.165912+00
7	ampol	Ampol	servo	f	2026-11-18 05:53:02.165912+00
8	bp	BP	servo	f	2026-11-18 05:53:02.165912+00
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.devices (id, token_hash, display_name, platform, app_version, reputation, is_banned, created_at, last_seen_at) FROM stdin;
14	161c557f7be85a80333952b6a5b5f9b8a41378b6c96e02797958a3440bbc0592	\N	android	0.1.0	0	f	2026-11-18 07:25:32.290737+00	2026-11-19 02:20:03.959642+00
16	d0792627dc8c0ece277831b8f50cbd99a0e8d54e1e194817eb4e4f11309280ba	\N	android	0.1.0	0	f	2026-11-18 07:26:13.49618+00	2026-11-19 02:26:46.184767+00
4	c363f2b5a26c9d896dc1f836adafd796c4ac2ede3a8d53707038ba066218b616	\N	android	\N	0	f	2026-11-18 06:16:17.186926+00	2026-11-18 06:16:17.186127+00
5	690eaa8e4fc7cab2747d31cb9fe11f4e1b0e8ef5edd37cf0f20dc6ad679b4d96	\N	android	\N	0	f	2026-11-18 06:16:24.94372+00	2026-11-18 06:16:24.941594+00
6	2f884bb29a9fdd91b7c029247606ae9cde1c69b99c7aaae9ea574438f591a61e	\N	android	\N	0	f	2026-11-18 06:16:25.071839+00	2026-11-18 06:16:25.069761+00
13	378e1c917e6178c558087ce849fbc7650954c2d9e713e38c0d31d8a3bbab4f2a	\N	android	0.1.0	0	f	2026-11-18 07:22:54.542221+00	2026-11-18 11:21:08.284294+00
26	93407b8e9adbe6511925f58d3f336a732aba1681dbdf2ae8f96972b94e898e3b	\N	android	0.1.0	0	f	2026-11-18 11:21:58.030158+00	2026-11-18 11:23:36.409825+00
15	6c4b545905294cafde9f55122432372d5678e71a451d9628ec2edb601dd9d8ce	\N	android	0.1.0	0	f	2026-11-18 07:26:13.232331+00	2026-11-18 07:26:13.231672+00
21	8980d700a8636953c2d6ba11a4a59aca43acf75b8af00064543213ad198a6f00	uidtest	android	\N	0	f	2026-11-18 07:31:15.201907+00	2026-11-18 07:31:15.201257+00
27	ac2ece45c1843e8b47635926e3de12e83b5e63f8cc7df5ec3b2758dcb234e137	\N	android	0.4.0	0	f	2026-11-18 11:24:17.28283+00	2026-11-19 02:11:48.847387+00
25	94cbb67b34df11e6d0ea9909e55d55b8947c99579020472f7f0ee2f219c23842	\N	android	0.4.0	0	f	2026-11-18 09:12:18.141348+00	2026-11-18 09:13:04.940902+00
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.listings (id, product_id, chain_id, external_sku, url, title_raw, size_text, pack_count, barcode, last_seen_at, created_at) FROM stdin;
913	40	1	361734	https://www.woolworths.com.au/shop/productdetails/361734	Monster Energy Green Cans 500mL x 4 pack	500mL x 4 pack	4	9342866000215	2026-11-18 21:20:01.979035+00	2026-11-18 06:05:19.909648+00
933	54	1	331784	https://www.woolworths.com.au/shop/productdetails/331784	Red Bull Energy Drink Cans 250mL x 8 pack	250mL x 8 pack	8	9002490206147	2026-11-18 21:20:03.052774+00	2026-11-18 06:05:23.286967+00
13	13	3	6ae3ec4ab911c66b8574f4a6	https://baldivis.spudshed.com.au/lines/monster-energy-ultra-rosa-500ml	Monster Energy Ultra Rosa 500mL	500mL	1	\N	2026-11-19 02:08:57.384134+00	2026-11-18 05:58:46.892636+00
936	29	1	6026788	https://www.woolworths.com.au/shop/productdetails/6026788	Red Bull Energy Drink 330mL	330mL	1	9002490275143	2026-11-18 21:20:07.32098+00	2026-11-18 06:05:23.286967+00
14	14	3	6614cc2bc85674744793c2df	https://baldivis.spudshed.com.au/lines/monster-energy-drink-original-500ml-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:08:57.388579+00	2026-11-18 05:58:46.892636+00
934	53	1	679135	https://www.woolworths.com.au/shop/productdetails/679135	Red Bull Energy Drink 473mL x 4 pack	473mL x 4 pack	4	9002490239442	2026-11-18 21:20:07.327989+00	2026-11-18 06:05:23.286967+00
925	15	1	6057776	https://www.woolworths.com.au/shop/productdetails/6057776	Monster Energy Lando Norris Zero Sugar Can 500mL	500mL	1	1934286603817	2026-11-18 21:20:08.632909+00	2026-11-18 06:05:19.909648+00
940	52	1	162609	https://www.woolworths.com.au/shop/productdetails/162609	Red Bull Energy Drink 250mL x 4 pack	250mL x 4 pack	4	9002490100445	2026-11-18 21:20:08.661344+00	2026-11-18 06:05:23.286967+00
4	4	3	6a73d5380f005ae590462be7	https://baldivis.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:57.342046+00	2026-11-18 05:58:46.892636+00
931	275	1	1142378818	https://www.woolworths.com.au/shop/productdetails/1142378818	Monster White Monster Energy Drink 500ml 500ml		1	\N	2026-11-18 21:20:02.049919+00	2026-11-18 06:05:19.909648+00
6	6	3	6614cc35c85674744793c90f	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-355ml	Red Bull Energy Drink Sugar Free Can 355mL	355mL	1	\N	2026-11-19 02:08:57.354026+00	2026-11-18 05:58:46.892636+00
7	7	3	6614cc08c85674744793ae3f	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:08:57.359281+00	2026-11-18 05:58:46.892636+00
8	8	3	6880419e96806413cb6e557c	https://baldivis.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-250ml	Red Bull Sugar Free Berry Ed 250mL	250mL	1	\N	2026-11-19 02:08:57.363703+00	2026-11-18 05:58:46.892636+00
9	9	3	6a0675c0447673cad56f40cf	https://baldivis.spudshed.com.au/lines/celsius-energy-mango-lemon-330ml	Celsius Energy Mango Lemon 330mL	330mL	1	\N	2026-11-19 02:08:57.367689+00	2026-11-18 05:58:46.892636+00
10	10	3	6a0675c0447673cad56f40db	https://baldivis.spudshed.com.au/lines/celsius-energy-watermelon-lemonade-330ml	Celsius Energy Watermelon Lemonade 330mL	330mL	1	\N	2026-11-19 02:08:57.371253+00	2026-11-18 05:58:46.892636+00
11	11	3	68ad0d9e4f085c0d964e57fa	https://baldivis.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:08:57.375526+00	2026-11-18 05:58:46.892636+00
12	12	3	6ae3ec57b911c66b8574f8de	https://baldivis.spudshed.com.au/lines/monster-bad-apple-500ml	Monster Bad Apple 500mL	500mL	1	\N	2026-11-19 02:08:57.37967+00	2026-11-18 05:58:46.892636+00
935	51	1	223875	https://www.woolworths.com.au/shop/productdetails/223875	Red Bull Energy Drink Cans 250mL x 12 pack	250mL x 12 pack	12	9002490200190	2026-11-18 21:20:03.06186+00	2026-11-18 06:05:23.286967+00
15	15	3	6a5573108a84d3701faae8b1	https://baldivis.spudshed.com.au/lines/monster-lando-norris-zero-sugar-500ml	Monster Lando Norris Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:08:57.392852+00	2026-11-18 05:58:46.892636+00
16	16	3	68341f8dd4ca5f828a7954e1	https://baldivis.spudshed.com.au/lines/monster-papillon-500ml	Monster Papillon 500mL	500mL	1	\N	2026-11-19 02:08:57.396855+00	2026-11-18 05:58:46.892636+00
937	1	1	327603	https://www.woolworths.com.au/shop/productdetails/327603	Red Bull Energy Drink 473mL	473mL	1	9002490212131	2026-11-18 21:20:03.070483+00	2026-11-18 06:05:23.286967+00
17	17	3	6ae3ec1cb911c66b8574e482	https://baldivis.spudshed.com.au/lines/monster-pipeline-punch-500ml	Monster Pipeline Punch 500mL	500mL	1	\N	2026-11-19 02:08:57.400994+00	2026-11-18 05:58:46.892636+00
939	42	1	226913	https://www.woolworths.com.au/shop/productdetails/226913	Red Bull Energy Drink Sugar Free 250mL x 4 pack	250mL x 4 pack	4	9002490200398	2026-11-18 21:20:03.080143+00	2026-11-18 06:05:23.286967+00
18	18	3	6a55731a8a84d3701faaeb88	https://baldivis.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:08:57.404911+00	2026-11-18 05:58:46.892636+00
948	7	1	766988	https://www.woolworths.com.au/shop/productdetails/766988	Red Bull Energy Drink Zero 250mL	250mL	1	9002490223670	2026-11-18 21:20:08.666132+00	2026-11-18 06:05:23.286967+00
2	2	3	6614cc19c85674744793b8cb	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:08:57.327815+00	2026-11-18 05:58:46.892636+00
3	3	3	6614cc1bc85674744793b973	https://baldivis.spudshed.com.au/lines/monster-energy-drink-juice-mango-loco-500ml-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:08:57.335073+00	2026-11-18 05:58:46.892636+00
5	5	3	6733dd91b0c6ab30a702f949	https://baldivis.spudshed.com.au/lines/monster-zero-sugar-500ml	Monster Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:08:57.348492+00	2026-11-18 05:58:46.892636+00
155	70	3	6ae3ec51113412bc9d35e4e8	https://ballajura.spudshed.com.au/lines/red-bull-white-peach-250ml-1	Red Bull White Peach 250mL	250mL	1	\N	2026-11-19 02:09:03.427339+00	2026-11-18 05:58:53.723784+00
406	49	3	6a178daaa8f2a37adc964259	https://waterford.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.758322+00	2026-11-18 05:59:05.642129+00
407	44	3	6a178e3ca8f2a37adc967cf7	https://waterford.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.762131+00	2026-11-18 05:59:05.642129+00
950	282	1	6060519	https://www.woolworths.com.au/shop/productdetails/6060519	Red Bull Energy Drink White Peach Edition 250mL x 4 pack	250mL x 4 pack	4	9002490292621	2026-11-18 21:20:03.089191+00	2026-11-18 06:05:23.286967+00
955	56	1	220969	https://www.woolworths.com.au/shop/productdetails/220969	Red Bull Energy Drink Sugar Free Cans 250mL x 8 pack	250mL x 8 pack	8	9002490242213	2026-11-18 21:20:03.093077+00	2026-11-18 06:05:23.286967+00
947	281	1	1127157773	https://www.woolworths.com.au/shop/productdetails/1127157773	Red Bull Energy Drink Sugar Free Berry Edition Forest Fruits 473mL 12 Pack		12	\N	2026-11-18 21:20:03.12363+00	2026-11-18 06:05:23.286967+00
953	284	1	1130431693	https://www.woolworths.com.au/shop/productdetails/1130431693	Red Bull Energy Drink Sugar Free Lilac Edition Grapefruit & Blossom 473mL 12 Pack		12	\N	2026-11-18 21:20:03.130972+00	2026-11-18 06:05:23.286967+00
949	55	1	944355	https://www.woolworths.com.au/shop/productdetails/944355	Red Bull Energy Drink Sugar Free 473mL x 4 pack	473mL x 4 pack	4	9002490264383	2026-11-18 21:20:03.134742+00	2026-11-18 06:05:23.286967+00
951	33	1	192401	https://www.woolworths.com.au/shop/productdetails/192401	Red Bull Energy Drink Sugar Free 250mL	250mL	1	9002490200237	2026-11-18 21:20:03.139021+00	2026-11-18 06:05:23.286967+00
954	285	1	6087376	https://www.woolworths.com.au/shop/productdetails/6087376	Red Bull Energy Drink Sudachi Lime 250mL	250mL	1	9002490297398	2026-11-18 21:20:03.142653+00	2026-11-18 06:05:23.286967+00
957	287	1	6090912	https://www.woolworths.com.au/shop/productdetails/6090912	Red Bull Energy Drink Cherry Sakura Edition 250mL	250mL	1	9002490297046	2026-11-18 21:20:03.146176+00	2026-11-18 06:05:23.286967+00
956	286	1	953142	https://www.woolworths.com.au/shop/productdetails/953142	Red Bull Energy Drink Sugar Free Cans 250mL x 12 pack	250mL x 12 pack	12	9002490202088	2026-11-18 21:20:03.149933+00	2026-11-18 06:05:23.286967+00
958	288	1	6029814	https://www.woolworths.com.au/shop/productdetails/6029814	Red Bull Sugarfree Energy Drink Berry Edition 250mL x 4 pack	250mL x 4 pack	4	9002490285395	2026-11-18 21:20:03.153572+00	2026-11-18 06:05:23.286967+00
959	289	1	6062443	https://www.woolworths.com.au/shop/productdetails/6062443	Red Bull The Lilac Edition Sugar Free Energy Drink Cans 250mL x 4 pack	250mL x 4 pack	4	9002490289942	2026-11-18 21:20:03.15715+00	2026-11-18 06:05:23.286967+00
960	32	1	82625	https://www.woolworths.com.au/shop/productdetails/82625	Red Bull Red Edition 250mL	250mL	1	9002490245948	2026-11-18 21:20:03.160473+00	2026-11-18 06:05:23.286967+00
961	34	1	459692	https://www.woolworths.com.au/shop/productdetails/459692	Red Bull  Sugar Free Energy Drink Can 473mL	473mL	1	9002490230227	2026-11-18 21:20:03.164105+00	2026-11-18 06:05:23.286967+00
962	66	1	6060312	https://www.woolworths.com.au/shop/productdetails/6060312	Red Bull Lilac Sugar Free Energy Drink Grapefruit & Blossom Can 250mL	250mL	1	9002490289874	2026-11-18 21:20:03.167833+00	2026-11-18 06:05:23.286967+00
964	8	1	6008388	https://www.woolworths.com.au/shop/productdetails/6008388	Red Bull Berry Edition Sugar Free 250mL	250mL	1	9002490279448	2026-11-18 21:20:03.178091+00	2026-11-18 06:05:23.286967+00
928	21	1	6013090	https://www.woolworths.com.au/shop/productdetails/6013090	Monster Ultra Fantasy Ruby Red Energy Drink 500mL	500mL	1	19342866003596	2026-11-18 21:20:03.182047+00	2026-11-18 06:05:19.909648+00
977	298	1	1126125477	https://www.woolworths.com.au/shop/productdetails/1126125477	V Energy Drink Raspberry Lemonade (4 Pack) 250mL 24 Pack		4	\N	2026-11-18 21:20:04.335191+00	2026-11-18 06:05:24.430403+00
912	273	1	489787	https://www.woolworths.com.au/shop/productdetails/489787	Monster Energy Ultra Can 500mL	500mL	1	19342866000496	2026-11-18 21:20:07.313952+00	2026-11-18 06:05:19.909648+00
986	306	1	6087780	https://www.woolworths.com.au/shop/productdetails/6087780	V Energy Refresh Peach & Nectarine Can 250mL	250mL	1	9415767116399	2026-11-18 21:20:04.37281+00	2026-11-18 06:05:24.430403+00
910	14	1	329812	https://www.woolworths.com.au/shop/productdetails/329812	Monster Energy Green Can 500mL	500mL	1	19342866002025	2026-11-18 21:20:07.331389+00	2026-11-18 06:05:19.909648+00
981	302	1	117141	https://www.woolworths.com.au/shop/productdetails/117141	V Energy Green Cans 330mL x 6 pack	330mL x 6 pack	6	9415767116764	2026-11-18 21:20:08.608322+00	2026-11-18 06:05:24.430403+00
908	12	1	6086374	https://www.woolworths.com.au/shop/productdetails/6086374	Monster Energy Bad Apple Can 500mL	500mL	1	19342866003893	2026-11-18 21:20:01.959361+00	2026-11-18 06:05:19.909648+00
914	38	1	690722	https://www.woolworths.com.au/shop/productdetails/690722	Monster Energy Zero Sugar Cans 500mL x 4 pack	500mL x 4 pack	4	19342866003336	2026-11-18 21:20:08.625976+00	2026-11-18 06:05:19.909648+00
907	272	1	511504	https://www.woolworths.com.au/shop/productdetails/511504	Monster Energy Ultra Cans 500mL x 4 pack	500mL x 4 pack	4	19342866000502	2026-11-18 21:20:04.391527+00	2026-11-18 06:05:19.909648+00
909	4	1	6007245	https://www.woolworths.com.au/shop/productdetails/6007245	Monster Energy Ultra Strawberry Dreams 500mL x 4 pack	500mL x 4 pack	4	19342866003367	2026-11-18 21:20:01.9644+00	2026-11-18 06:05:19.909648+00
1034	40	2	2785094	https://www.coles.com.au/product/2785094	Monster Energy Drink Green 4x500ml	2L	4	\N	2026-11-18 21:45:01.98751+00	2026-11-18 21:45:00.003691+00
990	37	1	324461	https://www.woolworths.com.au/shop/productdetails/324461	Mother Energy Drink Original Cans 500mL x 4 pack	500mL x 4 pack	4	9300675039918	2026-11-18 21:20:06.474951+00	2026-11-18 06:05:24.430403+00
996	45	1	793509	https://www.woolworths.com.au/shop/productdetails/793509	Mother Energy Drink Frosty Berry Cans 500mL x 4 pack	500mL x 4 pack	4	9300675057219	2026-11-18 21:20:06.499217+00	2026-11-18 06:05:25.779304+00
988	308	1	908693	https://www.woolworths.com.au/shop/productdetails/908693	V Energy Zero Sugar Drink Blackcurrant & Yuzu 250mL	250mL	1	9415767011298	2026-11-18 21:20:08.651216+00	2026-11-18 06:05:24.430403+00
919	20	1	174492	https://www.woolworths.com.au/shop/productdetails/174492	Monster Energy Drink Ultra Fiesta Mango Flavour 500mL	500mL	1	19342866002933	2026-11-18 21:20:08.657932+00	2026-11-18 06:05:19.909648+00
911	39	1	708119	https://www.woolworths.com.au/shop/productdetails/708119	Monster Energy Juice Mango Loco 500mL x 4 pack	500mL x 4 pack	4	19342866001202	2026-11-18 21:20:01.974191+00	2026-11-18 06:05:19.909648+00
1036	12	2	1869541	https://www.coles.com.au/product/1869541	Monster Energy Drink Bad Apple	500mL	1	\N	2026-11-18 21:45:01.995599+00	2026-11-18 21:45:00.003691+00
1037	48	2	1869610	https://www.coles.com.au/product/1869610	Monster Energy Drink Rio Punch 4x500ml	4 Pack	4	\N	2026-11-18 21:45:01.999749+00	2026-11-18 21:45:00.003691+00
1038	341	2	3299477	https://www.coles.com.au/product/3299477	Monster Energy Cans Green 6x250ml	1.5L	6	\N	2026-11-18 21:45:02.004473+00	2026-11-18 21:45:00.003691+00
916	48	1	6085847	https://www.woolworths.com.au/shop/productdetails/6085847	Monster Energy Drink Rio Punch Cans 500mL x 4 pack	500mL x 4 pack	4	19342866003794	2026-11-18 21:20:01.993141+00	2026-11-18 06:05:19.909648+00
1027	39	2	3290712	https://www.coles.com.au/product/3290712	Monster Energy Drink Mango 4x500ml	2L	4	\N	2026-11-18 21:45:01.952302+00	2026-11-18 21:45:00.003691+00
917	49	1	919600	https://www.woolworths.com.au/shop/productdetails/919600	Monster Energy Drink Ultra Peachy Keen Cans 500mL x 4 pack	500mL x 4 pack	4	19342866003329	2026-11-18 21:20:01.997332+00	2026-11-18 06:05:19.909648+00
920	19	1	6077152	https://www.woolworths.com.au/shop/productdetails/6077152	Monster Energy Drink Blue Hawaiian Can 500mL	500mL	1	19342866003862	2026-11-18 21:20:02.009377+00	2026-11-18 06:05:19.909648+00
1039	3	2	3290778	https://www.coles.com.au/product/3290778	Monster Energy Mango Loco Can	500mL	1	\N	2026-11-18 21:45:02.008652+00	2026-11-18 21:45:00.003691+00
918	67	1	690694	https://www.woolworths.com.au/shop/productdetails/690694	Monster Energy Ultra Strawberry Dreams Drink 500mL	500mL	1	19342866003350	2026-11-18 21:20:02.016849+00	2026-11-18 06:05:19.909648+00
921	3	1	698612	https://www.woolworths.com.au/shop/productdetails/698612	Monster Energy Mango Loco Can 500mL	500mL	1	19342866001301	2026-11-18 21:20:02.02404+00	2026-11-18 06:05:19.909648+00
973	294	1	909063	https://www.woolworths.com.au/shop/productdetails/909063	V Energy Drink Refresh Blackcurrant & Yuzu 250mL x 4 pack	250mL x 4 pack	4	9415767011830	2026-11-18 21:20:04.316448+00	2026-11-18 06:05:24.430403+00
975	296	1	1107569119	https://www.woolworths.com.au/shop/productdetails/1107569119	V Energy Drink Blue (4 Pack) 250mL 24 Pack	6000ML	1	\N	2026-11-18 21:20:04.32754+00	2026-11-18 06:05:24.430403+00
1044	11	2	1151012	https://www.coles.com.au/product/1151012	Monster Energy Aussie Lemonade Can	500mL	1	\N	2026-11-18 21:45:02.028321+00	2026-11-18 21:45:00.003691+00
1045	14	2	2787136	https://www.coles.com.au/product/2787136	Monster Energy Drink Can Green	500mL	1	\N	2026-11-18 21:45:02.032398+00	2026-11-18 21:45:00.003691+00
1032	273	2	2787147	https://www.coles.com.au/product/2787147	Monster Energy Ultra Can	500mL	1	\N	2026-11-18 21:45:09.733303+00	2026-11-18 21:45:00.003691+00
29	328	3	6a5573138a84d3701faae992	https://baldivis.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:08:57.449022+00	2026-11-18 05:58:46.892636+00
952	283	1	6097557	https://www.woolworths.com.au/shop/productdetails/6097557	Red Bull Energy Drink White Peach Edition Can 473mL x 4 pack	473mL x 4 pack	4	9002490305680	2026-11-18 21:20:06.561542+00	2026-11-18 06:05:23.286967+00
938	41	1	767252	https://www.woolworths.com.au/shop/productdetails/767252	Red Bull Energy Drink Zero 250mL x 4 pack	250mL x 4 pack	4	9002490223656	2026-11-18 21:20:03.074673+00	2026-11-18 06:05:23.286967+00
1003	313	1	1121216389	https://www.woolworths.com.au/shop/productdetails/1121216389	Rockstar Guava Punch 500ml x 12		1	\N	2026-11-18 21:20:07.2601+00	2026-11-18 06:05:26.825095+00
999	309	1	909279	https://www.woolworths.com.au/shop/productdetails/909279	Celsius Sunset Vibe Energy Drink Sparkling Mango Passionfruit 330mL	330mL	1	9415767913981	2026-11-18 21:20:07.303627+00	2026-11-18 06:05:25.779304+00
969	57	1	174412	https://www.woolworths.com.au/shop/productdetails/174412	V Energy Zero Sugar Blue Drink 250mL x 4 pack	250mL x 4 pack	4	9415767915640	2026-11-18 21:20:08.566382+00	2026-11-18 06:05:24.430403+00
1065	58	2	8737163	https://www.coles.com.au/product/8737163	V Energy Drink Original 4x250ml	1L	4	\N	2026-11-18 21:45:05.270607+00	2026-11-18 21:45:05.266594+00
987	307	1	228006	https://www.woolworths.com.au/shop/productdetails/228006	V Energy Refresh Pineapple & Watermelon Zero Sugar Can 250mL	250mL	1	9415767119222	2026-11-18 21:20:08.593063+00	2026-11-18 06:05:24.430403+00
923	5	1	688971	https://www.woolworths.com.au/shop/productdetails/688971	Monster Energy Original Zero Sugar Drink 500mL	500mL	1	19342866003299	2026-11-18 21:20:08.618992+00	2026-11-18 06:05:19.909648+00
915	44	1	6059390	https://www.woolworths.com.au/shop/productdetails/6059390	Monster Energy Ultra Violet Cans 500mL x 4 pack	500mL x 4 pack	4	19342866003848	2026-11-18 21:20:08.654541+00	2026-11-18 06:05:19.909648+00
1001	311	1	332724	https://www.woolworths.com.au/shop/productdetails/332724	Rockstar Guava Punched Energy Drink 500mL	500mL	1	20818094004620	2026-11-18 21:20:07.243504+00	2026-11-18 06:05:26.825095+00
1020	322	1	1119530131	https://www.woolworths.com.au/shop/productdetails/1119530131	Prime Hydration Glowberry Sports Drink 500ml		1	\N	2026-11-18 21:20:11.183718+00	2026-11-18 06:05:30.652681+00
1002	312	1	6032511	https://www.woolworths.com.au/shop/productdetails/6032511	Sodastream Rockstar Energy Drink Soda Mix 440mL	440mL	1	67290113763014	2026-11-18 21:20:07.247868+00	2026-11-18 06:05:26.825095+00
1066	342	2	5486362	https://www.coles.com.au/product/5486362	V Energy Drink Pineapple 4x250ml	1L	4	\N	2026-11-18 21:45:05.292303+00	2026-11-18 21:45:05.266594+00
1047	18	2	1640992	https://www.coles.com.au/product/1640992	Monster Energy Drink Can Rio Punch	500mL	1	\N	2026-11-18 21:45:02.040661+00	2026-11-18 21:45:00.003691+00
922	47	1	6086584	https://www.woolworths.com.au/shop/productdetails/6086584	Monster Energy Drink Lando Norris Cans 500mL x 4 pack	500mL x 4 pack	4	19342866003824	2026-11-18 21:20:02.005628+00	2026-11-18 06:05:19.909648+00
1067	343	2	7305345	https://www.coles.com.au/product/7305345	V Energy Drink 4x500ml	2L	4	\N	2026-11-18 21:45:05.297969+00	2026-11-18 21:45:05.266594+00
924	22	1	6040820	https://www.woolworths.com.au/shop/productdetails/6040820	Monster Ultra Vice Energy Drink 500mL	500mL	1	19342866003718	2026-11-18 21:20:02.031029+00	2026-11-18 06:05:19.909648+00
926	61	1	919631	https://www.woolworths.com.au/shop/productdetails/919631	Monster Energy Drink Ultra Violet Can 500mL	500mL	1	19342866003480	2026-11-18 21:20:02.034558+00	2026-11-18 06:05:19.909648+00
927	18	1	6059029	https://www.woolworths.com.au/shop/productdetails/6059029	Monster Energy Juice Rio Punch Can 500mL	500mL	1	19342866003770	2026-11-18 21:20:02.042471+00	2026-11-18 06:05:19.909648+00
929	11	1	6024547	https://www.woolworths.com.au/shop/productdetails/6024547	Monster Energy Drink Aussie Lemonade 500mL	500mL	1	19342866003602	2026-11-18 21:20:02.057065+00	2026-11-18 06:05:19.909648+00
1068	59	2	5020242	https://www.coles.com.au/product/5020242	V Energy Sugar Free 4x250ml	1L	4	\N	2026-11-18 21:45:05.301925+00	2026-11-18 21:45:05.266594+00
1069	344	2	1415500	https://www.coles.com.au/product/1415500	V Energy Drink Green 10x250ml	2.5L	10	\N	2026-11-18 21:45:05.307032+00	2026-11-18 21:45:05.266594+00
1070	300	2	6325336	https://www.coles.com.au/product/6325336	V Energy Drink Blue 4x500ml	2L	4	\N	2026-11-18 21:45:05.31062+00	2026-11-18 21:45:05.266594+00
1071	57	2	9880526	https://www.coles.com.au/product/9880526	V Energy Blue 4x250ml	1L	4	\N	2026-11-18 21:45:05.314854+00	2026-11-18 21:45:05.266594+00
1072	292	2	1713939	https://www.coles.com.au/product/1713939	V Energy Drink Grape 4x500ml	2L	4	\N	2026-11-18 21:45:05.31864+00	2026-11-18 21:45:05.266594+00
1073	345	2	3734827	https://www.coles.com.au/product/3734827	V Energy Drink Can Raspberry	500mL	1	\N	2026-11-18 21:45:05.323609+00	2026-11-18 21:45:05.266594+00
19	19	3	6a5572fd8a84d3701faae3de	https://baldivis.spudshed.com.au/lines/monster-ultra-blue-hawaiian-500ml	Monster Ultra Blue Hawaiian 500mL	500mL	1	\N	2026-11-19 02:08:57.409747+00	2026-11-18 05:58:46.892636+00
20	20	3	6614cc3fc85674744793ceaf	https://baldivis.spudshed.com.au/lines/monster-ultra-fiesta-mango-500ml	Monster Ultra Fiesta Mango 500mL	500mL	1	\N	2026-11-19 02:08:57.413802+00	2026-11-18 05:58:46.892636+00
980	301	1	6056838	https://www.woolworths.com.au/shop/productdetails/6056838	V Energy Drink Strawberry Crush 500mL	500mL	1	19415767015279	2026-11-18 21:20:04.34269+00	2026-11-18 06:05:24.430403+00
1055	287	2	1990178	https://www.coles.com.au/product/1990178	Red Bull Energy Drink Sugarfree Cherry Sakura	250mL	1	\N	2026-11-18 21:45:03.585692+00	2026-11-18 21:45:03.512711+00
979	300	1	283475	https://www.woolworths.com.au/shop/productdetails/283475	V Energy Blue Drink 500mL x 4 pack	500mL x 4 pack	4	19415767014975	2026-11-18 21:20:08.611856+00	2026-11-18 06:05:24.430403+00
976	297	1	139864	https://www.woolworths.com.au/shop/productdetails/139864	V Energy Drink 250mL	250mL	1	19415767677118	2026-11-18 21:20:08.615476+00	2026-11-18 06:05:24.430403+00
978	299	1	711024	https://www.woolworths.com.au/shop/productdetails/711024	V Energy Drink Blue Can 250mL	250mL	1	19415767624105	2026-11-18 21:20:08.622582+00	2026-11-18 06:05:24.430403+00
968	57	1	729764	https://www.woolworths.com.au/shop/productdetails/729764	V Energy Blue 250mL x 4 pack	250mL x 4 pack	4	19415767624686	2026-11-18 21:20:08.629491+00	2026-11-18 06:05:24.430403+00
930	274	1	391929	https://www.woolworths.com.au/shop/productdetails/391929	Monster Ultra Peachy Keen Energy Drink 500mL	500mL	1	19342866003282	2026-11-18 21:20:02.046171+00	2026-11-18 06:05:19.909648+00
966	291	1	331936	https://www.woolworths.com.au/shop/productdetails/331936	V Energy Drink 500mL x 4 pack	500mL x 4 pack	4	19415767014517	2026-11-18 21:20:08.640496+00	2026-11-18 06:05:24.430403+00
983	314	1	108466	https://www.woolworths.com.au/shop/productdetails/108466	V Energy Drink Blue Zero Sugar Can 250mL	250mL	1	19415767015606	2026-11-18 21:20:08.647677+00	2026-11-18 06:05:24.430403+00
1056	329	2	8654973	https://www.coles.com.au/product/8654973	Red Bull Energy Drink Single Can	250mL	1	\N	2026-11-18 21:45:03.59126+00	2026-11-18 21:45:03.512711+00
971	58	1	132815	https://www.woolworths.com.au/shop/productdetails/132815	V Energy Drink Original Guarana 250mL x 4 pack	250mL x 4 pack	4	19415767677682	2026-11-18 21:20:06.546468+00	2026-11-18 06:05:24.430403+00
1050	333	2	9043363	https://www.coles.com.au/product/9043363	Red Bull Energy Drink Original 4x250ml	1L	4	\N	2026-11-18 21:45:03.521159+00	2026-11-18 21:45:03.512711+00
982	303	1	162536	https://www.woolworths.com.au/shop/productdetails/162536	V Energy With Guarana Bottle 350ml	350mL	1	19415767677583	2026-11-18 21:20:04.354885+00	2026-11-18 06:05:24.430403+00
1051	278	2	1989882	https://www.coles.com.au/product/1989882	Red Bull Energy Drink Sudachi Lime 4x250ml	1L	4	\N	2026-11-18 21:45:03.543916+00	2026-11-18 21:45:03.512711+00
1058	331	2	7255622	https://www.coles.com.au/product/7255622	Red Bull Energy Drink Can	473mL	1	\N	2026-11-18 21:45:03.59985+00	2026-11-18 21:45:03.512711+00
1059	70	2	1337000	https://www.coles.com.au/product/1337000	Red Bull Energy Drink White Peach	250mL	1	\N	2026-11-18 21:45:03.603881+00	2026-11-18 21:45:03.512711+00
932	43	1	6062556	https://www.woolworths.com.au/shop/productdetails/6062556	Monster Energy Juice Aussie Lemonade Style 500mL x 4 pack	500mL x 4 pack	4	19342866003725	2026-11-18 21:20:02.053639+00	2026-11-18 06:05:19.909648+00
1060	33	2	9505006	https://www.coles.com.au/product/9505006	Red Bull Sugar Free Energy Drink Single Can	250mL	1	\N	2026-11-18 21:45:03.608083+00	2026-11-18 21:45:03.512711+00
1061	285	2	1990167	https://www.coles.com.au/product/1990167	Red Bull Energy Drink Sudachi Lime	250mL	1	\N	2026-11-18 21:45:03.612416+00	2026-11-18 21:45:03.512711+00
1062	56	2	3324177	https://www.coles.com.au/product/3324177	Red Bull Energy Drink Sugar Free  8x250ml	2L	8	\N	2026-11-18 21:45:03.616442+00	2026-11-18 21:45:03.512711+00
1063	332	2	4942488	https://www.coles.com.au/product/4942488	Red Bull Energy Drink 12x250ml	3L	12	\N	2026-11-18 21:45:03.62085+00	2026-11-18 21:45:03.512711+00
967	59	1	264490	https://www.woolworths.com.au/shop/productdetails/264490	V Energy Sugar Free 250mL x 4 pack	250mL x 4 pack	4	19415767676685	2026-11-18 21:20:04.277966+00	2026-11-18 06:05:24.430403+00
1064	334	2	3192495	https://www.coles.com.au/product/3192495	Red Bull Energy Drink Original 4x473ml	1.89L	4	\N	2026-11-18 21:45:03.625328+00	2026-11-18 21:45:03.512711+00
1052	42	2	9615900	https://www.coles.com.au/product/9615900	Red Bull Energy Drink Sugar Free 4x250ml	1L	4	\N	2026-11-18 21:45:03.560892+00	2026-11-18 21:45:03.512711+00
970	292	1	6057342	https://www.woolworths.com.au/shop/productdetails/6057342	V Energy Energy Drink Grape Burst Cans 500mL x 4 pack	500mL x 4 pack	4	19415767013633	2026-11-18 21:20:07.317513+00	2026-11-18 06:05:24.430403+00
985	305	1	195827	https://www.woolworths.com.au/shop/productdetails/195827	V Energy Zero Sugar Drink 250mL	250mL	1	19415767676111	2026-11-18 21:20:08.575625+00	2026-11-18 06:05:24.430403+00
972	293	1	6076329	https://www.woolworths.com.au/shop/productdetails/6076329	V Energy Drink Grape Zero Sugar Can 500mL	500mL	1	19415767015095	2026-11-18 21:20:08.597025+00	2026-11-18 06:05:24.430403+00
984	304	1	6094280	https://www.woolworths.com.au/shop/productdetails/6094280	V Energy Zero Sugar Drink 500mL x 4 pack	500mL x 4 pack	4	19415767018959	2026-11-18 21:20:08.60092+00	2026-11-18 06:05:24.430403+00
974	295	1	6007290	https://www.woolworths.com.au/shop/productdetails/6007290	V Energy Grape Burst Drink 500mL	500mL	1	19415767013848	2026-11-18 21:20:04.323764+00	2026-11-18 06:05:24.430403+00
965	60	1	705699	https://www.woolworths.com.au/shop/productdetails/705699	V Energy Blue 500mL	500mL	1	19415767624204	2026-11-18 21:20:08.604645+00	2026-11-18 06:05:23.286967+00
1053	335	2	7306224	https://www.coles.com.au/product/7306224	Red Bull Energy Drink Original Cans 8x250ml	2L	8	\N	2026-11-18 21:45:03.572834+00	2026-11-18 21:45:03.512711+00
1054	282	2	1789894	https://www.coles.com.au/product/1789894	Red Bull White Peach Edition 250ml	4 Pack	4	\N	2026-11-18 21:45:03.579417+00	2026-11-18 21:45:03.512711+00
1086	37	2	6907295	https://www.coles.com.au/product/6907295	Mother Energy Drink Original 4x500ml	2L	4	\N	2026-11-18 21:45:06.398466+00	2026-11-18 21:45:06.394389+00
1088	25	2	6526906	https://www.coles.com.au/product/6526906	Mother Original Energy Drink Can	500mL	1	\N	2026-11-18 21:45:06.438395+00	2026-11-18 21:45:06.394389+00
1089	28	2	1337021	https://www.coles.com.au/product/1337021	Mother Energy Drink White Gummy	500mL	1	\N	2026-11-18 21:45:06.443174+00	2026-11-18 21:45:06.394389+00
1090	352	2	6413160	https://www.coles.com.au/product/6413160	Mother Energy Drink Rainbow Sherbert	500mL	1	\N	2026-11-18 21:45:06.44838+00	2026-11-18 21:45:06.394389+00
165	44	3	6ab5c9a39ebfdb872df38ea3	https://ballajura.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.561016+00	2026-11-18 05:58:53.723784+00
166	46	3	6ab5c9979ebfdb872df38bd2	https://ballajura.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.564757+00	2026-11-18 05:58:53.723784+00
1105	319	2	3568590	https://www.coles.com.au/product/3568590	Dare No Added Sugar Double Espresso Iced Coffee	500mL	1	\N	2026-11-18 21:45:11.110934+00	2026-11-18 21:45:11.065558+00
1106	318	2	7070241	https://www.coles.com.au/product/7070241	Dare Iced Coffee Intense Espresso	500mL	1	\N	2026-11-18 21:45:11.114691+00	2026-11-18 21:45:11.065558+00
1107	315	2	4165228	https://www.coles.com.au/product/4165228	Dare Iced Coffee Mocha	2L	1	\N	2026-11-18 21:45:11.118512+00	2026-11-18 21:45:11.065558+00
1108	319	2	8991361	https://www.coles.com.au/product/8991361	Dare Protein No Sugar Added Iced Coffee Double Espresso	500mL	1	\N	2026-11-18 21:45:11.122099+00	2026-11-18 21:45:11.065558+00
989	25	1	315125	https://www.woolworths.com.au/shop/productdetails/315125	Mother Energy Drink Original Can 500mL	500mL	1	19300675038550	2026-11-18 21:20:08.63646+00	2026-11-18 06:05:24.430403+00
1074	314	2	1713928	https://www.coles.com.au/product/1713928	V Energy Drink Can Blue Zero Sugar	250mL	1	\N	2026-11-18 21:45:05.327631+00	2026-11-18 21:45:05.266594+00
1075	301	2	1713826	https://www.coles.com.au/product/1713826	V Energy Drink Can Strawberry Crush	500mL	1	\N	2026-11-18 21:45:05.3318+00	2026-11-18 21:45:05.266594+00
1076	346	2	1989791	https://www.coles.com.au/product/1989791	V Energy Drink Purple Sour Candy	250mL	1	\N	2026-11-18 21:45:05.336643+00	2026-11-18 21:45:05.266594+00
1077	347	2	1989805	https://www.coles.com.au/product/1989805	V Energy Drink Lemonade Iceblock	250mL	1	\N	2026-11-18 21:45:05.342624+00	2026-11-18 21:45:05.266594+00
1078	297	2	8737185	https://www.coles.com.au/product/8737185	V Energy Original	250mL	1	\N	2026-11-18 21:45:05.346553+00	2026-11-18 21:45:05.266594+00
1079	60	2	1256145	https://www.coles.com.au/product/1256145	V Energy Blue	500mL	1	\N	2026-11-18 21:45:05.350727+00	2026-11-18 21:45:05.266594+00
1080	348	2	9589458	https://www.coles.com.au/product/9589458	V Energy Zero Sugar Original	250mL	1	\N	2026-11-18 21:45:05.355594+00	2026-11-18 21:45:05.266594+00
1081	336	2	6963503	https://www.coles.com.au/product/6963503	V Energy Original	500mL	1	\N	2026-11-18 21:45:05.359652+00	2026-11-18 21:45:05.266594+00
1082	299	2	9850365	https://www.coles.com.au/product/9850365	V Energy Drink Blue	250mL	1	\N	2026-11-18 21:45:05.363558+00	2026-11-18 21:45:05.266594+00
1083	349	2	8913696	https://www.coles.com.au/product/8913696	V Energy Drink Original Glass	350mL	1	\N	2026-11-18 21:45:05.368827+00	2026-11-18 21:45:05.266594+00
1084	350	2	1338330	https://www.coles.com.au/product/1338330	V Energy Drink Strawberries & Cream	250mL	1	\N	2026-11-18 21:45:05.373519+00	2026-11-18 21:45:05.266594+00
1085	295	2	1022938	https://www.coles.com.au/product/1022938	V Enery Drink Grape Burst	500mL	1	\N	2026-11-18 21:45:05.377576+00	2026-11-18 21:45:05.266594+00
1092	353	2	1989612	https://www.coles.com.au/product/1989612	Rockstar Energy Drink 500mL	4 Pack	4	\N	2026-11-18 21:45:07.948508+00	2026-11-18 21:45:07.946303+00
1093	354	2	7388750	https://www.coles.com.au/product/7388750	Rockstar Energy Drink Guava Can	500mL	1	\N	2026-11-18 21:45:07.954362+00	2026-11-18 21:45:07.946303+00
1094	317	2	3034020	https://www.coles.com.au/product/3034020	Dare Iced Coffee Double Espresso	750mL	1	\N	2026-11-18 21:45:11.066612+00	2026-11-18 21:45:11.065558+00
1095	315	2	5206830	https://www.coles.com.au/product/5206830	Dare Iced Coffee Espresso	2L	1	\N	2026-11-18 21:45:11.070976+00	2026-11-18 21:45:11.065558+00
1096	317	2	3034010	https://www.coles.com.au/product/3034010	Dare Iced Coffee Espresso	750mL	1	\N	2026-11-18 21:45:11.07518+00	2026-11-18 21:45:11.065558+00
1097	319	2	3033946	https://www.coles.com.au/product/3033946	Dare Double Espresso Iced Coffee	500mL	1	\N	2026-11-18 21:45:11.078949+00	2026-11-18 21:45:11.065558+00
1098	318	2	3033935	https://www.coles.com.au/product/3033935	Dare Iced Coffee Espresso	500mL	1	\N	2026-11-18 21:45:11.083272+00	2026-11-18 21:45:11.065558+00
1099	315	2	6266816	https://www.coles.com.au/product/6266816	Dare No Sugar Added Iced Coffee Double Espresso	2L	1	\N	2026-11-18 21:45:11.087433+00	2026-11-18 21:45:11.065558+00
1100	317	2	1045875	https://www.coles.com.au/product/1045875	Dare Iced Coffee Intense Espresso	750mL	1	\N	2026-11-18 21:45:11.091262+00	2026-11-18 21:45:11.065558+00
1101	321	2	3034031	https://www.coles.com.au/product/3034031	Dare Iced Coffee Mocha	750mL	1	\N	2026-11-18 21:45:11.09482+00	2026-11-18 21:45:11.065558+00
1102	317	2	3643630	https://www.coles.com.au/product/3643630	Dare No Sugar Added Iced Coffee Double Espresso	750mL	1	\N	2026-11-18 21:45:11.098756+00	2026-11-18 21:45:11.065558+00
1103	315	2	1001141	https://www.coles.com.au/product/1001141	Dare Double Espresso Iced Coffee	2L	1	\N	2026-11-18 21:45:11.102612+00	2026-11-18 21:45:11.065558+00
1104	316	2	5601653	https://www.coles.com.au/product/5601653	Dare Iced Coffee Caramel Latte	750mL	1	\N	2026-11-18 21:45:11.106204+00	2026-11-18 21:45:11.065558+00
1109	319	2	9023752	https://www.coles.com.au/product/9023752	Dare No Sugar Added Iced Coffee Intense Espresso	500mL	1	\N	2026-11-18 21:45:11.125926+00	2026-11-18 21:45:11.065558+00
1110	317	2	1045886	https://www.coles.com.au/product/1045886	Dare Protein No Sugar Added Iced Coffee Double Espresso	750mL	1	\N	2026-11-18 21:45:11.129521+00	2026-11-18 21:45:11.065558+00
1111	355	2	1018067	https://www.coles.com.au/product/1018067	Dare Charged Strong Latte Iced Coffee	240mL	1	\N	2026-11-18 21:45:11.134117+00	2026-11-18 21:45:11.065558+00
181	14	3	6ab5ca14df3614b0b149f026	https://bunbury.spudshed.com.au/lines/monster-green-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:09:06.318629+00	2026-11-18 05:58:56.644305+00
196	68	3	6ab5ca10df3614b0b149ef28	https://bunbury.spudshed.com.au/lines/mother-lava-guava-500ml	Mother Lava Guava 500mL	500mL	1	\N	2026-11-19 02:09:06.378549+00	2026-11-18 05:58:56.644305+00
211	36	3	6ab5c9ffdf3614b0b149eb68	https://bunbury.spudshed.com.au/lines/red-bull-exotic-passionfruit-473ml	Red Bull Exotic Passionfruit 473mL	473mL	1	\N	2026-11-19 02:09:06.438953+00	2026-11-18 05:58:56.644305+00
212	63	3	6ab5c9ffdf3614b0b149eb4c	https://bunbury.spudshed.com.au/lines/red-bull-red-edition-473ml	Red Bull Red Edition 473mL	473mL	1	\N	2026-11-19 02:09:06.442594+00	2026-11-18 05:58:56.644305+00
213	64	3	6ab5ce81df3614b0b14b342e	https://bunbury.spudshed.com.au/lines/red-bull-sugar-free-330ml	Red Bull Sugar Free 330mL	330mL	1	\N	2026-11-19 02:09:06.446361+00	2026-11-18 05:58:56.644305+00
37	37	3	6614cbffc85674744793a95f	https://baldivis.spudshed.com.au/lines/mother-original-4x500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.691164+00	2026-11-18 05:58:46.892636+00
993	50	1	919329	https://www.woolworths.com.au/shop/productdetails/919329	Mother Energy Drink Rainbow Sherbet 500mL x 4 pack	500mL x 4 pack	4	11220000063003	2026-11-18 21:20:06.470718+00	2026-11-18 06:05:25.779304+00
991	62	1	595462	https://www.woolworths.com.au/shop/productdetails/595462	Mother Energy Drink Rainbow Sherbet 500mL	500mL	1	11220000062921	2026-11-18 21:20:06.478759+00	2026-11-18 06:05:25.779304+00
38	38	3	6614cc14c85674744793b55f	https://baldivis.spudshed.com.au/lines/monster-energy-drink-zero-ultra-4-x-500ml-4x500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.702059+00	2026-11-18 05:58:46.892636+00
39	39	3	6614cbf8c85674744793a53f	https://baldivis.spudshed.com.au/lines/monster-energy-drink-mango-loco-4x500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.70905+00	2026-11-18 05:58:46.892636+00
40	40	3	6614cc11c85674744793b41b	https://baldivis.spudshed.com.au/lines/monster-energy-drink-original-4-x-500ml-4x500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.71501+00	2026-11-18 05:58:46.892636+00
41	356	3	6614cc07c85674744793ae03	https://baldivis.spudshed.com.au/lines/mother-original-sugar-free-4x500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.721438+00	2026-11-18 05:58:46.892636+00
272	63	3	6a62ecc9cb87d9bd90b9388b	https://bentleyplaza.spudshed.com.au/lines/red-bull-red-edition-473ml	Red Bull Red Edition 473mL	473mL	1	\N	2026-11-19 02:09:09.652689+00	2026-11-18 05:58:59.721082+00
273	64	3	6a62ea01cb87d9bd90b86765	https://bentleyplaza.spudshed.com.au/lines/red-bull-sugar-free-330ml	Red Bull Sugar Free 330mL	330mL	1	\N	2026-11-19 02:09:09.65626+00	2026-11-18 05:58:59.721082+00
42	41	3	6614cbf2c85674744793a1c3	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-zero-4-x-4x250ml	Red Bull Energy Drink Zero 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:08:58.731029+00	2026-11-18 05:58:46.892636+00
45	44	3	698e719babdbd4c1d0384d24	https://baldivis.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.743228+00	2026-11-18 05:58:46.892636+00
995	27	1	6058332	https://www.woolworths.com.au/shop/productdetails/6058332	Mother Energy Watermelon Can 500mL	500mL	1	11220000063348	2026-11-18 21:20:06.504288+00	2026-11-18 06:05:25.779304+00
994	37	1	733745	https://www.woolworths.com.au/shop/productdetails/733745	Mother Zero Sugar Original Energy Drink 500mL x 4 pack	500mL x 4 pack	4	11220000060347	2026-11-18 21:20:08.58821+00	2026-11-18 06:05:25.779304+00
992	68	1	223752	https://www.woolworths.com.au/shop/productdetails/223752	Mother Energy Drink Lava Guava Can 500mL	500mL	1	11220000060750	2026-11-18 21:20:08.669588+00	2026-11-18 06:05:25.779304+00
1091	27	2	1641168	https://www.coles.com.au/product/1641168	Mother Energy Drink Can Watermelon	500mL	1	\N	2026-11-18 21:45:06.452735+00	2026-11-18 21:45:06.394389+00
1033	19	2	1753263	https://www.coles.com.au/product/1753263	Monster Energy Drink Blue Hawaiian	500mL	1	\N	2026-11-18 21:45:09.728971+00	2026-11-18 21:45:00.003691+00
1024	272	2	2785108	https://www.coles.com.au/product/2785108	Monster Energy Drink Ultra 4x500ml	2L	4	\N	2026-11-18 21:45:09.737341+00	2026-11-18 21:45:00.003691+00
1035	22	2	1308012	https://www.coles.com.au/product/1308012	Monster Energy Drink Ultra Vice	500mL	1	\N	2026-11-18 21:45:09.741357+00	2026-11-18 21:45:00.003691+00
1031	38	2	7717105	https://www.coles.com.au/product/7717105	Monster Energy Drink Zero Sugar 4x500ml	2L	4	\N	2026-11-18 21:45:09.745171+00	2026-11-18 21:45:00.003691+00
1025	339	2	3299488	https://www.coles.com.au/product/3299488	Monster Energy Cans Ultra 6x250ml	1.5L	6	\N	2026-11-18 21:45:09.748875+00	2026-11-18 21:45:00.003691+00
1026	4	2	9961424	https://www.coles.com.au/product/9961424	Monster Energy Strawberry Cans 4x500ml	2L	4	\N	2026-11-18 21:45:09.753883+00	2026-11-18 21:45:00.003691+00
1029	44	2	1641317	https://www.coles.com.au/product/1641317	Monster Energy Drink Ultra Violet 4x500ml	2L	4	\N	2026-11-18 21:45:09.757535+00	2026-11-18 21:45:00.003691+00
1057	41	2	1492443	https://www.coles.com.au/product/1492443	Red Bull Energy Drink Zero Sugar 4x250ml	1L	4	\N	2026-11-18 21:45:09.761376+00	2026-11-18 21:45:03.512711+00
1048	5	2	7717116	https://www.coles.com.au/product/7717116	Monster Energy Drink Zero Sugar Can	500mL	1	\N	2026-11-18 21:45:09.765329+00	2026-11-18 21:45:00.003691+00
1087	351	2	3512825	https://www.coles.com.au/product/3512825	Mother Energy Drink Sugar Free 4x500ml	2L	4	\N	2026-11-18 21:45:09.769274+00	2026-11-18 21:45:06.394389+00
1028	340	2	8592956	https://www.coles.com.au/product/8592956	Monster Energy Drink Peach 4x500ml	2L	4	\N	2026-11-18 21:45:09.773028+00	2026-11-18 21:45:00.003691+00
171	335	3	6ab5ce189ebfdb872df4c3db	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-8-x-250ml	Red Bull Energy Drink 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:04.58457+00	2026-11-18 05:58:53.723784+00
172	42	3	6ab5c9b09ebfdb872df39134	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4-x-250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:04.588643+00	2026-11-18 05:58:53.723784+00
242	14	3	6a62b29aa53458fd616eba10	https://bentleyplaza.spudshed.com.au/lines/monster-green-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:09:09.536482+00	2026-11-18 05:58:59.721082+00
269	2	3	6a62ebc3cb87d9bd90b8efa6	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:09:09.641696+00	2026-11-18 05:58:59.721082+00
270	35	3	6a62ed1ecb87d9bd90b95163	https://bentleyplaza.spudshed.com.au/lines/red-bull-exotic-passionfruit-250ml	Red Bull Exotic Passionfruit 250mL	250mL	1	\N	2026-11-19 02:09:09.64534+00	2026-11-18 05:58:59.721082+00
271	36	3	6a62ed1ecb87d9bd90b9516f	https://bentleyplaza.spudshed.com.au/lines/red-bull-exotic-passionfruit-473ml	Red Bull Exotic Passionfruit 473mL	473mL	1	\N	2026-11-19 02:09:09.649157+00	2026-11-18 05:58:59.721082+00
1010	319	1	249137	https://www.woolworths.com.au/shop/productdetails/249137	Dare Double Espresso Iced Coffee 500mL	500mL	1	19310232957507	2026-11-18 21:20:09.862828+00	2026-11-18 06:05:29.130598+00
1007	315	1	239524	https://www.woolworths.com.au/shop/productdetails/239524	Dare No Added Sugar Double Espresso Iced Coffee 2L	2L	1	19310232961238	2026-11-18 21:20:09.870869+00	2026-11-18 06:05:29.130598+00
1011	317	1	6021271	https://www.woolworths.com.au/shop/productdetails/6021271	Dare Intense Espresso Iced Coffee 750mL	750mL	1	19310232962310	2026-11-18 21:20:09.878031+00	2026-11-18 06:05:29.130598+00
46	45	3	6614cbfbc85674744793a737	https://baldivis.spudshed.com.au/lines/mother-frosty-berry-4x500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.747368+00	2026-11-18 05:58:46.892636+00
47	46	3	67622016d19a1f17327dac30	https://baldivis.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.751211+00	2026-11-18 05:58:46.892636+00
48	47	3	6abf01ddfda3d460708bcda7	https://baldivis.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.754809+00	2026-11-18 05:58:46.892636+00
49	48	3	6abf01ddfda3d460708bcdb9	https://baldivis.spudshed.com.au/lines/monster-rio-punch-4-x-500ml	Monster Rio Punch 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.758607+00	2026-11-18 05:58:46.892636+00
50	49	3	69f7c5990b6cdd58674052b5	https://baldivis.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml-1	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.762254+00	2026-11-18 05:58:46.892636+00
51	50	3	6ae3ec41b911c66b8574f1a0	https://baldivis.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.766123+00	2026-11-18 05:58:46.892636+00
52	332	3	69796b82aadb1e16c78857c9	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-12-x-250ml	Red Bull Energy Drink 12 x 250mL	12 x 250mL	12	\N	2026-11-19 02:08:58.770201+00	2026-11-18 05:58:46.892636+00
998	46	1	223932	https://www.woolworths.com.au/shop/productdetails/223932	Mother Lava Guava Energy Drink Cans 500mL x 4 pack	500mL x 4 pack	4	11220000060774	2026-11-18 21:20:06.491156+00	2026-11-18 06:05:25.779304+00
997	28	1	6042380	https://www.woolworths.com.au/shop/productdetails/6042380	Mother Energy White Gummy Can 500mL	500mL	1	11220000063287	2026-11-18 21:20:06.508142+00	2026-11-18 06:05:25.779304+00
1000	310	1	6095367	https://www.woolworths.com.au/shop/productdetails/6095367	Rockstar Energy Drink Tropical Guava 500mL x 4 pack	500mL x 4 pack	4	19414789968266	2026-11-18 21:20:07.238368+00	2026-11-18 06:05:26.825095+00
1004	315	1	261043	https://www.woolworths.com.au/shop/productdetails/261043	Dare Espresso Iced Coffee 2L	2L	1	19310199080843	2026-11-18 21:20:09.84391+00	2026-11-18 06:05:29.130598+00
1005	316	1	746542	https://www.woolworths.com.au/shop/productdetails/746542	Dare Caramel Latte Iced Coffee 750mL	750mL	1	19310232958979	2026-11-18 21:20:09.847929+00	2026-11-18 06:05:29.130598+00
1009	319	1	11076	https://www.woolworths.com.au/shop/productdetails/11076	Dare No Added Sugar Double Espresso Iced Coffee 500mL	500mL	1	19310232959235	2026-11-18 21:20:09.851836+00	2026-11-18 06:05:29.130598+00
1006	317	1	293933	https://www.woolworths.com.au/shop/productdetails/293933	Dare Double Espresso Iced Coffee 750mL	750mL	1	19310232957545	2026-11-18 21:20:09.855487+00	2026-11-18 06:05:29.130598+00
1008	318	1	239692	https://www.woolworths.com.au/shop/productdetails/239692	Dare Intense Espresso Iced Coffee 500mL	500mL	1	19310232961184	2026-11-18 21:20:09.859293+00	2026-11-18 06:05:29.130598+00
1012	318	1	40284	https://www.woolworths.com.au/shop/productdetails/40284	Dare Espresso Iced Coffee 500mL	500mL	1	19310232957491	2026-11-18 21:20:09.881607+00	2026-11-18 06:05:29.130598+00
1043	61	2	8593020	https://www.coles.com.au/product/8593020	Monster Energy Ultra Violet Can	500mL	1	\N	2026-11-18 21:45:09.77694+00	2026-11-18 21:45:00.003691+00
1046	15	2	1641011	https://www.coles.com.au/product/1641011	Monster Energy Drink Can Lando Norris	500mL	1	\N	2026-11-18 21:45:09.780652+00	2026-11-18 21:45:00.003691+00
53	333	3	69c9ff18885077a1f3af93ce	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-4-x-250ml	Red Bull Energy Drink 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:08:58.774436+00	2026-11-18 05:58:46.892636+00
218	43	3	6ab5c9bfdf3614b0b149dd10	https://bunbury.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.596693+00	2026-11-18 05:58:56.644305+00
1041	67	2	7717127	https://www.coles.com.au/product/7717127	Monster Energy Drink Ultra Strawberry Can	500mL	1	\N	2026-11-18 21:45:09.784847+00	2026-11-18 21:45:00.003691+00
219	40	3	6ab5c9bcdf3614b0b149dc59	https://bunbury.spudshed.com.au/lines/monster-energy-drink-green-4-x-500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.60108+00	2026-11-18 05:58:56.644305+00
223	48	3	6ac439bb676c4c12600a2d8b	https://bunbury.spudshed.com.au/lines/monster-rio-punch-4-x-500ml	Monster Rio Punch 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.61605+00	2026-11-18 05:58:56.644305+00
224	49	3	6ab5c9bedf3614b0b149dce6	https://bunbury.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.619679+00	2026-11-18 05:58:56.644305+00
225	44	3	6ab5c9bfdf3614b0b149dd1e	https://bunbury.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.623305+00	2026-11-18 05:58:56.644305+00
226	45	3	6ab5c9b2df3614b0b149da15	https://bunbury.spudshed.com.au/lines/mother-frosty-berry-4-x-500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.626934+00	2026-11-18 05:58:56.644305+00
227	46	3	6ab5c9b2df3614b0b149da4d	https://bunbury.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.630798+00	2026-11-18 05:58:56.644305+00
1013	315	1	155830	https://www.woolworths.com.au/shop/productdetails/155830	Dare Mocha Iced Coffee 2L	2L	1	19310232960583	2026-11-18 21:20:09.885294+00	2026-11-18 06:05:29.130598+00
1030	47	2	1869665	https://www.coles.com.au/product/1869665	Monster Energy Drink Lando Norris 500mL	4 Pack	4	\N	2026-11-18 21:45:09.788718+00	2026-11-18 21:45:00.003691+00
1049	274	2	6413422	https://www.coles.com.au/product/6413422	Monster Energy Ultra Peachy Keen Can	500mL	1	\N	2026-11-18 21:45:09.792392+00	2026-11-18 21:45:00.003691+00
1040	21	2	9965141	https://www.coles.com.au/product/9965141	Monster Energy Drink Ultra Ruby Red	500mL	1	\N	2026-11-18 21:45:09.795836+00	2026-11-18 21:45:00.003691+00
1042	20	2	4402516	https://www.coles.com.au/product/4402516	Monster Ultra Fiesta Mango Flavour Energy Drink Can	500mL	1	\N	2026-11-18 21:45:09.799566+00	2026-11-18 21:45:00.003691+00
56	55	3	69eaa3765984f7016ff41420	https://baldivis.spudshed.com.au/lines/red-bull-sugar-free-4-x-473ml	Red Bull Sugar Free 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:08:58.786657+00	2026-11-18 05:58:46.892636+00
57	56	3	6a5572f58a84d3701faae1f8	https://baldivis.spudshed.com.au/lines/red-bull-sugar-free-8-x-250ml	Red Bull Sugar Free 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:08:58.791006+00	2026-11-18 05:58:46.892636+00
58	57	3	6614cb78c856747447935e9f	https://baldivis.spudshed.com.au/lines/v-blue-guarana-energy-drink-4-pack-x-250ml	V Energy Drink Blue 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:08:58.794649+00	2026-11-18 05:58:46.892636+00
59	58	3	6614cbb2c856747447937de3	https://baldivis.spudshed.com.au/lines/v-guarana-energy-drink-original-4-pack-x-250ml	V Energy Drink Original 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:08:58.798493+00	2026-11-18 05:58:46.892636+00
60	59	3	6614cb1ec856747447932ba3	https://baldivis.spudshed.com.au/lines/v-guarana-energy-drink-sugarfree-4-pack-x-250ml	V Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:08:58.801965+00	2026-11-18 05:58:46.892636+00
122	11	3	6ab5c9fc9ebfdb872df3a261	https://ballajura.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:09:03.296669+00	2026-11-18 05:58:53.723784+00
123	12	3	6ae3ec30113412bc9d35dafb	https://ballajura.spudshed.com.au/lines/monster-bad-apple-500ml	Monster Bad Apple 500mL	500mL	1	\N	2026-11-19 02:09:03.301135+00	2026-11-18 05:58:53.723784+00
124	14	3	6ab5c9f99ebfdb872df3a1ab	https://ballajura.spudshed.com.au/lines/monster-green-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:09:03.304879+00	2026-11-18 05:58:53.723784+00
125	3	3	6ab5c9f99ebfdb872df3a1c7	https://ballajura.spudshed.com.au/lines/monster-mango-loco-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:09:03.308649+00	2026-11-18 05:58:53.723784+00
126	16	3	6ab5c9fb9ebfdb872df3a245	https://ballajura.spudshed.com.au/lines/monster-papillon-500ml	Monster Papillon 500mL	500mL	1	\N	2026-11-19 02:09:03.312513+00	2026-11-18 05:58:53.723784+00
127	17	3	6ae3ec46113412bc9d35e158	https://ballajura.spudshed.com.au/lines/monster-pipeline-punch-500ml-1	Monster Pipeline Punch 500mL	500mL	1	\N	2026-11-19 02:09:03.316629+00	2026-11-18 05:58:53.723784+00
128	18	3	6ab5c9fd9ebfdb872df3a28b	https://ballajura.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:09:03.320686+00	2026-11-18 05:58:53.723784+00
140	62	3	6ab5c9f49ebfdb872df3a0bb	https://ballajura.spudshed.com.au/lines/mother-rainbow-sherbet-500ml	Mother Rainbow Sherbet 500mL	500mL	1	\N	2026-11-19 02:09:03.367819+00	2026-11-18 05:58:53.723784+00
141	27	3	6ab5c9f59ebfdb872df3a0c9	https://ballajura.spudshed.com.au/lines/mother-watermelon-500ml	Mother Watermelon 500mL	500mL	1	\N	2026-11-19 02:09:03.371782+00	2026-11-18 05:58:53.723784+00
332	2	3	691568a605730aecff3d9ce9	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:09:12.634213+00	2026-11-18 05:59:02.681685+00
21	21	3	6a73d5380f005ae590462bcb	https://baldivis.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:08:57.417822+00	2026-11-18 05:58:46.892636+00
22	22	3	6a5573168a84d3701faaea5b	https://baldivis.spudshed.com.au/lines/monster-ultra-vice-500ml	Monster Ultra Vice 500mL	500mL	1	\N	2026-11-19 02:08:57.421462+00	2026-11-18 05:58:46.892636+00
23	23	3	6ae3ec43b911c66b8574f25c	https://baldivis.spudshed.com.au/lines/mother-drink-frosty-berry-500ml-1	Mother Drink Frosty Berry 500mL	500mL	1	\N	2026-11-19 02:08:57.425198+00	2026-11-18 05:58:46.892636+00
24	24	3	68f1a7938017472a2662e140	https://baldivis.spudshed.com.au/lines/mother-drink-passion-500ml-1	Mother Drink Passion 500mL	500mL	1	\N	2026-11-19 02:08:57.428718+00	2026-11-18 05:58:46.892636+00
25	25	3	6614cc1bc85674744793b97f	https://baldivis.spudshed.com.au/lines/mother-energy-drink-500ml	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:08:57.432519+00	2026-11-18 05:58:46.892636+00
26	26	3	6ae3ec26b911c66b8574e875	https://baldivis.spudshed.com.au/lines/mother-energy-drink-sugar-free-500ml	Mother Energy Drink Sugar Free 500mL	500mL	1	\N	2026-11-19 02:08:57.436401+00	2026-11-18 05:58:46.892636+00
27	27	3	6a5573148a84d3701faae9ce	https://baldivis.spudshed.com.au/lines/mother-watermelon-500ml	Mother Watermelon 500mL	500mL	1	\N	2026-11-19 02:08:57.440892+00	2026-11-18 05:58:46.892636+00
28	28	3	6a5572f08a84d3701faae0a7	https://baldivis.spudshed.com.au/lines/mother-white-gummy-500ml	Mother White Gummy 500mL	500mL	1	\N	2026-11-19 02:08:57.444595+00	2026-11-18 05:58:46.892636+00
30	329	3	6614cc51c85674744793d953	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-250ml-250ml	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:08:57.453096+00	2026-11-18 05:58:46.892636+00
31	330	3	6614cc2ac85674744793c267	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-can-355ml	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:08:57.457079+00	2026-11-18 05:58:46.892636+00
1	331	3	6827e77da784c07cbed02d6a	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-can-473ml-1	Red Bull Energy Drink Can 473mL	473mL	1	\N	2026-11-19 02:08:57.461118+00	2026-11-18 05:58:46.892636+00
32	32	3	6614cc12c85674744793b46f	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-the-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:08:57.464997+00	2026-11-18 05:58:46.892636+00
33	33	3	6614cc35c85674744793c88b	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-250ml-250ml	Red Bull Energy Drink Sugar Free Can 250mL	250mL	1	\N	2026-11-19 02:08:57.468521+00	2026-11-18 05:58:46.892636+00
34	34	3	6614cc3ac85674744793cc0f	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:08:57.472332+00	2026-11-18 05:58:46.892636+00
284	46	3	6a62ec1ccb87d9bd90b90769	https://bentleyplaza.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.734172+00	2026-11-18 05:58:59.721082+00
285	37	3	6a62ea06cb87d9bd90b868f2	https://bentleyplaza.spudshed.com.au/lines/mother-original-4-x-500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.738311+00	2026-11-18 05:58:59.721082+00
286	356	3	6a62ea27cb87d9bd90b872b7	https://bentleyplaza.spudshed.com.au/lines/mother-original-sugar-free-4-x-500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.741875+00	2026-11-18 05:58:59.721082+00
287	50	3	6ae3ec90f88e2b759830c0f1	https://bentleyplaza.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.745857+00	2026-11-18 05:58:59.721082+00
288	332	3	6a62eb23cb87d9bd90b8c065	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-12-x-250ml	Red Bull Energy Drink 12 x 250mL	12 x 250mL	12	\N	2026-11-19 02:09:10.749986+00	2026-11-18 05:58:59.721082+00
289	333	3	6ae3ecf0f88e2b759830d936	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-4-x-250ml-1	Red Bull Energy Drink 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:10.754247+00	2026-11-18 05:58:59.721082+00
290	334	3	6a62ea5dcb87d9bd90b8839d	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-4-x-473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:10.758212+00	2026-11-18 05:58:59.721082+00
291	335	3	6a62b2c7a53458fd616ec7cd	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-8-x-250ml	Red Bull Energy Drink 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:10.762294+00	2026-11-18 05:58:59.721082+00
292	42	3	6a62ea36cb87d9bd90b8772d	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4-x-250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:10.765938+00	2026-11-18 05:58:59.721082+00
293	41	3	6a62ea3dcb87d9bd90b87956	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-zero-4-x-250ml	Red Bull Energy Drink Zero 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:10.769697+00	2026-11-18 05:58:59.721082+00
294	55	3	6a62ec34cb87d9bd90b90e7d	https://bentleyplaza.spudshed.com.au/lines/red-bull-sugar-free-4-x-473ml	Red Bull Sugar Free 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:10.773133+00	2026-11-18 05:58:59.721082+00
295	56	3	6a62eaedcb87d9bd90b8afa7	https://bentleyplaza.spudshed.com.au/lines/red-bull-sugar-free-8-x-250ml	Red Bull Sugar Free 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:10.776754+00	2026-11-18 05:58:59.721082+00
35	35	3	6a5573128a84d3701faae956	https://baldivis.spudshed.com.au/lines/red-bull-exotic-passionfruit-250ml	Red Bull Exotic Passionfruit 250mL	250mL	1	\N	2026-11-19 02:08:57.475861+00	2026-11-18 05:58:46.892636+00
36	36	3	6a20c3b923c0ea396394133d	https://baldivis.spudshed.com.au/lines/red-bull-exotic-passionfruit-473ml	Red Bull Exotic Passionfruit 473mL	473mL	1	\N	2026-11-19 02:08:57.479542+00	2026-11-18 05:58:46.892636+00
43	42	3	6614cbd5c856747447939203	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4-x-4x250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:08:58.735117+00	2026-11-18 05:58:46.892636+00
44	43	3	698e719babdbd4c1d0384d12	https://baldivis.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:08:58.739242+00	2026-11-18 05:58:46.892636+00
54	334	3	6614cc0cc85674744793b10f	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-4-x-4x473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:08:58.778327+00	2026-11-18 05:58:46.892636+00
55	335	3	6a5572fe8a84d3701faae41a	https://baldivis.spudshed.com.au/lines/red-bull-energy-drink-8-x-250ml	Red Bull Energy Drink 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:08:58.783134+00	2026-11-18 05:58:46.892636+00
109	47	3	6abf02104014041e088bd29f	https://kelmscott.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.511037+00	2026-11-18 05:58:50.692497+00
110	49	3	69f7c5acb303a06fdcfe6ca2	https://kelmscott.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml-1	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.514703+00	2026-11-18 05:58:50.692497+00
111	44	3	698e720f39303bb8388269a0	https://kelmscott.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.51874+00	2026-11-18 05:58:50.692497+00
107	356	3	660de44b42594e3e1204108f	https://kelmscott.spudshed.com.au/lines/mother-original-sugar-free-4x500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.52234+00	2026-11-18 05:58:50.692497+00
112	50	3	6ae3eceeec8a62a2d230d7db	https://kelmscott.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.527123+00	2026-11-18 05:58:50.692497+00
113	332	3	69796c0a36c24e7f748395fd	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-12-x-250ml	Red Bull Energy Drink 12 x 250mL	12 x 250mL	12	\N	2026-11-19 02:09:01.531222+00	2026-11-18 05:58:50.692497+00
114	333	3	69c9ff22c1cbe9095b58ea75	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-4-x-250ml	Red Bull Energy Drink 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:01.535265+00	2026-11-18 05:58:50.692497+00
115	334	3	660de49142594e3e1204454f	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-4x473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:01.539576+00	2026-11-18 05:58:50.692497+00
116	335	3	6a55731280ef495b3f53c065	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-8-x-250ml	Red Bull Energy Drink 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:01.543561+00	2026-11-18 05:58:50.692497+00
117	42	3	660de49042594e3e120444d1	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4x250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:01.547522+00	2026-11-18 05:58:50.692497+00
118	41	3	660de43542594e3e120400dd	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-zero-4x250ml	Red Bull Energy Drink Zero 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:01.551183+00	2026-11-18 05:58:50.692497+00
177	9	3	6ab5cf47df3614b0b14b6c52	https://bunbury.spudshed.com.au/lines/celsius-energy-mango-lemon-330ml	Celsius Energy Mango Lemon 330mL	330mL	1	\N	2026-11-19 02:09:06.301708+00	2026-11-18 05:58:56.644305+00
178	10	3	6ab5cf47df3614b0b14b6c60	https://bunbury.spudshed.com.au/lines/celsius-energy-watermelon-lemonade-330ml	Celsius Energy Watermelon Lemonade 330mL	330mL	1	\N	2026-11-19 02:09:06.305964+00	2026-11-18 05:58:56.644305+00
179	11	3	6ab5ca17df3614b0b149f0dc	https://bunbury.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:09:06.310336+00	2026-11-18 05:58:56.644305+00
238	9	3	6a62ed25cb87d9bd90b95398	https://bentleyplaza.spudshed.com.au/lines/celsius-energy-mango-lemon-330ml	Celsius Energy Mango Lemon 330mL	330mL	1	\N	2026-11-19 02:09:09.508574+00	2026-11-18 05:58:59.721082+00
239	10	3	6a62ed26cb87d9bd90b953a4	https://bentleyplaza.spudshed.com.au/lines/celsius-energy-watermelon-lemonade-330ml	Celsius Energy Watermelon Lemonade 330mL	330mL	1	\N	2026-11-19 02:09:09.51864+00	2026-11-18 05:58:59.721082+00
240	11	3	6a62eca4cb87d9bd90b92de7	https://bentleyplaza.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:09:09.525686+00	2026-11-18 05:58:59.721082+00
92	34	3	660de49742594e3e12044a17	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:09:00.419554+00	2026-11-18 05:58:50.692497+00
1014	320	1	6074551	https://www.woolworths.com.au/shop/productdetails/6074551	Dare Protein Mocha Iced Coffee 500mL	500mL	1	19310232962471	2026-11-18 21:20:09.888987+00	2026-11-18 06:05:29.130598+00
61	10	3	6a06759974be2f0e876ca6e8	https://kelmscott.spudshed.com.au/lines/celsius-energy-watermelon-lemonade-330ml	Celsius Energy Watermelon Lemonade 330mL	330mL	1	\N	2026-11-19 02:09:00.284829+00	2026-11-18 05:58:50.692497+00
62	5	3	6733dda6b0c6ab308800b682	https://kelmscott.spudshed.com.au/lines/monster-zero-sugar-500ml	Monster Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:00.289939+00	2026-11-18 05:58:50.692497+00
64	9	3	6a06759974be2f0e876ca6d6	https://kelmscott.spudshed.com.au/lines/celsius-energy-mango-lemon-330ml	Celsius Energy Mango Lemon 330mL	330mL	1	\N	2026-11-19 02:09:00.29977+00	2026-11-18 05:58:50.692497+00
65	11	3	68ad0d7cc6d98fb794826c9f	https://kelmscott.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:09:00.304062+00	2026-11-18 05:58:50.692497+00
84	62	3	68341fcdeb0ae37ce87a1b99	https://kelmscott.spudshed.com.au/lines/mother-rainbow-sherbet-500ml	Mother Rainbow Sherbet 500mL	500mL	1	\N	2026-11-19 02:09:00.38327+00	2026-11-18 05:58:50.692497+00
85	328	3	6a55732d80ef495b3f53c69e	https://kelmscott.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:09:00.387708+00	2026-11-18 05:58:50.692497+00
86	329	3	660de4c842594e3e12046ecf	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-can-250ml	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:09:00.392618+00	2026-11-18 05:58:50.692497+00
87	330	3	660de4b842594e3e120462a1	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-can-355ml	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:09:00.397069+00	2026-11-18 05:58:50.692497+00
88	331	3	6827e695b959de44cb188452	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-can-473ml-1	Red Bull Energy Drink Can 473mL	473mL	1	\N	2026-11-19 02:09:00.402941+00	2026-11-18 05:58:50.692497+00
89	32	3	660de4ae42594e3e12045b51	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:09:00.407162+00	2026-11-18 05:58:50.692497+00
90	33	3	660de43742594e3e120401fd	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-250ml	Red Bull Energy Drink Sugar Free Can 250mL	250mL	1	\N	2026-11-19 02:09:00.411337+00	2026-11-18 05:58:50.692497+00
91	6	3	660de4a242594e3e120451e5	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-355ml	Red Bull Energy Drink Sugar Free Can 355mL	355mL	1	\N	2026-11-19 02:09:00.415328+00	2026-11-18 05:58:50.692497+00
93	7	3	660de44742594e3e12040d9b	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:09:00.423657+00	2026-11-18 05:58:50.692497+00
94	2	3	660de47d42594e3e120435fb	https://kelmscott.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:09:00.427831+00	2026-11-18 05:58:50.692497+00
100	37	3	660de4a742594e3e120455c3	https://kelmscott.spudshed.com.au/lines/mother-original-4x500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.480213+00	2026-11-18 05:58:50.692497+00
241	13	3	6ae3ecc8f88e2b759830d08b	https://bentleyplaza.spudshed.com.au/lines/monster-energy-ultra-rosa-500ml-1	Monster Energy Ultra Rosa 500mL	500mL	1	\N	2026-11-19 02:09:09.531585+00	2026-11-18 05:58:59.721082+00
245	16	3	6a62ec95cb87d9bd90b92967	https://bentleyplaza.spudshed.com.au/lines/monster-papillon-500ml	Monster Papillon 500mL	500mL	1	\N	2026-11-19 02:09:09.548644+00	2026-11-18 05:58:59.721082+00
246	18	3	6a62ecfecb87d9bd90b9486f	https://bentleyplaza.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:09:09.552308+00	2026-11-18 05:58:59.721082+00
247	19	3	6a62ed36cb87d9bd90b95824	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-blue-hawaiian-500ml	Monster Ultra Blue Hawaiian 500mL	500mL	1	\N	2026-11-19 02:09:09.55607+00	2026-11-18 05:58:59.721082+00
248	20	3	6a62eb8ecb87d9bd90b8e02e	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-fiesta-mango-500ml	Monster Ultra Fiesta Mango 500mL	500mL	1	\N	2026-11-19 02:09:09.559798+00	2026-11-18 05:58:59.721082+00
249	21	3	6a790f3d9909401b83dca5c3	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:09:09.563692+00	2026-11-18 05:58:59.721082+00
385	28	3	6a55731ba39b030b86524292	https://waterford.spudshed.com.au/lines/mother-white-gummy-500ml	Mother White Gummy 500mL	500mL	1	\N	2026-11-19 02:09:15.577237+00	2026-11-18 05:59:05.642129+00
101	40	3	660de4ab42594e3e1204586f	https://kelmscott.spudshed.com.au/lines/monster-energy-drink-green-4x500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.484689+00	2026-11-18 05:58:50.692497+00
102	43	3	698e720a39303bb838826881	https://kelmscott.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.489014+00	2026-11-18 05:58:50.692497+00
103	39	3	660de4a342594e3e120452ab	https://kelmscott.spudshed.com.au/lines/monster-energy-drink-mango-loco-4x500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.492863+00	2026-11-18 05:58:50.692497+00
104	38	3	660de49042594e3e1204442f	https://kelmscott.spudshed.com.au/lines/monster-energy-drink-ultra-zero-4x500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.496893+00	2026-11-18 05:58:50.692497+00
105	45	3	660de43f42594e3e1204083f	https://kelmscott.spudshed.com.au/lines/mother-frosty-berry-4x500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.500514+00	2026-11-18 05:58:50.692497+00
106	46	3	67621e91d19a1f17327d7916	https://kelmscott.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:01.504109+00	2026-11-18 05:58:50.692497+00
108	57	3	660de36d42594e3e12036e4f	https://kelmscott.spudshed.com.au/lines/v-energy-drink-blue-4x250ml	V Energy Drink Blue 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:01.50743+00	2026-11-18 05:58:50.692497+00
119	55	3	69eaa3915984f7016ff41954	https://kelmscott.spudshed.com.au/lines/red-bull-sugar-free-4-x-473ml	Red Bull Sugar Free 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:01.554508+00	2026-11-18 05:58:50.692497+00
120	58	3	660de3bf42594e3e1203aa47	https://kelmscott.spudshed.com.au/lines/v-energy-drink-original-4x250ml	V Energy Drink Original 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:01.558157+00	2026-11-18 05:58:50.692497+00
121	59	3	660de36d42594e3e12036e61	https://kelmscott.spudshed.com.au/lines/v-energy-drink-sugar-free-4x250ml	V Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:01.561763+00	2026-11-18 05:58:50.692497+00
180	12	3	6ae3ecf56f4bef734b30fa02	https://bunbury.spudshed.com.au/lines/monster-bad-apple-500ml	Monster Bad Apple 500mL	500mL	1	\N	2026-11-19 02:09:06.314416+00	2026-11-18 05:58:56.644305+00
182	15	3	6ab5ca17df3614b0b149f0f8	https://bunbury.spudshed.com.au/lines/monster-lando-norris-zero-sugar-500ml	Monster Lando Norris Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:06.322615+00	2026-11-18 05:58:56.644305+00
183	3	3	6ab5ca14df3614b0b149f042	https://bunbury.spudshed.com.au/lines/monster-mango-loco-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:09:06.327804+00	2026-11-18 05:58:56.644305+00
184	16	3	6ab5ca16df3614b0b149f0c0	https://bunbury.spudshed.com.au/lines/monster-papillon-500ml	Monster Papillon 500mL	500mL	1	\N	2026-11-19 02:09:06.331874+00	2026-11-18 05:58:56.644305+00
185	17	3	6ae3ecf06f4bef734b30f8de	https://bunbury.spudshed.com.au/lines/monster-pipeline-punch-500ml-1	Monster Pipeline Punch 500mL	500mL	1	\N	2026-11-19 02:09:06.336035+00	2026-11-18 05:58:56.644305+00
186	18	3	6ab5ca18df3614b0b149f106	https://bunbury.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:09:06.340227+00	2026-11-18 05:58:56.644305+00
187	19	3	6ab5cf5adf3614b0b14b711b	https://bunbury.spudshed.com.au/lines/monster-ultra-blue-hawaiian-500ml	Monster Ultra Blue Hawaiian 500mL	500mL	1	\N	2026-11-19 02:09:06.344147+00	2026-11-18 05:58:56.644305+00
188	20	3	6ab5ca15df3614b0b149f07a	https://bunbury.spudshed.com.au/lines/monster-ultra-fiesta-mango-500ml	Monster Ultra Fiesta Mango 500mL	500mL	1	\N	2026-11-19 02:09:06.348198+00	2026-11-18 05:58:56.644305+00
189	21	3	6ab5ca17df3614b0b149f0ce	https://bunbury.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:09:06.352115+00	2026-11-18 05:58:56.644305+00
190	4	3	6ab5c9bedf3614b0b149dd02	https://bunbury.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:06.355893+00	2026-11-18 05:58:56.644305+00
191	22	3	6ab5ca17df3614b0b149f0ea	https://bunbury.spudshed.com.au/lines/monster-ultra-vice-500ml	Monster Ultra Vice 500mL	500mL	1	\N	2026-11-19 02:09:06.359801+00	2026-11-18 05:58:56.644305+00
192	61	3	6ae3ece26f4bef734b30f5d7	https://bunbury.spudshed.com.au/lines/monster-ultra-violet-500ml-1	Monster Ultra Violet 500mL	500mL	1	\N	2026-11-19 02:09:06.363634+00	2026-11-18 05:58:56.644305+00
193	23	3	6ae3ecf06f4bef734b30f900	https://bunbury.spudshed.com.au/lines/mother-drink-frosty-berry-500ml-1	Mother Drink Frosty Berry 500mL	500mL	1	\N	2026-11-19 02:09:06.367648+00	2026-11-18 05:58:56.644305+00
194	25	3	6ae3ecf06f4bef734b30f8f6	https://bunbury.spudshed.com.au/lines/mother-energy-drink-original-500ml-1	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:09:06.371155+00	2026-11-18 05:58:56.644305+00
198	27	3	6ab5ca10df3614b0b149ef44	https://bunbury.spudshed.com.au/lines/mother-watermelon-500ml	Mother Watermelon 500mL	500mL	1	\N	2026-11-19 02:09:06.386348+00	2026-11-18 05:58:56.644305+00
199	28	3	6ab5cf73df3614b0b14b77f3	https://bunbury.spudshed.com.au/lines/mother-white-gummy-500ml	Mother White Gummy 500mL	500mL	1	\N	2026-11-19 02:09:06.390681+00	2026-11-18 05:58:56.644305+00
200	328	3	6ab5ce81df3614b0b14b3420	https://bunbury.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:09:06.394801+00	2026-11-18 05:58:56.644305+00
201	329	3	6ae3eceb6f4bef734b30f7e2	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-can-250ml-1	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:09:06.399192+00	2026-11-18 05:58:56.644305+00
202	330	3	6ae3ecec6f4bef734b30f806	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-can-355ml-1	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:09:06.403163+00	2026-11-18 05:58:56.644305+00
203	331	3	6ab5c9fcdf3614b0b149ea88	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-can-473ml	Red Bull Energy Drink Can 473mL	473mL	1	\N	2026-11-19 02:09:06.407356+00	2026-11-18 05:58:56.644305+00
204	32	3	6ab5ca1fdf3614b0b149f2b9	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:09:06.410963+00	2026-11-18 05:58:56.644305+00
205	33	3	6ab5ca1bdf3614b0b149f1f4	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-250ml	Red Bull Energy Drink Sugar Free Can 250mL	250mL	1	\N	2026-11-19 02:09:06.41501+00	2026-11-18 05:58:56.644305+00
206	6	3	6ab5cc52df3614b0b14a7cc8	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-355ml	Red Bull Energy Drink Sugar Free Can 355mL	355mL	1	\N	2026-11-19 02:09:06.418519+00	2026-11-18 05:58:56.644305+00
305	27	3	6a55731675e52b9e1c527f3f	https://kalgoorlie.spudshed.com.au/lines/mother-watermelon-500ml	Mother Watermelon 500mL	500mL	1	\N	2026-11-19 02:09:12.528511+00	2026-11-18 05:59:02.681685+00
142	28	3	6ab5cf749ebfdb872df52978	https://ballajura.spudshed.com.au/lines/mother-white-gummy-500ml	Mother White Gummy 500mL	500mL	1	\N	2026-11-19 02:09:03.37555+00	2026-11-18 05:58:53.723784+00
143	328	3	6ab5ce7e9ebfdb872df4e5a5	https://ballajura.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:09:03.380201+00	2026-11-18 05:58:53.723784+00
167	37	3	6ab5c9969ebfdb872df38ba8	https://ballajura.spudshed.com.au/lines/mother-original-4-x-500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.568468+00	2026-11-18 05:58:53.723784+00
168	356	3	6ab5c9969ebfdb872df38bb6	https://ballajura.spudshed.com.au/lines/mother-original-sugar-free-4-x-500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.572045+00	2026-11-18 05:58:53.723784+00
169	50	3	6ae3ec79113412bc9d35f06b	https://ballajura.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.575997+00	2026-11-18 05:58:53.723784+00
170	334	3	6ab5cc179ebfdb872df42238	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-4-x-473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:04.580076+00	2026-11-18 05:58:53.723784+00
173	41	3	6ab5c9b09ebfdb872df39142	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-zero-4-x-250ml	Red Bull Energy Drink Zero 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:04.592571+00	2026-11-18 05:58:53.723784+00
174	55	3	6ab5cdd89ebfdb872df4aed1	https://ballajura.spudshed.com.au/lines/red-bull-sugar-free-4-x-473ml	Red Bull Sugar Free 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:04.596301+00	2026-11-18 05:58:53.723784+00
175	56	3	6ab5ce189ebfdb872df4c3e9	https://ballajura.spudshed.com.au/lines/red-bull-sugar-free-8-x-250ml	Red Bull Sugar Free 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:04.600147+00	2026-11-18 05:58:53.723784+00
1016	318	1	808368	https://www.woolworths.com.au/shop/productdetails/808368	Dare Triple Espresso Iced Coffee 500mL	500mL	1	19310232959075	2026-11-18 21:20:09.874512+00	2026-11-18 06:05:29.130598+00
1015	320	1	323328	https://www.woolworths.com.au/shop/productdetails/323328	Dare Mocha Iced Coffee 500mL	500mL	1	19310232957514	2026-11-18 21:20:09.892357+00	2026-11-18 06:05:29.130598+00
275	43	3	6a62ecfecb87d9bd90b9487b	https://bentleyplaza.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.696809+00	2026-11-18 05:58:59.721082+00
276	40	3	6a62ea02cb87d9bd90b867b9	https://bentleyplaza.spudshed.com.au/lines/monster-energy-drink-green-4-x-500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.701137+00	2026-11-18 05:58:59.721082+00
277	39	3	6a62ea55cb87d9bd90b880fd	https://bentleyplaza.spudshed.com.au/lines/monster-energy-drink-mango-loco-4-x-500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.705377+00	2026-11-18 05:58:59.721082+00
278	38	3	6a62ea02cb87d9bd90b867c5	https://bentleyplaza.spudshed.com.au/lines/monster-energy-drink-ultra-zero-4-x-500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.709495+00	2026-11-18 05:58:59.721082+00
361	21	3	6a73d550167a0d3a4f46feec	https://waterford.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:09:15.476193+00	2026-11-18 05:59:05.642129+00
1017	321	1	876991	https://www.woolworths.com.au/shop/productdetails/876991	Dare Mocha Iced Coffee Flavoured Milk 750mL	750mL	1	19310232957552	2026-11-18 21:20:09.895919+00	2026-11-18 06:05:29.130598+00
362	61	3	6ae3ecd8153100a46674ebbe	https://waterford.spudshed.com.au/lines/monster-ultra-violet-500ml-1	Monster Ultra Violet 500mL	500mL	1	\N	2026-11-19 02:09:15.486291+00	2026-11-18 05:59:05.642129+00
363	11	3	6a178de8a8f2a37adc965984	https://waterford.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:09:15.49212+00	2026-11-18 05:59:05.642129+00
364	12	3	6ae3ed0b153100a46674f599	https://waterford.spudshed.com.au/lines/monster-bad-apple-500ml	Monster Bad Apple 500mL	500mL	1	\N	2026-11-19 02:09:15.496312+00	2026-11-18 05:59:05.642129+00
365	13	3	6ae3ec95153100a46674da94	https://waterford.spudshed.com.au/lines/monster-energy-ultra-rosa-500ml-1	Monster Energy Ultra Rosa 500mL	500mL	1	\N	2026-11-19 02:09:15.500127+00	2026-11-18 05:59:05.642129+00
366	14	3	6a178b8ea8f2a37adc95717c	https://waterford.spudshed.com.au/lines/monster-green-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:09:15.504127+00	2026-11-18 05:59:05.642129+00
367	15	3	6a557338a39b030b8652495f	https://waterford.spudshed.com.au/lines/monster-lando-norris-zero-sugar-500ml	Monster Lando Norris Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:15.50796+00	2026-11-18 05:59:05.642129+00
368	3	3	6a178bf6a8f2a37adc959ccb	https://waterford.spudshed.com.au/lines/monster-mango-loco-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:09:15.511692+00	2026-11-18 05:59:05.642129+00
369	16	3	6a178dc8a8f2a37adc964e43	https://waterford.spudshed.com.au/lines/monster-papillon-500ml	Monster Papillon 500mL	500mL	1	\N	2026-11-19 02:09:15.51535+00	2026-11-18 05:59:05.642129+00
386	328	3	6a557336a39b030b865248c3	https://waterford.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:09:15.581591+00	2026-11-18 05:59:05.642129+00
387	329	3	6ae3ecf3153100a46674f126	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-can-250ml-1	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:09:15.585834+00	2026-11-18 05:59:05.642129+00
388	330	3	6ae3ecc9153100a46674e836	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-can-355ml-1	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:09:15.590206+00	2026-11-18 05:59:05.642129+00
389	331	3	6a178b7ca8f2a37adc956998	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-can-473ml	Red Bull Energy Drink Can 473mL	473mL	1	\N	2026-11-19 02:09:15.594149+00	2026-11-18 05:59:05.642129+00
944	278	1	6089497	https://www.woolworths.com.au/shop/productdetails/6089497	Red Bull Sudachi Lime Energy Drink 250mL x 4 pack	250mL x 4 pack	4	9002490298548	2026-11-18 21:20:03.101061+00	2026-11-18 06:05:23.286967+00
942	276	1	1127157777	https://www.woolworths.com.au/shop/productdetails/1127157777	Red Bull Energy Drink Red Edition Watermelon Flavour 473mL 12 Pack		12	\N	2026-11-18 21:20:03.105088+00	2026-11-18 06:05:23.286967+00
943	277	1	1127157783	https://www.woolworths.com.au/shop/productdetails/1127157783	Red Bull Energy Drink Summer Edition White Peach 473mL 12 Pack		12	\N	2026-11-18 21:20:03.108833+00	2026-11-18 06:05:23.286967+00
941	30	1	114632	https://www.woolworths.com.au/shop/productdetails/114632	Red Bull Energy Drink 250mL	250mL	1	9002490100476	2026-11-18 21:20:03.112485+00	2026-11-18 06:05:23.286967+00
945	279	1	1129738645	https://www.woolworths.com.au/shop/productdetails/1129738645	Red Bull Energy Drink Sugar Free Cherry Sakura 473mL 12 Pack		12	\N	2026-11-18 21:20:03.116303+00	2026-11-18 06:05:23.286967+00
946	280	1	1129499055	https://www.woolworths.com.au/shop/productdetails/1129499055	Red Bull Energy Drink Summer Edition Sudachi Lime 473mL 12 Pack		12	\N	2026-11-18 21:20:03.120043+00	2026-11-18 06:05:23.286967+00
963	337	1	1125016627	https://www.woolworths.com.au/shop/productdetails/1125016627	Red Bull 250ml Energy Drink 250ml Can (24x Pack)		24	\N	2026-11-18 21:20:03.173713+00	2026-11-18 06:05:23.286967+00
395	2	3	6a178cf6a8f2a37adc95fcb6	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:09:15.615746+00	2026-11-18 05:59:05.642129+00
396	35	3	6a557333a39b030b865247c7	https://waterford.spudshed.com.au/lines/red-bull-exotic-passionfruit-250ml	Red Bull Exotic Passionfruit 250mL	250mL	1	\N	2026-11-19 02:09:15.61941+00	2026-11-18 05:59:05.642129+00
398	64	3	6a55732da39b030b86524677	https://waterford.spudshed.com.au/lines/red-bull-sugar-free-330ml	Red Bull Sugar Free 330mL	330mL	1	\N	2026-11-19 02:09:15.627554+00	2026-11-18 05:59:05.642129+00
63	60	3	660de42942594e3e1203f729	https://kelmscott.spudshed.com.au/lines/v-energy-drink-blue-500ml	V Energy Drink Blue 500mL	500mL	1	\N	2026-11-19 02:09:00.294216+00	2026-11-18 05:58:50.692497+00
66	12	3	6ae3ed05ec8a62a2d230dc72	https://kelmscott.spudshed.com.au/lines/monster-bad-apple-500ml	Monster Bad Apple 500mL	500mL	1	\N	2026-11-19 02:09:00.308341+00	2026-11-18 05:58:50.692497+00
67	13	3	6ae3ecf9ec8a62a2d230d9ef	https://kelmscott.spudshed.com.au/lines/monster-energy-ultra-rosa-500ml-1	Monster Energy Ultra Rosa 500mL	500mL	1	\N	2026-11-19 02:09:00.312349+00	2026-11-18 05:58:50.692497+00
68	14	3	660de48242594e3e12043a21	https://kelmscott.spudshed.com.au/lines/monster-green-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:09:00.317012+00	2026-11-18 05:58:50.692497+00
69	15	3	6a55733080ef495b3f53c788	https://kelmscott.spudshed.com.au/lines/monster-lando-norris-zero-sugar-500ml	Monster Lando Norris Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:00.321209+00	2026-11-18 05:58:50.692497+00
70	3	3	660de48142594e3e1204395b	https://kelmscott.spudshed.com.au/lines/monster-mango-loco-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:09:00.325355+00	2026-11-18 05:58:50.692497+00
71	16	3	68341fdaeb0ae37ce87a1d83	https://kelmscott.spudshed.com.au/lines/monster-papillon-500ml	Monster Papillon 500mL	500mL	1	\N	2026-11-19 02:09:00.329862+00	2026-11-18 05:58:50.692497+00
72	17	3	6ae3ed06ec8a62a2d230dcbb	https://kelmscott.spudshed.com.au/lines/monster-pipeline-punch-500ml-1	Monster Pipeline Punch 500mL	500mL	1	\N	2026-11-19 02:09:00.334031+00	2026-11-18 05:58:50.692497+00
73	18	3	6a55732e80ef495b3f53c6c2	https://kelmscott.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:09:00.337957+00	2026-11-18 05:58:50.692497+00
74	19	3	6a55732880ef495b3f53c54a	https://kelmscott.spudshed.com.au/lines/monster-ultra-blue-hawaiian-500ml	Monster Ultra Blue Hawaiian 500mL	500mL	1	\N	2026-11-19 02:09:00.342113+00	2026-11-18 05:58:50.692497+00
75	20	3	660de40642594e3e1203dd33	https://kelmscott.spudshed.com.au/lines/monster-ultra-fiesta-mango-500ml	Monster Ultra Fiesta Mango 500mL	500mL	1	\N	2026-11-19 02:09:00.346771+00	2026-11-18 05:58:50.692497+00
76	49	3	671876d914c2c37ce2d28bae	https://kelmscott.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:00.350976+00	2026-11-18 05:58:50.692497+00
77	21	3	6a73d4fa496084ff256885db	https://kelmscott.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:09:00.354979+00	2026-11-18 05:58:50.692497+00
95	63	3	6a55732d80ef495b3f53c6aa	https://kelmscott.spudshed.com.au/lines/red-bull-red-edition-473ml	Red Bull Red Edition 473mL	473mL	1	\N	2026-11-19 02:09:00.431795+00	2026-11-18 05:58:50.692497+00
96	64	3	6a55732880ef495b3f53c55c	https://kelmscott.spudshed.com.au/lines/red-bull-sugar-free-330ml	Red Bull Sugar Free 330mL	330mL	1	\N	2026-11-19 02:09:00.435677+00	2026-11-18 05:58:50.692497+00
97	8	3	6880419bab13c2fbd158fd00	https://kelmscott.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-250ml	Red Bull Sugar Free Berry Ed 250mL	250mL	1	\N	2026-11-19 02:09:00.439816+00	2026-11-18 05:58:50.692497+00
98	65	3	6880419cab13c2fbd158fd0f	https://kelmscott.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-473ml	Red Bull Sugar Free Berry Ed 473mL	473mL	1	\N	2026-11-19 02:09:00.444106+00	2026-11-18 05:58:50.692497+00
99	66	3	6a55732480ef495b3f53c474	https://kelmscott.spudshed.com.au/lines/red-bull-sugar-free-lilac-grapefruit-250ml	Red Bull Sugar Free Lilac Grapefruit 250mL	250mL	1	\N	2026-11-19 02:09:00.448396+00	2026-11-18 05:58:50.692497+00
399	43	3	6a178e3ca8f2a37adc967cdf	https://waterford.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.712387+00	2026-11-18 05:59:05.642129+00
400	42	3	6a178be2a8f2a37adc959492	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4-x-250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:16.729509+00	2026-11-18 05:59:05.642129+00
401	40	3	6a178bcfa8f2a37adc958bea	https://waterford.spudshed.com.au/lines/monster-energy-drink-green-4-x-500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.738737+00	2026-11-18 05:59:05.642129+00
402	39	3	6a178bf6a8f2a37adc959cd7	https://waterford.spudshed.com.au/lines/monster-energy-drink-mango-loco-4-x-500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.743188+00	2026-11-18 05:59:05.642129+00
403	38	3	6a178bcfa8f2a37adc958bf7	https://waterford.spudshed.com.au/lines/monster-energy-drink-ultra-zero-4-x-500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.746908+00	2026-11-18 05:59:05.642129+00
144	329	3	6ae3ec8d113412bc9d35f5f8	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-can-250ml-1	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:09:03.384583+00	2026-11-18 05:58:53.723784+00
145	330	3	6ae3ec76113412bc9d35efc9	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-can-355ml-1	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:09:03.388947+00	2026-11-18 05:58:53.723784+00
146	32	3	6ab5ca039ebfdb872df3a43e	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:09:03.393062+00	2026-11-18 05:58:53.723784+00
147	34	3	6ab5c9df9ebfdb872df39c37	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:09:03.397068+00	2026-11-18 05:58:53.723784+00
148	7	3	6ab5ca029ebfdb872df3a3ea	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:09:03.400791+00	2026-11-18 05:58:53.723784+00
149	2	3	6ab5c9e09ebfdb872df39c45	https://ballajura.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:09:03.404497+00	2026-11-18 05:58:53.723784+00
150	63	3	6ab5c9e39ebfdb872df39cd1	https://ballajura.spudshed.com.au/lines/red-bull-red-edition-473ml	Red Bull Red Edition 473mL	473mL	1	\N	2026-11-19 02:09:03.408112+00	2026-11-18 05:58:53.723784+00
151	64	3	6ab5ce7e9ebfdb872df4e5b3	https://ballajura.spudshed.com.au/lines/red-bull-sugar-free-330ml	Red Bull Sugar Free 330mL	330mL	1	\N	2026-11-19 02:09:03.412206+00	2026-11-18 05:58:53.723784+00
152	65	3	6ab5c9e29ebfdb872df39cc3	https://ballajura.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-473ml	Red Bull Sugar Free Berry Ed 473mL	473mL	1	\N	2026-11-19 02:09:03.415877+00	2026-11-18 05:58:53.723784+00
153	66	3	6ab5cf3e9ebfdb872df51b8e	https://ballajura.spudshed.com.au/lines/red-bull-sugar-free-lilac-grapefruit-250ml	Red Bull Sugar Free Lilac Grapefruit 250mL	250mL	1	\N	2026-11-19 02:09:03.419658+00	2026-11-18 05:58:53.723784+00
154	69	3	6ab5c9e49ebfdb872df39cfb	https://ballajura.spudshed.com.au/lines/red-bull-sugar-free-lilac-grapefruit-473ml	Red Bull Sugar Free Lilac Grapefruit 473mL	473mL	1	\N	2026-11-19 02:09:03.423234+00	2026-11-18 05:58:53.723784+00
156	71	3	6ab5c9e39ebfdb872df39cdf	https://ballajura.spudshed.com.au/lines/red-bull-white-peach-473ml	Red Bull White Peach 473mL	473mL	1	\N	2026-11-19 02:09:03.4311+00	2026-11-18 05:58:53.723784+00
157	45	3	6ab5c9969ebfdb872df38b9a	https://ballajura.spudshed.com.au/lines/mother-frosty-berry-4-x-500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.48541+00	2026-11-18 05:58:53.723784+00
158	43	3	6ab5c9a39ebfdb872df38e95	https://ballajura.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.504389+00	2026-11-18 05:58:53.723784+00
159	40	3	6ab5c9a09ebfdb872df38dde	https://ballajura.spudshed.com.au/lines/monster-energy-drink-green-4-x-500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.526224+00	2026-11-18 05:58:53.723784+00
160	39	3	6ab5c9a09ebfdb872df38dfa	https://ballajura.spudshed.com.au/lines/monster-energy-drink-mango-loco-4-x-500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.534999+00	2026-11-18 05:58:53.723784+00
78	4	3	6a73d527496084ff25688c8f	https://kelmscott.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:00.358937+00	2026-11-18 05:58:50.692497+00
79	22	3	6a55732f80ef495b3f53c71c	https://kelmscott.spudshed.com.au/lines/monster-ultra-vice-500ml	Monster Ultra Vice 500mL	500mL	1	\N	2026-11-19 02:09:00.363037+00	2026-11-18 05:58:50.692497+00
161	38	3	6ab5c9a09ebfdb872df38dec	https://ballajura.spudshed.com.au/lines/monster-energy-drink-ultra-zero-4-x-500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.541874+00	2026-11-18 05:58:53.723784+00
162	47	3	6ac2fca1752f45334cd8823d	https://ballajura.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.547474+00	2026-11-18 05:58:53.723784+00
163	48	3	6ac2fca2752f45334cd8824b	https://ballajura.spudshed.com.au/lines/monster-rio-punch-4-x-500ml	Monster Rio Punch 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.552583+00	2026-11-18 05:58:53.723784+00
164	49	3	6ab5c9a29ebfdb872df38e6b	https://ballajura.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:04.556784+00	2026-11-18 05:58:53.723784+00
176	57	3	6ab5cd939ebfdb872df4996b	https://ballajura.spudshed.com.au/lines/v-energy-drink-blue-4-x-250ml	V Energy Drink Blue 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:04.60381+00	2026-11-18 05:58:53.723784+00
250	4	3	6a790f3d9909401b83dca5ac	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:09.567377+00	2026-11-18 05:58:59.721082+00
251	22	3	6a62ecd2cb87d9bd90b93b2b	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-vice-500ml	Monster Ultra Vice 500mL	500mL	1	\N	2026-11-19 02:09:09.571176+00	2026-11-18 05:58:59.721082+00
252	61	3	6ae3ece2f88e2b759830d61e	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-violet-500ml-1	Monster Ultra Violet 500mL	500mL	1	\N	2026-11-19 02:09:09.574933+00	2026-11-18 05:58:59.721082+00
253	5	3	6a62ec64cb87d9bd90b91ccb	https://bentleyplaza.spudshed.com.au/lines/monster-zero-sugar-500ml	Monster Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:09.57892+00	2026-11-18 05:58:59.721082+00
254	323	3	6a62e9fecb87d9bd90b86651	https://bentleyplaza.spudshed.com.au/lines/monster-zero-ultra-500ml	Monster Zero Ultra 500mL	500mL	1	\N	2026-11-19 02:09:09.582806+00	2026-11-18 05:58:59.721082+00
255	23	3	6ae3ecc7f88e2b759830d019	https://bentleyplaza.spudshed.com.au/lines/mother-drink-frosty-berry-500ml-1	Mother Drink Frosty Berry 500mL	500mL	1	\N	2026-11-19 02:09:09.588063+00	2026-11-18 05:58:59.721082+00
256	25	3	6ae3ecd1f88e2b759830d2d0	https://bentleyplaza.spudshed.com.au/lines/mother-energy-drink-original-500ml-1	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:09:09.591679+00	2026-11-18 05:58:59.721082+00
257	68	3	6a62ec1dcb87d9bd90b90775	https://bentleyplaza.spudshed.com.au/lines/mother-lava-guava-500ml	Mother Lava Guava 500mL	500mL	1	\N	2026-11-19 02:09:09.595446+00	2026-11-18 05:58:59.721082+00
279	47	3	6abf01f11f77109f8093d513	https://bentleyplaza.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.715665+00	2026-11-18 05:58:59.721082+00
280	48	3	6abf01f11f77109f8093d51f	https://bentleyplaza.spudshed.com.au/lines/monster-rio-punch-4-x-500ml	Monster Rio Punch 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.719636+00	2026-11-18 05:58:59.721082+00
281	49	3	6a62ec82cb87d9bd90b9241b	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.723402+00	2026-11-18 05:58:59.721082+00
282	44	3	6a62ecffcb87d9bd90b948b7	https://bentleyplaza.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.726898+00	2026-11-18 05:58:59.721082+00
80	61	3	6ae3ed02ec8a62a2d230dbcb	https://kelmscott.spudshed.com.au/lines/monster-ultra-violet-500ml-1	Monster Ultra Violet 500mL	500mL	1	\N	2026-11-19 02:09:00.367324+00	2026-11-18 05:58:50.692497+00
1022	338	1	227590	https://www.woolworths.com.au/shop/productdetails/227590	V Energy Refresh Pineapple & Watermelon Zero Sugar Cans 250mL x 4 pack	250mL x 4 pack	4	9415767119062	2026-11-18 21:20:08.582474+00	2026-11-18 21:20:04.249755+00
1021	336	1	315692	https://www.woolworths.com.au/shop/productdetails/315692	V Energy Drink 500mL	500mL	1	29415767677207	2026-11-18 21:20:08.64431+00	2026-11-18 21:20:00.001424+00
1023	317	1	26888	https://www.woolworths.com.au/shop/productdetails/26888	Dare No Added Sugar Double Espresso Iced Coffee 750mL	750mL	1	19310232959273	2026-11-18 21:20:09.867116+00	2026-11-18 21:20:09.842972+00
1018	319	1	72375	https://www.woolworths.com.au/shop/productdetails/72375	Dare No Added Sugar Intense Espresso Iced Coffee 500mL	500mL	1	19310232961993	2026-11-18 21:20:09.899435+00	2026-11-18 06:05:29.130598+00
1019	317	1	6020777	https://www.woolworths.com.au/shop/productdetails/6020777	Dare Protein Double Espresso Iced Coffee No Sugar Added 750mL	750mL	1	19310232962303	2026-11-18 21:20:09.90296+00	2026-11-18 06:05:29.130598+00
81	23	3	6ae3ece2ec8a62a2d230d51b	https://kelmscott.spudshed.com.au/lines/mother-drink-frosty-berry-500ml-1	Mother Drink Frosty Berry 500mL	500mL	1	\N	2026-11-19 02:09:00.371079+00	2026-11-18 05:58:50.692497+00
274	8	3	6a62eca5cb87d9bd90b92e0b	https://bentleyplaza.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-250ml	Red Bull Sugar Free Berry Ed 250mL	250mL	1	\N	2026-11-19 02:09:09.659757+00	2026-11-18 05:58:59.721082+00
283	45	3	6a62ea05cb87d9bd90b868da	https://bentleyplaza.spudshed.com.au/lines/mother-frosty-berry-4-x-500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:10.730634+00	2026-11-18 05:58:59.721082+00
296	57	3	6a62ebf3cb87d9bd90b8fd90	https://bentleyplaza.spudshed.com.au/lines/v-energy-drink-blue-4-x-250ml	V Energy Drink Blue 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:10.780384+00	2026-11-18 05:58:59.721082+00
297	58	3	6a62ebc8cb87d9bd90b8f126	https://bentleyplaza.spudshed.com.au/lines/v-energy-drink-original-4-x-250ml	V Energy Drink Original 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:10.784466+00	2026-11-18 05:58:59.721082+00
82	25	3	660de47442594e3e12042f29	https://kelmscott.spudshed.com.au/lines/mother-energy-drink-original-500ml	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:09:00.375112+00	2026-11-18 05:58:50.692497+00
83	26	3	6ae3ed07ec8a62a2d230dcef	https://kelmscott.spudshed.com.au/lines/mother-energy-drink-sugar-free-500ml-1	Mother Energy Drink Sugar Free 500mL	500mL	1	\N	2026-11-19 02:09:00.378899+00	2026-11-18 05:58:50.692497+00
129	49	3	6ae3ec21113412bc9d35d668	https://ballajura.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml-1	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:03.324619+00	2026-11-18 05:58:53.723784+00
130	21	3	6ab5c9fc9ebfdb872df3a253	https://ballajura.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:09:03.328396+00	2026-11-18 05:58:53.723784+00
131	4	3	6ab5c9a39ebfdb872df38e87	https://ballajura.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:03.332124+00	2026-11-18 05:58:53.723784+00
132	67	3	6ae3ec2f113412bc9d35dac8	https://ballajura.spudshed.com.au/lines/monster-ultra-strawberry-dreams-500ml-1	Monster Ultra Strawberry Dreams 500mL	500mL	1	\N	2026-11-19 02:09:03.335894+00	2026-11-18 05:58:53.723784+00
221	38	3	6ab5c9bcdf3614b0b149dc67	https://bunbury.spudshed.com.au/lines/monster-energy-drink-ultra-zero-4-x-500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.608385+00	2026-11-18 05:58:56.644305+00
222	47	3	6ac439bb676c4c12600a2d7f	https://bunbury.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.611974+00	2026-11-18 05:58:56.644305+00
228	37	3	6ab5c9b2df3614b0b149da23	https://bunbury.spudshed.com.au/lines/mother-original-4-x-500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.634355+00	2026-11-18 05:58:56.644305+00
229	356	3	6ab5c9b2df3614b0b149da31	https://bunbury.spudshed.com.au/lines/mother-original-sugar-free-4-x-500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.63831+00	2026-11-18 05:58:56.644305+00
230	50	3	6ae3ecd56f4bef734b30f341	https://bunbury.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.642174+00	2026-11-18 05:58:56.644305+00
231	332	3	6ab5c9a3df3614b0b149d6bd	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-12-x-250ml	Red Bull Energy Drink 12 x 250mL	12 x 250mL	12	\N	2026-11-19 02:09:08.647609+00	2026-11-18 05:58:56.644305+00
232	333	3	6ae3ed056f4bef734b30fda7	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-4-x-250ml-1	Red Bull Energy Drink 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:08.651541+00	2026-11-18 05:58:56.644305+00
233	334	3	6ab5cc2bdf3614b0b14a70b3	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-4-x-473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:08.65546+00	2026-11-18 05:58:56.644305+00
234	42	3	6ab5c9cadf3614b0b149dfaf	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4-x-250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:08.658873+00	2026-11-18 05:58:56.644305+00
235	57	3	6ab5cd9ddf3614b0b14ae7e6	https://bunbury.spudshed.com.au/lines/v-energy-drink-blue-4-x-250ml	V Energy Drink Blue 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:08.662742+00	2026-11-18 05:58:56.644305+00
236	58	3	6ab5cd74df3614b0b14adab6	https://bunbury.spudshed.com.au/lines/v-energy-drink-original-4-x-250ml	V Energy Drink Original 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:08.666359+00	2026-11-18 05:58:56.644305+00
300	49	3	691567a205730aecff3d56b4	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:12.497861+00	2026-11-18 05:59:02.681685+00
301	13	3	6ae3ece75eb09f9d9430d464	https://kalgoorlie.spudshed.com.au/lines/monster-energy-ultra-rosa-500ml-1	Monster Energy Ultra Rosa 500mL	500mL	1	\N	2026-11-19 02:09:12.506594+00	2026-11-18 05:59:02.681685+00
333	35	3	6a55731c75e52b9e1c5280e4	https://kalgoorlie.spudshed.com.au/lines/red-bull-exotic-passionfruit-250ml	Red Bull Exotic Passionfruit 250mL	250mL	1	\N	2026-11-19 02:09:12.638113+00	2026-11-18 05:59:02.681685+00
334	36	3	6a20c3c3d69aba5e6d928b5a	https://kalgoorlie.spudshed.com.au/lines/red-bull-exotic-passionfruit-473ml	Red Bull Exotic Passionfruit 473mL	473mL	1	\N	2026-11-19 02:09:12.641721+00	2026-11-18 05:59:02.681685+00
133	61	3	6ae3ec25113412bc9d35d775	https://ballajura.spudshed.com.au/lines/monster-ultra-violet-500ml-1	Monster Ultra Violet 500mL	500mL	1	\N	2026-11-19 02:09:03.340483+00	2026-11-18 05:58:53.723784+00
134	5	3	6ab5c9fb9ebfdb872df3a21b	https://ballajura.spudshed.com.au/lines/monster-zero-sugar-500ml	Monster Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:03.344176+00	2026-11-18 05:58:53.723784+00
135	23	3	6ae3ec78113412bc9d35f035	https://ballajura.spudshed.com.au/lines/mother-drink-frosty-berry-500ml-1	Mother Drink Frosty Berry 500mL	500mL	1	\N	2026-11-19 02:09:03.349032+00	2026-11-18 05:58:53.723784+00
136	24	3	6ab5c9f49ebfdb872df3a09f	https://ballajura.spudshed.com.au/lines/mother-drink-passion-500ml	Mother Drink Passion 500mL	500mL	1	\N	2026-11-19 02:09:03.352627+00	2026-11-18 05:58:53.723784+00
137	25	3	6ae3ec10113412bc9d35d0c2	https://ballajura.spudshed.com.au/lines/mother-energy-drink-original-500ml-1	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:09:03.356445+00	2026-11-18 05:58:53.723784+00
138	26	3	6ae3ec16113412bc9d35d2f2	https://ballajura.spudshed.com.au/lines/mother-energy-drink-sugar-free-500ml-1	Mother Energy Drink Sugar Free 500mL	500mL	1	\N	2026-11-19 02:09:03.360124+00	2026-11-18 05:58:53.723784+00
139	68	3	6ab5c9f49ebfdb872df3a0ad	https://ballajura.spudshed.com.au/lines/mother-lava-guava-500ml	Mother Lava Guava 500mL	500mL	1	\N	2026-11-19 02:09:03.364018+00	2026-11-18 05:58:53.723784+00
207	34	3	6ab5c9fddf3614b0b149eab2	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:09:06.423628+00	2026-11-18 05:58:56.644305+00
208	7	3	6ab5ca1ddf3614b0b149f265	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:09:06.427247+00	2026-11-18 05:58:56.644305+00
209	2	3	6ab5c9fddf3614b0b149eac0	https://bunbury.spudshed.com.au/lines/red-bull-energy-drink-zero-can-473ml	Red Bull Energy Drink Zero Can 473mL	473mL	1	\N	2026-11-19 02:09:06.431164+00	2026-11-18 05:58:56.644305+00
210	35	3	6ab5ca2ddf3614b0b149f602	https://bunbury.spudshed.com.au/lines/red-bull-exotic-passionfruit-250ml	Red Bull Exotic Passionfruit 250mL	250mL	1	\N	2026-11-19 02:09:06.434838+00	2026-11-18 05:58:56.644305+00
214	8	3	6ab5ca2bdf3614b0b149f569	https://bunbury.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-250ml	Red Bull Sugar Free Berry Ed 250mL	250mL	1	\N	2026-11-19 02:09:06.45009+00	2026-11-18 05:58:56.644305+00
215	65	3	6ab5c9ffdf3614b0b149eb3e	https://bunbury.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-473ml	Red Bull Sugar Free Berry Ed 473mL	473mL	1	\N	2026-11-19 02:09:06.454204+00	2026-11-18 05:58:56.644305+00
216	66	3	6ab5cf3edf3614b0b14b6a09	https://bunbury.spudshed.com.au/lines/red-bull-sugar-free-lilac-grapefruit-250ml	Red Bull Sugar Free Lilac Grapefruit 250mL	250mL	1	\N	2026-11-19 02:09:06.457902+00	2026-11-18 05:58:56.644305+00
217	69	3	6ab5c9ffdf3614b0b149eb76	https://bunbury.spudshed.com.au/lines/red-bull-sugar-free-lilac-grapefruit-473ml	Red Bull Sugar Free Lilac Grapefruit 473mL	473mL	1	\N	2026-11-19 02:09:06.461788+00	2026-11-18 05:58:56.644305+00
220	39	3	6ab5c9bcdf3614b0b149dc75	https://bunbury.spudshed.com.au/lines/monster-energy-drink-mango-loco-4-x-500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:08.604675+00	2026-11-18 05:58:56.644305+00
237	59	3	6ab5cd76df3614b0b14adb5e	https://bunbury.spudshed.com.au/lines/v-energy-drink-sugar-free-4-x-250ml	V Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:08.670236+00	2026-11-18 05:58:56.644305+00
299	4	3	6a73d53e5367586972452ef8	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:12.483754+00	2026-11-18 05:59:02.681685+00
335	63	3	6a55731575e52b9e1c527eeb	https://kalgoorlie.spudshed.com.au/lines/red-bull-red-edition-473ml	Red Bull Red Edition 473mL	473mL	1	\N	2026-11-19 02:09:12.645465+00	2026-11-18 05:59:02.681685+00
195	26	3	6ae3ecf76f4bef734b30fa92	https://bunbury.spudshed.com.au/lines/mother-energy-drink-sugar-free-500ml-1	Mother Energy Drink Sugar Free 500mL	500mL	1	\N	2026-11-19 02:09:06.374866+00	2026-11-18 05:58:56.644305+00
197	62	3	6ab5ca10df3614b0b149ef36	https://bunbury.spudshed.com.au/lines/mother-rainbow-sherbet-500ml	Mother Rainbow Sherbet 500mL	500mL	1	\N	2026-11-19 02:09:06.382547+00	2026-11-18 05:58:56.644305+00
409	46	3	6a178d3ca8f2a37adc961620	https://waterford.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.769683+00	2026-11-18 05:59:05.642129+00
410	37	3	6a178bd1a8f2a37adc958cac	https://waterford.spudshed.com.au/lines/mother-original-4-x-500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.773478+00	2026-11-18 05:59:05.642129+00
411	356	3	6a178bdca8f2a37adc959222	https://waterford.spudshed.com.au/lines/mother-original-sugar-free-4-x-500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.777018+00	2026-11-18 05:59:05.642129+00
258	27	3	6a62ecfecb87d9bd90b94863	https://bentleyplaza.spudshed.com.au/lines/mother-watermelon-500ml	Mother Watermelon 500mL	500mL	1	\N	2026-11-19 02:09:09.599164+00	2026-11-18 05:58:59.721082+00
259	28	3	6a62ed47cb87d9bd90b95d4c	https://bentleyplaza.spudshed.com.au/lines/mother-white-gummy-500ml	Mother White Gummy 500mL	500mL	1	\N	2026-11-19 02:09:09.602858+00	2026-11-18 05:58:59.721082+00
261	329	3	6ae3ece9f88e2b759830d7a4	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-can-250ml-1	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:09:09.610697+00	2026-11-18 05:58:59.721082+00
262	330	3	6ae3eccff88e2b759830d23a	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-can-355ml-1	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:09:09.614632+00	2026-11-18 05:58:59.721082+00
263	331	3	6a62b276a53458fd616eae6c	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-can-473ml	Red Bull Energy Drink Can 473mL	473mL	1	\N	2026-11-19 02:09:09.618622+00	2026-11-18 05:58:59.721082+00
264	32	3	6a62eacfcb87d9bd90b8a66b	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:09:09.622348+00	2026-11-18 05:58:59.721082+00
265	33	3	6a62ea35cb87d9bd90b87715	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-250ml	Red Bull Energy Drink Sugar Free Can 250mL	250mL	1	\N	2026-11-19 02:09:09.626012+00	2026-11-18 05:58:59.721082+00
266	6	3	6a62ea82cb87d9bd90b88e37	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-355ml	Red Bull Energy Drink Sugar Free Can 355mL	355mL	1	\N	2026-11-19 02:09:09.629495+00	2026-11-18 05:58:59.721082+00
267	34	3	6a62ea55cb87d9bd90b88121	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:09:09.633471+00	2026-11-18 05:58:59.721082+00
268	7	3	6a62ea64cb87d9bd90b88559	https://bentleyplaza.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:09:09.637654+00	2026-11-18 05:58:59.721082+00
298	59	3	6a62eb77cb87d9bd90b8d97a	https://bentleyplaza.spudshed.com.au/lines/v-energy-drink-sugar-free-4-x-250ml	V Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:10.788573+00	2026-11-18 05:58:59.721082+00
390	32	3	6a178c47a8f2a37adc95bc5f	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:09:15.59798+00	2026-11-18 05:59:05.642129+00
391	33	3	6a178be2a8f2a37adc959486	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-250ml	Red Bull Energy Drink Sugar Free Can 250mL	250mL	1	\N	2026-11-19 02:09:15.601591+00	2026-11-18 05:59:05.642129+00
392	6	3	6a178c16a8f2a37adc95a992	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-355ml	Red Bull Energy Drink Sugar Free Can 355mL	355mL	1	\N	2026-11-19 02:09:15.605138+00	2026-11-18 05:59:05.642129+00
393	34	3	6a178bf6a8f2a37adc959cfb	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:09:15.608586+00	2026-11-18 05:59:05.642129+00
394	7	3	6a178c00a8f2a37adc95a0e1	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:09:15.612192+00	2026-11-18 05:59:05.642129+00
397	63	3	6a557338a39b030b8652492f	https://waterford.spudshed.com.au/lines/red-bull-red-edition-473ml	Red Bull Red Edition 473mL	473mL	1	\N	2026-11-19 02:09:15.622826+00	2026-11-18 05:59:05.642129+00
404	47	3	6abf0211ed32fb9c548bbd0c	https://waterford.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.75083+00	2026-11-18 05:59:05.642129+00
405	48	3	6abf0211ed32fb9c548bbd18	https://waterford.spudshed.com.au/lines/monster-rio-punch-4-x-500ml	Monster Rio Punch 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.754492+00	2026-11-18 05:59:05.642129+00
408	45	3	6a178bd0a8f2a37adc958ca0	https://waterford.spudshed.com.au/lines/mother-frosty-berry-4-x-500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.76606+00	2026-11-18 05:59:05.642129+00
302	17	3	6ae3ec965eb09f9d9430c01c	https://kalgoorlie.spudshed.com.au/lines/monster-pipeline-punch-500ml-1	Monster Pipeline Punch 500mL	500mL	1	\N	2026-11-19 02:09:12.512831+00	2026-11-18 05:59:02.681685+00
303	21	3	6a73d51c5367586972452a31	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-ruby-red-500ml	Monster Ultra Ruby Red 500mL	500mL	1	\N	2026-11-19 02:09:12.519784+00	2026-11-18 05:59:02.681685+00
304	323	3	691567d405730aecff3d6433	https://kalgoorlie.spudshed.com.au/lines/monster-zero-ultra-500ml	Monster Zero Ultra 500mL	500mL	1	\N	2026-11-19 02:09:12.52444+00	2026-11-18 05:59:02.681685+00
306	11	3	69156c3a05730aecff3e8bac	https://kalgoorlie.spudshed.com.au/lines/monster-aussie-lemonade-500ml	Monster Aussie Lemonade 500mL	500mL	1	\N	2026-11-19 02:09:12.532501+00	2026-11-18 05:59:02.681685+00
307	12	3	6ae3ece45eb09f9d9430d3c8	https://kalgoorlie.spudshed.com.au/lines/monster-bad-apple-500ml	Monster Bad Apple 500mL	500mL	1	\N	2026-11-19 02:09:12.536361+00	2026-11-18 05:59:02.681685+00
308	14	3	6915684b05730aecff3d8549	https://kalgoorlie.spudshed.com.au/lines/monster-green-500ml	Monster Green 500mL	500mL	1	\N	2026-11-19 02:09:12.540322+00	2026-11-18 05:59:02.681685+00
309	15	3	6a55730775e52b9e1c527a7f	https://kalgoorlie.spudshed.com.au/lines/monster-lando-norris-zero-sugar-500ml	Monster Lando Norris Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:12.544417+00	2026-11-18 05:59:02.681685+00
323	328	3	6a55731975e52b9e1c527ffa	https://kalgoorlie.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:09:12.599092+00	2026-11-18 05:59:02.681685+00
336	64	3	6a55731775e52b9e1c527f90	https://kalgoorlie.spudshed.com.au/lines/red-bull-sugar-free-330ml	Red Bull Sugar Free 330mL	330mL	1	\N	2026-11-19 02:09:12.64906+00	2026-11-18 05:59:02.681685+00
337	8	3	69156c3b05730aecff3e8c24	https://kalgoorlie.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-250ml	Red Bull Sugar Free Berry Ed 250mL	250mL	1	\N	2026-11-19 02:09:12.652821+00	2026-11-18 05:59:02.681685+00
338	65	3	69156c3c05730aecff3e8c30	https://kalgoorlie.spudshed.com.au/lines/red-bull-sugar-free-berry-ed-473ml	Red Bull Sugar Free Berry Ed 473mL	473mL	1	\N	2026-11-19 02:09:12.656479+00	2026-11-18 05:59:02.681685+00
339	66	3	6a55731f75e52b9e1c5281e6	https://kalgoorlie.spudshed.com.au/lines/red-bull-sugar-free-lilac-grapefruit-250ml	Red Bull Sugar Free Lilac Grapefruit 250mL	250mL	1	\N	2026-11-19 02:09:12.660331+00	2026-11-18 05:59:02.681685+00
340	38	3	6915679605730aecff3d5332	https://kalgoorlie.spudshed.com.au/lines/monster-energy-drink-ultra-zero-4-x-500ml	Monster Energy Drink Ultra Zero 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.700103+00	2026-11-18 05:59:02.681685+00
341	39	3	6915679605730aecff3d533f	https://kalgoorlie.spudshed.com.au/lines/monster-energy-drink-mango-loco-4-x-500ml	Monster Energy Drink Mango Loco 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.719059+00	2026-11-18 05:59:02.681685+00
342	44	3	698e71fec9cce87bf5384fdd	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-violet-4-x-500ml	Monster Ultra Violet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.729495+00	2026-11-18 05:59:02.681685+00
343	40	3	691567a005730aecff3d5621	https://kalgoorlie.spudshed.com.au/lines/monster-energy-drink-green-4-x-500ml	Monster Energy Drink Green 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.736812+00	2026-11-18 05:59:02.681685+00
344	47	3	6abf01e1043c0daabd8bd107	https://kalgoorlie.spudshed.com.au/lines/monster-lando-norris-4-x-500ml	Monster Lando Norris 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.742458+00	2026-11-18 05:59:02.681685+00
345	49	3	69f7c5a9aebe13c423fe3590	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-peachy-keen-4-x-500ml-1	Monster Ultra Peachy Keen 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.747907+00	2026-11-18 05:59:02.681685+00
346	43	3	698e71fec9cce87bf5384fd1	https://kalgoorlie.spudshed.com.au/lines/monster-aussie-lemonade-4-x-500ml	Monster Aussie Lemonade 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.752333+00	2026-11-18 05:59:02.681685+00
347	48	3	6abf01e1043c0daabd8bd113	https://kalgoorlie.spudshed.com.au/lines/monster-rio-punch-4-x-500ml	Monster Rio Punch 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.756538+00	2026-11-18 05:59:02.681685+00
348	45	3	6915695e05730aecff3dcc04	https://kalgoorlie.spudshed.com.au/lines/mother-frosty-berry-4-x-500ml	Mother Frosty Berry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.760366+00	2026-11-18 05:59:02.681685+00
349	46	3	69156a8e05730aecff3e14dc	https://kalgoorlie.spudshed.com.au/lines/mother-lava-guava-4-x-500ml	Mother Lava Guava 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.764164+00	2026-11-18 05:59:02.681685+00
350	37	3	6915695e05730aecff3dcc1c	https://kalgoorlie.spudshed.com.au/lines/mother-original-4-x-500ml	Mother Original 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.767734+00	2026-11-18 05:59:02.681685+00
351	356	3	6915697905730aecff3dd327	https://kalgoorlie.spudshed.com.au/lines/mother-original-sugar-free-4-x-500ml	Mother Original Sugar Free 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.7725+00	2026-11-18 05:59:02.681685+00
352	50	3	6ae3eccd5eb09f9d9430cf1a	https://kalgoorlie.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:13.776115+00	2026-11-18 05:59:02.681685+00
353	332	3	69796b9377b7436e8e3b3f12	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-12-x-250ml	Red Bull Energy Drink 12 x 250mL	12 x 250mL	12	\N	2026-11-19 02:09:13.780085+00	2026-11-18 05:59:02.681685+00
354	333	3	69c9ff1247ded80fbc58e4a4	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-4-x-250ml-1	Red Bull Energy Drink 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:13.78443+00	2026-11-18 05:59:02.681685+00
355	334	3	6915689b05730aecff3d99e9	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-4-x-473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:13.788739+00	2026-11-18 05:59:02.681685+00
356	335	3	6a55730b75e52b9e1c527bd8	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-8-x-250ml	Red Bull Energy Drink 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:13.792651+00	2026-11-18 05:59:02.681685+00
357	42	3	6915689b05730aecff3d99dd	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-4-x-250ml	Red Bull Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:13.796509+00	2026-11-18 05:59:02.681685+00
358	41	3	691568e705730aecff3dae70	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-zero-4-x-250ml	Red Bull Energy Drink Zero 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:13.799952+00	2026-11-18 05:59:02.681685+00
243	15	3	6a62ecfbcb87d9bd90b947bb	https://bentleyplaza.spudshed.com.au/lines/monster-lando-norris-zero-sugar-500ml	Monster Lando Norris Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:09.54092+00	2026-11-18 05:58:59.721082+00
244	3	3	6a62ea54cb87d9bd90b880f1	https://bentleyplaza.spudshed.com.au/lines/monster-mango-loco-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:09:09.544677+00	2026-11-18 05:58:59.721082+00
260	328	3	6a62ec9bcb87d9bd90b92b17	https://bentleyplaza.spudshed.com.au/lines/red-bull-330ml	Red Bull 330mL	330mL	1	\N	2026-11-19 02:09:09.606709+00	2026-11-18 05:58:59.721082+00
329	6	3	691567eb05730aecff3d6b27	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-355ml	Red Bull Energy Drink Sugar Free Can 355mL	355mL	1	\N	2026-11-19 02:09:12.623246+00	2026-11-18 05:59:02.681685+00
330	34	3	691567b405730aecff3d5bcf	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-473ml	Red Bull Energy Drink Sugar Free Can 473mL	473mL	1	\N	2026-11-19 02:09:12.626716+00	2026-11-18 05:59:02.681685+00
331	7	3	691567e605730aecff3d6998	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-zero-can-250ml	Red Bull Energy Drink Zero Can 250mL	250mL	1	\N	2026-11-19 02:09:12.630538+00	2026-11-18 05:59:02.681685+00
359	55	3	69eaa38153245b8eb0908435	https://kalgoorlie.spudshed.com.au/lines/red-bull-sugar-free-4-x-473ml	Red Bull Sugar Free 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:13.803522+00	2026-11-18 05:59:02.681685+00
360	56	3	6a55730975e52b9e1c527b6c	https://kalgoorlie.spudshed.com.au/lines/red-bull-sugar-free-8-x-250ml	Red Bull Sugar Free 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:13.807+00	2026-11-18 05:59:02.681685+00
310	3	3	691567e505730aecff3d6974	https://kalgoorlie.spudshed.com.au/lines/monster-mango-loco-500ml	Monster Mango Loco 500mL	500mL	1	\N	2026-11-19 02:09:12.548241+00	2026-11-18 05:59:02.681685+00
311	18	3	6a55730a75e52b9e1c527bb1	https://kalgoorlie.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:09:12.552081+00	2026-11-18 05:59:02.681685+00
312	19	3	6a55730875e52b9e1c527b06	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-blue-hawaiian-500ml	Monster Ultra Blue Hawaiian 500mL	500mL	1	\N	2026-11-19 02:09:12.555933+00	2026-11-18 05:59:02.681685+00
370	17	3	6ae3ec8f153100a46674d8ea	https://waterford.spudshed.com.au/lines/monster-pipeline-punch-500ml-1	Monster Pipeline Punch 500mL	500mL	1	\N	2026-11-19 02:09:15.519202+00	2026-11-18 05:59:05.642129+00
371	18	3	6a557331a39b030b86524743	https://waterford.spudshed.com.au/lines/monster-rio-punch-500ml	Monster Rio Punch 500mL	500mL	1	\N	2026-11-19 02:09:15.52303+00	2026-11-18 05:59:05.642129+00
372	19	3	6a55732ca39b030b86524616	https://waterford.spudshed.com.au/lines/monster-ultra-blue-hawaiian-500ml	Monster Ultra Blue Hawaiian 500mL	500mL	1	\N	2026-11-19 02:09:15.52682+00	2026-11-18 05:59:05.642129+00
313	20	3	6915687605730aecff3d9075	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-fiesta-mango-500ml	Monster Ultra Fiesta Mango 500mL	500mL	1	\N	2026-11-19 02:09:12.559838+00	2026-11-18 05:59:02.681685+00
314	67	3	6ae3ecc75eb09f9d9430cdb7	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-strawberry-dreams-500ml-1	Monster Ultra Strawberry Dreams 500mL	500mL	1	\N	2026-11-19 02:09:12.563632+00	2026-11-18 05:59:02.681685+00
315	61	3	6ae3ecd55eb09f9d9430d0d6	https://kalgoorlie.spudshed.com.au/lines/monster-ultra-violet-500ml-1	Monster Ultra Violet 500mL	500mL	1	\N	2026-11-19 02:09:12.567579+00	2026-11-18 05:59:02.681685+00
316	5	3	6915682705730aecff3d7aff	https://kalgoorlie.spudshed.com.au/lines/monster-zero-sugar-500ml	Monster Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:12.571347+00	2026-11-18 05:59:02.681685+00
317	24	3	6915681105730aecff3d74f7	https://kalgoorlie.spudshed.com.au/lines/mother-drink-passion-500ml	Mother Drink Passion 500mL	500mL	1	\N	2026-11-19 02:09:12.574995+00	2026-11-18 05:59:02.681685+00
318	25	3	6ae3ec445eb09f9d9430b6bf	https://kalgoorlie.spudshed.com.au/lines/mother-energy-drink-original-500ml-1	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:09:12.578629+00	2026-11-18 05:59:02.681685+00
319	26	3	6ae3ece25eb09f9d9430d368	https://kalgoorlie.spudshed.com.au/lines/mother-energy-drink-sugar-free-500ml-1	Mother Energy Drink Sugar Free 500mL	500mL	1	\N	2026-11-19 02:09:12.58285+00	2026-11-18 05:59:02.681685+00
320	68	3	6915682405730aecff3d7a31	https://kalgoorlie.spudshed.com.au/lines/mother-lava-guava-500ml	Mother Lava Guava 500mL	500mL	1	\N	2026-11-19 02:09:12.58667+00	2026-11-18 05:59:02.681685+00
321	62	3	6915688005730aecff3d9348	https://kalgoorlie.spudshed.com.au/lines/mother-rainbow-sherbet-500ml	Mother Rainbow Sherbet 500mL	500mL	1	\N	2026-11-19 02:09:12.590888+00	2026-11-18 05:59:02.681685+00
322	28	3	6a55730975e52b9e1c527b60	https://kalgoorlie.spudshed.com.au/lines/mother-white-gummy-500ml	Mother White Gummy 500mL	500mL	1	\N	2026-11-19 02:09:12.594603+00	2026-11-18 05:59:02.681685+00
324	329	3	6ae3ece45eb09f9d9430d3d4	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-can-250ml-1	Red Bull Energy Drink Can 250mL	250mL	1	\N	2026-11-19 02:09:12.603178+00	2026-11-18 05:59:02.681685+00
325	330	3	6ae3ecde5eb09f9d9430d284	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-can-355ml-1	Red Bull Energy Drink Can 355mL	355mL	1	\N	2026-11-19 02:09:12.607276+00	2026-11-18 05:59:02.681685+00
326	331	3	691567d005730aecff3d6306	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-can-473ml	Red Bull Energy Drink Can 473mL	473mL	1	\N	2026-11-19 02:09:12.611137+00	2026-11-18 05:59:02.681685+00
327	32	3	691568a205730aecff3d9bd5	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-red-edition-can-250ml	Red Bull Energy Drink Red Edition Can 250mL	250mL	1	\N	2026-11-19 02:09:12.615987+00	2026-11-18 05:59:02.681685+00
328	33	3	691567e505730aecff3d6950	https://kalgoorlie.spudshed.com.au/lines/red-bull-energy-drink-sugar-free-can-250ml	Red Bull Energy Drink Sugar Free Can 250mL	250mL	1	\N	2026-11-19 02:09:12.61967+00	2026-11-18 05:59:02.681685+00
373	20	3	6a178cc9a8f2a37adc95eb7e	https://waterford.spudshed.com.au/lines/monster-ultra-fiesta-mango-500ml	Monster Ultra Fiesta Mango 500mL	500mL	1	\N	2026-11-19 02:09:15.530657+00	2026-11-18 05:59:05.642129+00
374	4	3	6a73d50f167a0d3a4f46f5c1	https://waterford.spudshed.com.au/lines/monster-ultra-strawberry-4pk	Monster Ultra Strawberry 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:15.535628+00	2026-11-18 05:59:05.642129+00
375	22	3	6a557334a39b030b8652480f	https://waterford.spudshed.com.au/lines/monster-ultra-vice-500ml	Monster Ultra Vice 500mL	500mL	1	\N	2026-11-19 02:09:15.539851+00	2026-11-18 05:59:05.642129+00
376	5	3	6a178d81a8f2a37adc963303	https://waterford.spudshed.com.au/lines/monster-zero-sugar-500ml	Monster Zero Sugar 500mL	500mL	1	\N	2026-11-19 02:09:15.543634+00	2026-11-18 05:59:05.642129+00
377	323	3	6a178bcda8f2a37adc958afa	https://waterford.spudshed.com.au/lines/monster-zero-ultra-500ml	Monster Zero Ultra 500mL	500mL	1	\N	2026-11-19 02:09:15.547546+00	2026-11-18 05:59:05.642129+00
378	23	3	6ae3ecee153100a46674f030	https://waterford.spudshed.com.au/lines/mother-drink-frosty-berry-500ml-1	Mother Drink Frosty Berry 500mL	500mL	1	\N	2026-11-19 02:09:15.551249+00	2026-11-18 05:59:05.642129+00
379	24	3	6a178beba8f2a37adc9597dc	https://waterford.spudshed.com.au/lines/mother-drink-passion-500ml	Mother Drink Passion 500mL	500mL	1	\N	2026-11-19 02:09:15.55471+00	2026-11-18 05:59:05.642129+00
380	25	3	6ae3eccb153100a46674e8d8	https://waterford.spudshed.com.au/lines/mother-energy-drink-original-500ml-1	Mother Energy Drink Original 500mL	500mL	1	\N	2026-11-19 02:09:15.558312+00	2026-11-18 05:59:05.642129+00
381	26	3	6ae3ed07153100a46674f4f7	https://waterford.spudshed.com.au/lines/mother-energy-drink-sugar-free-500ml-1	Mother Energy Drink Sugar Free 500mL	500mL	1	\N	2026-11-19 02:09:15.562006+00	2026-11-18 05:59:05.642129+00
382	68	3	6a178d3ca8f2a37adc96162c	https://waterford.spudshed.com.au/lines/mother-lava-guava-500ml	Mother Lava Guava 500mL	500mL	1	\N	2026-11-19 02:09:15.56599+00	2026-11-18 05:59:05.642129+00
383	62	3	6a178d5aa8f2a37adc96229b	https://waterford.spudshed.com.au/lines/mother-rainbow-sherbet-500ml	Mother Rainbow Sherbet 500mL	500mL	1	\N	2026-11-19 02:09:15.569738+00	2026-11-18 05:59:05.642129+00
384	27	3	6a55732fa39b030b865246e3	https://waterford.spudshed.com.au/lines/mother-watermelon-500ml	Mother Watermelon 500mL	500mL	1	\N	2026-11-19 02:09:15.573687+00	2026-11-18 05:59:05.642129+00
412	50	3	6ae3eca2153100a46674dd3d	https://waterford.spudshed.com.au/lines/mother-rainbow-sherbet-4-x-500ml-1	Mother Rainbow Sherbet 4 x 500mL	4 x 500mL	4	\N	2026-11-19 02:09:16.780911+00	2026-11-18 05:59:05.642129+00
413	332	3	6a178d7ea8f2a37adc96319b	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-12-x-250ml	Red Bull Energy Drink 12 x 250mL	12 x 250mL	12	\N	2026-11-19 02:09:16.784987+00	2026-11-18 05:59:05.642129+00
414	333	3	6ae3ed1b153100a46674f90b	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-4-x-250ml-1	Red Bull Energy Drink 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:16.789173+00	2026-11-18 05:59:05.642129+00
415	334	3	6a178bfca8f2a37adc959f48	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-4-x-473ml	Red Bull Energy Drink 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:16.793252+00	2026-11-18 05:59:05.642129+00
416	335	3	6a557317a39b030b86524171	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-8-x-250ml	Red Bull Energy Drink 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:16.797649+00	2026-11-18 05:59:05.642129+00
417	41	3	6a178be6a8f2a37adc95958e	https://waterford.spudshed.com.au/lines/red-bull-energy-drink-zero-4-x-250ml	Red Bull Energy Drink Zero 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:16.801501+00	2026-11-18 05:59:05.642129+00
418	55	3	6a178d4fa8f2a37adc961e55	https://waterford.spudshed.com.au/lines/red-bull-sugar-free-4-x-473ml	Red Bull Sugar Free 4 x 473mL	4 x 473mL	4	\N	2026-11-19 02:09:16.805166+00	2026-11-18 05:59:05.642129+00
419	56	3	6a557317a39b030b8652417d	https://waterford.spudshed.com.au/lines/red-bull-sugar-free-8-x-250ml	Red Bull Sugar Free 8 x 250mL	8 x 250mL	8	\N	2026-11-19 02:09:16.8086+00	2026-11-18 05:59:05.642129+00
420	57	3	6a178d20a8f2a37adc960b31	https://waterford.spudshed.com.au/lines/v-energy-drink-blue-4-x-250ml	V Energy Drink Blue 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:16.812362+00	2026-11-18 05:59:05.642129+00
421	58	3	6a178cfaa8f2a37adc95fe7e	https://waterford.spudshed.com.au/lines/v-energy-drink-original-4-x-250ml	V Energy Drink Original 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:16.816162+00	2026-11-18 05:59:05.642129+00
422	59	3	6a178cfba8f2a37adc95ff1a	https://waterford.spudshed.com.au/lines/v-energy-drink-sugar-free-4-x-250ml	V Energy Drink Sugar Free 4 x 250mL	4 x 250mL	4	\N	2026-11-19 02:09:16.821175+00	2026-11-18 05:59:05.642129+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.notifications (id, device_id, kind, title, body, payload, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: observation_votes; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.observation_votes (observation_id, device_id, vote, created_at) FROM stdin;
\.


--
-- Data for Name: observations; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.observations (id, store_id, product_id, listing_id, price_cents, was_price_cents, unit_price_cents_per_l, promo_kind, promo_qty, promo_total_cents, in_stock, source, price_scope, device_id, note, photo_url, observed_at, created_at, status, dedupe_key, chain_id, photo_id, ocr_text) FROM stdin;
20845	\N	272	907	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.23381+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:272:2026-11-18:1750:none:0:0	1	\N	\N
20846	\N	12	908	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.241269+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:12:2026-11-18:350:special:0:0	1	\N	\N
20847	\N	4	909	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.245776+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:4:2026-11-18:1750:none:0:0	1	\N	\N
20848	\N	14	910	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.249935+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:14:2026-11-18:350:special:0:0	1	\N	\N
20849	\N	39	911	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.253355+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:39:2026-11-18:1750:none:0:0	1	\N	\N
20850	\N	273	912	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.257947+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:273:2026-11-18:350:special:0:0	1	\N	\N
20851	\N	40	913	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.260865+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:40:2026-11-18:1750:none:0:0	1	\N	\N
20852	\N	38	914	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.263598+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:38:2026-11-18:1750:none:0:0	1	\N	\N
20853	\N	44	915	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.2665+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:44:2026-11-18:1750:none:0:0	1	\N	\N
20854	\N	48	916	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.269538+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:48:2026-11-18:1750:none:0:0	1	\N	\N
20855	\N	49	917	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.272373+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:49:2026-11-18:1750:none:0:0	1	\N	\N
20856	\N	67	918	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.275299+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:67:2026-11-18:350:special:0:0	1	\N	\N
20857	\N	20	919	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.2782+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:20:2026-11-18:350:special:0:0	1	\N	\N
20858	\N	19	920	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.281085+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:19:2026-11-18:350:special:0:0	1	\N	\N
20859	\N	3	921	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.283984+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:3:2026-11-18:350:special:0:0	1	\N	\N
20860	\N	47	922	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.286862+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:47:2026-11-18:1750:none:0:0	1	\N	\N
20861	\N	5	923	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.290047+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:5:2026-11-18:350:special:0:0	1	\N	\N
20862	\N	22	924	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.29297+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:22:2026-11-18:350:special:0:0	1	\N	\N
20863	\N	15	925	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.29594+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:15:2026-11-18:350:special:0:0	1	\N	\N
20864	\N	61	926	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.298788+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:61:2026-11-18:350:special:0:0	1	\N	\N
20865	\N	18	927	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.301612+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:18:2026-11-18:350:special:0:0	1	\N	\N
20866	\N	21	928	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.304375+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:21:2026-11-18:350:special:0:0	1	\N	\N
20867	\N	11	929	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.307138+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:11:2026-11-18:350:special:0:0	1	\N	\N
20868	\N	274	930	350	470	700	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.310901+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:274:2026-11-18:350:special:0:0	1	\N	\N
20869	\N	275	931	550	\N	1100	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.314305+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:275:2026-11-18:550:none:0:0	1	\N	\N
20870	\N	43	932	1750	\N	875	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:22.317045+00	2026-11-18 06:05:19.909648+00	accepted	scrape:chain1:43:2026-11-18:1750:none:0:0	1	\N	\N
20871	\N	54	933	2200	\N	1100	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.296418+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:54:2026-11-18:2200:none:0:0	1	\N	\N
20872	\N	53	934	1500	\N	793	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.305522+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:53:2026-11-18:1500:none:0:0	1	\N	\N
20873	\N	51	935	2500	\N	833	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.311836+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:51:2026-11-18:2500:none:0:0	1	\N	\N
20874	\N	29	936	470	\N	1424	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.317069+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:29:2026-11-18:470:none:0:0	1	\N	\N
20875	\N	1	937	450	560	951	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.321701+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:1:2026-11-18:450:special:0:0	1	\N	\N
20876	\N	41	938	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.325228+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:41:2026-11-18:1300:none:0:0	1	\N	\N
20877	\N	42	939	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.328324+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:42:2026-11-18:1300:none:0:0	1	\N	\N
20878	\N	52	940	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.331798+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:52:2026-11-18:1300:none:0:0	1	\N	\N
20879	\N	30	941	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.335063+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:30:2026-11-18:320:none:0:0	1	\N	\N
20880	\N	276	942	6249	\N	1101	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.338497+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:276:2026-11-18:6249:none:0:0	1	\N	\N
20881	\N	277	943	6249	\N	1101	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.341992+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:277:2026-11-18:6249:none:0:0	1	\N	\N
20882	\N	278	944	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.345367+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:278:2026-11-18:1300:none:0:0	1	\N	\N
20883	\N	279	945	6249	\N	1101	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.348451+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:279:2026-11-18:6249:none:0:0	1	\N	\N
20884	\N	280	946	6249	\N	1101	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.351546+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:280:2026-11-18:6249:none:0:0	1	\N	\N
20885	\N	281	947	6249	\N	1101	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.354679+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:281:2026-11-18:6249:none:0:0	1	\N	\N
20886	\N	7	948	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.357336+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:7:2026-11-18:320:none:0:0	1	\N	\N
20887	\N	55	949	1500	\N	793	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.359889+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:55:2026-11-18:1500:none:0:0	1	\N	\N
20888	\N	282	950	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.363454+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:282:2026-11-18:1300:none:0:0	1	\N	\N
20889	\N	33	951	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.366344+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:33:2026-11-18:320:none:0:0	1	\N	\N
20890	\N	283	952	1500	\N	793	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.36971+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:283:2026-11-18:1500:none:0:0	1	\N	\N
20891	\N	284	953	6249	\N	1101	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.372721+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:284:2026-11-18:6249:none:0:0	1	\N	\N
20892	\N	285	954	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.376009+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:285:2026-11-18:320:none:0:0	1	\N	\N
20893	\N	56	955	2200	\N	1100	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.378551+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:56:2026-11-18:2200:none:0:0	1	\N	\N
20894	\N	286	956	2500	\N	833	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.381862+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:286:2026-11-18:2500:none:0:0	1	\N	\N
20895	\N	287	957	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.385254+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:287:2026-11-18:320:none:0:0	1	\N	\N
20896	\N	288	958	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.38903+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:288:2026-11-18:1300:none:0:0	1	\N	\N
20897	\N	289	959	1300	\N	1300	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.392724+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:289:2026-11-18:1300:none:0:0	1	\N	\N
20898	\N	32	960	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.395368+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:32:2026-11-18:320:none:0:0	1	\N	\N
20899	\N	34	961	450	560	951	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.397985+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:34:2026-11-18:450:special:0:0	1	\N	\N
20900	\N	66	962	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.40059+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:66:2026-11-18:320:none:0:0	1	\N	\N
20901	\N	290	963	7499	\N	29996	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.403576+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:290:2026-11-18:7499:none:0:0	1	\N	\N
20902	\N	8	964	320	\N	1280	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.406198+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:8:2026-11-18:320:none:0:0	1	\N	\N
20904	\N	60	965	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:23.412072+00	2026-11-18 06:05:23.286967+00	accepted	scrape:chain1:60:2026-11-18:440:none:0:0	1	\N	\N
20905	\N	291	966	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.433211+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:291:2026-11-18:1000:none:0:0	1	\N	\N
20906	\N	59	967	720	1200	720	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.436094+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:59:2026-11-18:720:special:0:0	1	\N	\N
20907	\N	57	968	720	1200	720	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.439439+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:57:2026-11-18:720:special:0:0	1	\N	\N
20909	\N	292	970	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.445747+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:292:2026-11-18:1000:none:0:0	1	\N	\N
20911	\N	58	971	720	1200	720	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.451216+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:58:2026-11-18:720:special:0:0	1	\N	\N
20912	\N	293	972	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.454898+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:293:2026-11-18:440:none:0:0	1	\N	\N
20913	\N	294	973	720	1200	720	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.458333+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:294:2026-11-18:720:special:0:0	1	\N	\N
20914	\N	295	974	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.461743+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:295:2026-11-18:440:none:0:0	1	\N	\N
20915	\N	296	975	6950	\N	1158	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.464716+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:296:2026-11-18:6950:none:0:0	1	\N	\N
20916	\N	297	976	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.467937+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:297:2026-11-18:265:none:0:0	1	\N	\N
20917	\N	298	977	6255	\N	6255	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.470955+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:298:2026-11-18:6255:none:0:0	1	\N	\N
20918	\N	299	978	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.474305+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:299:2026-11-18:265:none:0:0	1	\N	\N
20919	\N	300	979	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.477655+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:300:2026-11-18:1000:none:0:0	1	\N	\N
20920	\N	301	980	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.481123+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:301:2026-11-18:440:none:0:0	1	\N	\N
20921	\N	302	981	1290	\N	652	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.485138+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:302:2026-11-18:1290:none:0:0	1	\N	\N
20922	\N	303	982	350	\N	1000	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.488654+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:303:2026-11-18:350:none:0:0	1	\N	\N
20924	\N	304	984	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.494652+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:304:2026-11-18:1000:none:0:0	1	\N	\N
20925	\N	305	985	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.498005+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:305:2026-11-18:265:none:0:0	1	\N	\N
20926	\N	306	986	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.501392+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:306:2026-11-18:265:none:0:0	1	\N	\N
20927	\N	307	987	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.50468+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:307:2026-11-18:265:none:0:0	1	\N	\N
20928	\N	308	988	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.508036+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:308:2026-11-18:265:none:0:0	1	\N	\N
20929	\N	25	989	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.510768+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:25:2026-11-18:360:none:0:0	1	\N	\N
20930	\N	37	990	870	1450	435	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:24.513381+00	2026-11-18 06:05:24.430403+00	accepted	scrape:chain1:37:2026-11-18:870:special:0:0	1	\N	\N
20936	\N	62	991	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.784242+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:62:2026-11-18:360:none:0:0	1	\N	\N
20937	\N	68	992	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.78739+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:68:2026-11-18:360:none:0:0	1	\N	\N
20938	\N	50	993	870	1450	435	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.790443+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:50:2026-11-18:870:special:0:0	1	\N	\N
20941	\N	27	995	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.798524+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:27:2026-11-18:360:none:0:0	1	\N	\N
20942	\N	45	996	870	1450	435	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.801365+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:45:2026-11-18:870:special:0:0	1	\N	\N
20943	\N	28	997	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.804221+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:28:2026-11-18:360:none:0:0	1	\N	\N
20944	\N	46	998	870	1450	435	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.807068+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:46:2026-11-18:870:special:0:0	1	\N	\N
20956	\N	309	999	400	\N	1212	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:25.834191+00	2026-11-18 06:05:25.779304+00	accepted	scrape:chain1:309:2026-11-18:400:none:0:0	1	\N	\N
20960	\N	310	1000	900	\N	450	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:26.836166+00	2026-11-18 06:05:26.825095+00	accepted	scrape:chain1:310:2026-11-18:900:none:0:0	1	\N	\N
20961	\N	311	1001	275	\N	550	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:26.843122+00	2026-11-18 06:05:26.825095+00	accepted	scrape:chain1:311:2026-11-18:275:none:0:0	1	\N	\N
20962	\N	312	1002	450	700	1023	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:26.846497+00	2026-11-18 06:05:26.825095+00	accepted	scrape:chain1:312:2026-11-18:450:special:0:0	1	\N	\N
20966	\N	313	1003	6095	\N	12190	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:26.855808+00	2026-11-18 06:05:26.825095+00	accepted	scrape:chain1:313:2026-11-18:6095:none:0:0	1	\N	\N
20978	\N	314	983	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:26.884234+00	2026-11-18 06:05:26.825095+00	accepted	scrape:chain1:314:2026-11-18:265:none:0:0	1	\N	\N
21009	\N	315	1004	690	770	345	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.140236+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:315:2026-11-18:690:special:0:0	1	\N	\N
21010	\N	316	1005	550	\N	733	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.148451+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:316:2026-11-18:550:none:0:0	1	\N	\N
21011	\N	317	1006	550	\N	733	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.154903+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:317:2026-11-18:550:none:0:0	1	\N	\N
21013	\N	318	1008	330	430	660	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.163836+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:318:2026-11-18:330:special:0:0	1	\N	\N
21014	\N	319	1009	330	430	660	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.168101+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:319:2026-11-18:330:special:0:0	1	\N	\N
21019	\N	320	1014	330	465	660	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.182475+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:320:2026-11-18:330:special:0:0	1	\N	\N
21022	\N	321	1017	550	\N	733	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.191309+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:321:2026-11-18:550:none:0:0	1	\N	\N
21024	\N	317	1019	570	\N	760	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:29.196769+00	2026-11-18 06:05:29.130598+00	accepted	scrape:chain1:317:2026-11-18:570:none:0:0	1	\N	\N
21025	\N	322	1020	1400	\N	2800	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 06:05:30.661711+00	2026-11-18 06:05:30.652681+00	accepted	scrape:chain1:322:2026-11-18:1400:none:0:0	1	\N	\N
21279	561	323	254	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:06:12.503988+00	2026-11-18 06:06:12.44389+00	accepted	scrape:store561:323:2026-11-18:329:special:0:0	3	\N	\N
21329	562	323	304	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:06:15.377216+00	2026-11-18 06:06:15.35845+00	accepted	scrape:store562:323:2026-11-18:329:special:0:0	3	\N	\N
21402	563	323	377	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:06:18.497706+00	2026-11-18 06:06:18.418495+00	accepted	scrape:store563:323:2026-11-18:329:special:0:0	3	\N	\N
20423	554	1	1	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.470911+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:1:2026-11-18:579:none:0:0	3	\N	\N
20424	554	2	2	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.476984+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:2:2026-11-18:579:none:0:0	3	\N	\N
20425	554	3	3	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.480741+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:3:2026-11-18:329:special:0:0	3	\N	\N
20426	554	4	4	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.483902+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:4:2026-11-18:875:special:0:0	3	\N	\N
20427	554	5	5	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.487045+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:5:2026-11-18:329:special:0:0	3	\N	\N
20428	554	6	6	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.489967+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:6:2026-11-18:459:none:0:0	3	\N	\N
20429	554	7	7	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.492364+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:7:2026-11-18:299:special:0:0	3	\N	\N
20430	554	8	8	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.494876+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:8:2026-11-18:299:special:0:0	3	\N	\N
20431	554	9	9	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.497471+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:9:2026-11-18:399:none:0:0	3	\N	\N
20432	554	10	10	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.499647+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:10:2026-11-18:399:none:0:0	3	\N	\N
20433	554	11	11	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.502091+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:11:2026-11-18:329:special:0:0	3	\N	\N
20434	554	12	12	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.504584+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:12:2026-11-18:449:none:0:0	3	\N	\N
20435	554	13	13	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.507036+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:13:2026-11-18:329:special:0:0	3	\N	\N
20436	554	14	14	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.50946+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:14:2026-11-18:329:special:0:0	3	\N	\N
20437	554	15	15	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.511812+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:15:2026-11-18:329:special:0:0	3	\N	\N
20438	554	16	16	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.514368+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:16:2026-11-18:329:special:0:0	3	\N	\N
20439	554	17	17	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.516629+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:17:2026-11-18:329:special:0:0	3	\N	\N
20440	554	18	18	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.51889+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:18:2026-11-18:329:special:0:0	3	\N	\N
20441	554	19	19	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.521219+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:19:2026-11-18:449:none:0:0	3	\N	\N
20442	554	20	20	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.523543+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:20:2026-11-18:329:special:0:0	3	\N	\N
20443	554	21	21	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.525799+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:21:2026-11-18:329:special:0:0	3	\N	\N
20444	554	22	22	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.528259+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:22:2026-11-18:329:special:0:0	3	\N	\N
20445	554	23	23	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.530554+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:23:2026-11-18:359:special:0:0	3	\N	\N
20446	554	24	24	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.532772+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:24:2026-11-18:359:special:0:0	3	\N	\N
20447	554	25	25	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.535229+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:25:2026-11-18:359:special:0:0	3	\N	\N
20448	554	26	26	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.537631+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:26:2026-11-18:359:special:0:0	3	\N	\N
20449	554	27	27	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.539778+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:27:2026-11-18:359:special:0:0	3	\N	\N
20450	554	28	28	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.541947+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:28:2026-11-18:449:none:0:0	3	\N	\N
20451	554	29	29	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.544687+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:29:2026-11-18:479:none:0:0	3	\N	\N
20452	554	30	30	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.547335+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:30:2026-11-18:299:special:0:0	3	\N	\N
20453	554	31	31	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.549747+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:31:2026-11-18:459:none:0:0	3	\N	\N
20454	554	32	32	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.552009+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:32:2026-11-18:299:special:0:0	3	\N	\N
20455	554	33	33	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.554286+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:33:2026-11-18:299:special:0:0	3	\N	\N
20456	554	34	34	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.556466+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:34:2026-11-18:579:none:0:0	3	\N	\N
20457	554	35	35	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.558712+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:35:2026-11-18:299:special:0:0	3	\N	\N
20458	554	36	36	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:58.560971+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:36:2026-11-18:579:none:0:0	3	\N	\N
20459	554	37	37	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.793813+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:37:2026-11-18:1449:none:0:0	3	\N	\N
20460	554	38	38	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.796503+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:38:2026-11-18:875:special:0:0	3	\N	\N
20461	554	39	39	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.798907+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:39:2026-11-18:875:special:0:0	3	\N	\N
20462	554	40	40	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.801243+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:40:2026-11-18:875:special:0:0	3	\N	\N
20464	554	41	42	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.805524+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:41:2026-11-18:999:special:0:0	3	\N	\N
20465	554	42	43	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.807729+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:42:2026-11-18:999:special:0:0	3	\N	\N
20466	554	43	44	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.80989+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:43:2026-11-18:875:special:0:0	3	\N	\N
20467	554	44	45	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.812253+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:44:2026-11-18:875:special:0:0	3	\N	\N
20468	554	45	46	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.814462+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:45:2026-11-18:1449:none:0:0	3	\N	\N
20469	554	46	47	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.8167+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:46:2026-11-18:1449:none:0:0	3	\N	\N
20470	554	47	48	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.818857+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:47:2026-11-18:1549:none:0:0	3	\N	\N
20471	554	48	49	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.820995+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:48:2026-11-18:1549:none:0:0	3	\N	\N
20472	554	49	50	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.823112+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:49:2026-11-18:875:special:0:0	3	\N	\N
20473	554	50	51	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.825465+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:50:2026-11-18:1449:none:0:0	3	\N	\N
20474	554	51	52	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.828237+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:51:2026-11-18:2799:special:0:0	3	\N	\N
20475	554	52	53	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.830732+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:52:2026-11-18:999:special:0:0	3	\N	\N
20476	554	53	54	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.833107+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:53:2026-11-18:1599:special:0:0	3	\N	\N
20477	554	54	55	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.835542+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:54:2026-11-18:2599:none:0:0	3	\N	\N
20478	554	55	56	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.837981+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:55:2026-11-18:1599:special:0:0	3	\N	\N
20479	554	56	57	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.840266+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:56:2026-11-18:2599:none:0:0	3	\N	\N
20480	554	57	58	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.842417+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:57:2026-11-18:1199:none:0:0	3	\N	\N
20481	554	58	59	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.844621+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:58:2026-11-18:1199:none:0:0	3	\N	\N
20482	554	59	60	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:04:59.846902+00	2026-11-18 06:04:57.551181+00	accepted	scrape:store554:59:2026-11-18:1199:none:0:0	3	\N	\N
20483	555	10	61	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.584862+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:10:2026-11-18:399:none:0:0	3	\N	\N
20484	555	5	62	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.592785+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:5:2026-11-18:329:special:0:0	3	\N	\N
20485	555	60	63	439	\N	878	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.595096+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:60:2026-11-18:439:none:0:0	3	\N	\N
20486	555	9	64	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.597319+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:9:2026-11-18:399:none:0:0	3	\N	\N
20487	555	11	65	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.599734+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:11:2026-11-18:329:special:0:0	3	\N	\N
20488	555	12	66	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.60205+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:12:2026-11-18:449:none:0:0	3	\N	\N
20489	555	13	67	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.604332+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:13:2026-11-18:329:special:0:0	3	\N	\N
20490	555	14	68	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.606848+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:14:2026-11-18:329:special:0:0	3	\N	\N
20491	555	15	69	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.609219+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:15:2026-11-18:329:special:0:0	3	\N	\N
20492	555	3	70	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.611539+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:3:2026-11-18:329:special:0:0	3	\N	\N
20493	555	16	71	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.613755+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:16:2026-11-18:329:special:0:0	3	\N	\N
20494	555	17	72	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.616138+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:17:2026-11-18:329:special:0:0	3	\N	\N
20495	555	18	73	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.61862+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:18:2026-11-18:329:special:0:0	3	\N	\N
20496	555	19	74	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.620922+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:19:2026-11-18:449:none:0:0	3	\N	\N
20497	555	20	75	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.623171+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:20:2026-11-18:329:special:0:0	3	\N	\N
20498	555	49	76	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.625409+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:49:2026-11-18:329:special:0:0	3	\N	\N
20499	555	21	77	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.627708+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:21:2026-11-18:329:special:0:0	3	\N	\N
20500	555	4	78	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.629865+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:4:2026-11-18:875:special:0:0	3	\N	\N
20501	555	22	79	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.63217+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:22:2026-11-18:329:special:0:0	3	\N	\N
20502	555	61	80	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.634574+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:61:2026-11-18:329:special:0:0	3	\N	\N
20503	555	23	81	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.637277+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:23:2026-11-18:359:special:0:0	3	\N	\N
20504	555	25	82	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.640122+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:25:2026-11-18:359:special:0:0	3	\N	\N
20505	555	26	83	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.642636+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:26:2026-11-18:359:special:0:0	3	\N	\N
20506	555	62	84	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.645047+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:62:2026-11-18:359:special:0:0	3	\N	\N
20507	555	29	85	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.647649+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:29:2026-11-18:479:none:0:0	3	\N	\N
20508	555	30	86	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.650242+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:30:2026-11-18:299:special:0:0	3	\N	\N
20509	555	31	87	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.652756+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:31:2026-11-18:459:none:0:0	3	\N	\N
20510	555	1	88	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.655307+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:1:2026-11-18:579:none:0:0	3	\N	\N
20511	555	32	89	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.657694+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:32:2026-11-18:299:special:0:0	3	\N	\N
20512	555	33	90	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.659956+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:33:2026-11-18:299:special:0:0	3	\N	\N
20513	555	6	91	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.662057+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:6:2026-11-18:459:none:0:0	3	\N	\N
20514	555	34	92	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.664421+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:34:2026-11-18:579:none:0:0	3	\N	\N
20515	555	7	93	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.666617+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:7:2026-11-18:299:special:0:0	3	\N	\N
20516	555	2	94	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.668806+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:2:2026-11-18:579:none:0:0	3	\N	\N
20517	555	63	95	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.671064+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:63:2026-11-18:579:none:0:0	3	\N	\N
20518	555	64	96	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.673137+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:64:2026-11-18:479:none:0:0	3	\N	\N
20519	555	8	97	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.675404+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:8:2026-11-18:299:special:0:0	3	\N	\N
20520	555	65	98	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.677846+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:65:2026-11-18:579:none:0:0	3	\N	\N
20521	555	66	99	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:01.680095+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:66:2026-11-18:299:special:0:0	3	\N	\N
20522	555	37	100	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.658741+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:37:2026-11-18:1449:none:0:0	3	\N	\N
20523	555	40	101	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.661484+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:40:2026-11-18:875:special:0:0	3	\N	\N
20524	555	43	102	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.663867+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:43:2026-11-18:875:special:0:0	3	\N	\N
20525	555	39	103	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.666153+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:39:2026-11-18:875:special:0:0	3	\N	\N
20526	555	38	104	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.668467+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:38:2026-11-18:875:special:0:0	3	\N	\N
20527	555	45	105	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.670656+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:45:2026-11-18:1449:none:0:0	3	\N	\N
20528	555	46	106	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.672939+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:46:2026-11-18:1449:none:0:0	3	\N	\N
20530	555	57	108	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.677392+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:57:2026-11-18:1199:none:0:0	3	\N	\N
20531	555	47	109	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.679591+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:47:2026-11-18:1549:none:0:0	3	\N	\N
20532	555	49	110	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.681769+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:49:2026-11-18:875:special:0:0	3	\N	\N
20533	555	44	111	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.683933+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:44:2026-11-18:875:special:0:0	3	\N	\N
20534	555	50	112	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.686214+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:50:2026-11-18:1449:none:0:0	3	\N	\N
20535	555	51	113	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.689537+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:51:2026-11-18:2799:special:0:0	3	\N	\N
20536	555	52	114	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.692699+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:52:2026-11-18:999:special:0:0	3	\N	\N
20537	555	53	115	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.695571+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:53:2026-11-18:1599:special:0:0	3	\N	\N
20538	555	54	116	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.698104+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:54:2026-11-18:2599:none:0:0	3	\N	\N
20539	555	42	117	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.700263+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:42:2026-11-18:999:special:0:0	3	\N	\N
20540	555	41	118	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.702392+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:41:2026-11-18:999:special:0:0	3	\N	\N
20541	555	55	119	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.704525+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:55:2026-11-18:1599:special:0:0	3	\N	\N
20542	555	58	120	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.70669+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:58:2026-11-18:1199:none:0:0	3	\N	\N
20543	555	59	121	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:02.708743+00	2026-11-18 06:05:01.579614+00	accepted	scrape:store555:59:2026-11-18:1199:none:0:0	3	\N	\N
20544	556	11	122	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.369398+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:11:2026-11-18:329:special:0:0	3	\N	\N
20545	556	12	123	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.371884+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:12:2026-11-18:449:none:0:0	3	\N	\N
20546	556	14	124	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.374226+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:14:2026-11-18:329:special:0:0	3	\N	\N
20547	556	3	125	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.376571+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:3:2026-11-18:329:special:0:0	3	\N	\N
20548	556	16	126	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.378868+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:16:2026-11-18:329:special:0:0	3	\N	\N
20549	556	17	127	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.381159+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:17:2026-11-18:329:special:0:0	3	\N	\N
20550	556	18	128	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.383472+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:18:2026-11-18:329:special:0:0	3	\N	\N
20551	556	49	129	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.385623+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:49:2026-11-18:329:special:0:0	3	\N	\N
20552	556	21	130	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.388281+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:21:2026-11-18:329:special:0:0	3	\N	\N
20553	556	4	131	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.39064+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:4:2026-11-18:875:special:0:0	3	\N	\N
20554	556	67	132	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.392971+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:67:2026-11-18:329:special:0:0	3	\N	\N
20555	556	61	133	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.395347+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:61:2026-11-18:329:special:0:0	3	\N	\N
20556	556	5	134	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.397596+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:5:2026-11-18:329:special:0:0	3	\N	\N
20557	556	23	135	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.399696+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:23:2026-11-18:359:special:0:0	3	\N	\N
20558	556	24	136	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.40187+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:24:2026-11-18:359:special:0:0	3	\N	\N
20559	556	25	137	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.404049+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:25:2026-11-18:359:special:0:0	3	\N	\N
20560	556	26	138	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.406241+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:26:2026-11-18:359:special:0:0	3	\N	\N
20561	556	68	139	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.408427+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:68:2026-11-18:359:special:0:0	3	\N	\N
20562	556	62	140	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.410639+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:62:2026-11-18:359:special:0:0	3	\N	\N
20563	556	27	141	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.412825+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:27:2026-11-18:359:special:0:0	3	\N	\N
20564	556	28	142	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.415013+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:28:2026-11-18:449:none:0:0	3	\N	\N
20565	556	29	143	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.417561+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:29:2026-11-18:479:none:0:0	3	\N	\N
20566	556	30	144	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.420086+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:30:2026-11-18:299:special:0:0	3	\N	\N
20567	556	31	145	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.422657+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:31:2026-11-18:459:none:0:0	3	\N	\N
20568	556	32	146	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.424856+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:32:2026-11-18:299:special:0:0	3	\N	\N
20569	556	34	147	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.427135+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:34:2026-11-18:579:none:0:0	3	\N	\N
20570	556	7	148	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.429496+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:7:2026-11-18:299:special:0:0	3	\N	\N
20571	556	2	149	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.431777+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:2:2026-11-18:579:none:0:0	3	\N	\N
20572	556	63	150	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.433986+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:63:2026-11-18:579:none:0:0	3	\N	\N
20573	556	64	151	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.436301+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:64:2026-11-18:479:none:0:0	3	\N	\N
20574	556	65	152	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.439061+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:65:2026-11-18:579:none:0:0	3	\N	\N
20575	556	66	153	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.441336+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:66:2026-11-18:299:special:0:0	3	\N	\N
20576	556	69	154	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.443477+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:69:2026-11-18:579:none:0:0	3	\N	\N
20577	556	70	155	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.445544+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:70:2026-11-18:299:special:0:0	3	\N	\N
20578	556	71	156	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:04.447736+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:71:2026-11-18:579:none:0:0	3	\N	\N
20579	556	45	157	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.574739+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:45:2026-11-18:1449:none:0:0	3	\N	\N
20580	556	43	158	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.585574+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:43:2026-11-18:875:special:0:0	3	\N	\N
20581	556	40	159	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.595268+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:40:2026-11-18:875:special:0:0	3	\N	\N
20582	556	39	160	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.60134+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:39:2026-11-18:875:special:0:0	3	\N	\N
20583	556	38	161	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.606135+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:38:2026-11-18:875:special:0:0	3	\N	\N
20584	556	47	162	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.610198+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:47:2026-11-18:1549:none:0:0	3	\N	\N
20585	556	48	163	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.61387+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:48:2026-11-18:1549:none:0:0	3	\N	\N
20586	556	49	164	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.617075+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:49:2026-11-18:875:special:0:0	3	\N	\N
20587	556	44	165	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.61979+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:44:2026-11-18:875:special:0:0	3	\N	\N
20588	556	46	166	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.62237+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:46:2026-11-18:1449:none:0:0	3	\N	\N
20589	556	37	167	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.625007+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:37:2026-11-18:1449:none:0:0	3	\N	\N
20591	556	50	169	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.629699+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:50:2026-11-18:1449:none:0:0	3	\N	\N
20592	556	53	170	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.632316+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:53:2026-11-18:1599:special:0:0	3	\N	\N
20593	556	54	171	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.634778+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:54:2026-11-18:2599:none:0:0	3	\N	\N
20594	556	42	172	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.636917+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:42:2026-11-18:999:special:0:0	3	\N	\N
20595	556	41	173	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.639555+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:41:2026-11-18:999:special:0:0	3	\N	\N
20596	556	55	174	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.641699+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:55:2026-11-18:1599:special:0:0	3	\N	\N
20597	556	56	175	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.643815+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:56:2026-11-18:2599:none:0:0	3	\N	\N
20598	556	57	176	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:05.646001+00	2026-11-18 06:05:04.367777+00	accepted	scrape:store556:57:2026-11-18:1199:none:0:0	3	\N	\N
20599	558	9	177	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.310137+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:9:2026-11-18:399:none:0:0	3	\N	\N
20600	558	10	178	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.31266+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:10:2026-11-18:399:none:0:0	3	\N	\N
20601	558	11	179	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.315188+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:11:2026-11-18:329:special:0:0	3	\N	\N
20602	558	12	180	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.317496+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:12:2026-11-18:449:none:0:0	3	\N	\N
20603	558	14	181	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.319745+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:14:2026-11-18:329:special:0:0	3	\N	\N
20604	558	15	182	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.322046+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:15:2026-11-18:329:special:0:0	3	\N	\N
20605	558	3	183	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.324338+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:3:2026-11-18:329:special:0:0	3	\N	\N
20606	558	16	184	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.326574+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:16:2026-11-18:329:special:0:0	3	\N	\N
20607	558	17	185	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.32882+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:17:2026-11-18:329:special:0:0	3	\N	\N
20608	558	18	186	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.331111+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:18:2026-11-18:329:special:0:0	3	\N	\N
20609	558	19	187	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.333338+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:19:2026-11-18:449:none:0:0	3	\N	\N
20610	558	20	188	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.335592+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:20:2026-11-18:329:special:0:0	3	\N	\N
20611	558	21	189	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.338401+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:21:2026-11-18:329:special:0:0	3	\N	\N
20612	558	4	190	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.340656+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:4:2026-11-18:875:special:0:0	3	\N	\N
20613	558	22	191	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.343006+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:22:2026-11-18:329:special:0:0	3	\N	\N
20614	558	61	192	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.345543+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:61:2026-11-18:329:special:0:0	3	\N	\N
20615	558	23	193	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.347934+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:23:2026-11-18:359:special:0:0	3	\N	\N
20616	558	25	194	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.350169+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:25:2026-11-18:359:special:0:0	3	\N	\N
20617	558	26	195	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.352374+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:26:2026-11-18:359:special:0:0	3	\N	\N
20618	558	68	196	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.354767+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:68:2026-11-18:359:special:0:0	3	\N	\N
20619	558	62	197	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.356969+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:62:2026-11-18:359:special:0:0	3	\N	\N
20620	558	27	198	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.359309+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:27:2026-11-18:359:special:0:0	3	\N	\N
20621	558	28	199	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.361709+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:28:2026-11-18:449:none:0:0	3	\N	\N
20622	558	29	200	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.36429+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:29:2026-11-18:479:none:0:0	3	\N	\N
20623	558	30	201	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.366802+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:30:2026-11-18:299:special:0:0	3	\N	\N
20624	558	31	202	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.369281+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:31:2026-11-18:459:none:0:0	3	\N	\N
20625	558	1	203	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.371826+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:1:2026-11-18:579:none:0:0	3	\N	\N
20626	558	32	204	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.374019+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:32:2026-11-18:299:special:0:0	3	\N	\N
20627	558	33	205	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.376213+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:33:2026-11-18:299:special:0:0	3	\N	\N
20628	558	6	206	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.378381+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:6:2026-11-18:459:none:0:0	3	\N	\N
20629	558	34	207	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.380475+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:34:2026-11-18:579:none:0:0	3	\N	\N
20630	558	7	208	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.382562+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:7:2026-11-18:299:special:0:0	3	\N	\N
20631	558	2	209	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.384795+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:2:2026-11-18:579:none:0:0	3	\N	\N
20632	558	35	210	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.387036+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:35:2026-11-18:299:special:0:0	3	\N	\N
20633	558	36	211	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.389652+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:36:2026-11-18:579:none:0:0	3	\N	\N
20634	558	63	212	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.391849+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:63:2026-11-18:579:none:0:0	3	\N	\N
20635	558	64	213	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.393934+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:64:2026-11-18:479:none:0:0	3	\N	\N
20636	558	8	214	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.396041+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:8:2026-11-18:299:special:0:0	3	\N	\N
20637	558	65	215	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.398139+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:65:2026-11-18:579:none:0:0	3	\N	\N
20638	558	66	216	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.400283+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:66:2026-11-18:299:special:0:0	3	\N	\N
20639	558	69	217	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:07.402472+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:69:2026-11-18:579:none:0:0	3	\N	\N
20640	558	43	218	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.596418+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:43:2026-11-18:875:special:0:0	3	\N	\N
20641	558	40	219	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.608163+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:40:2026-11-18:875:special:0:0	3	\N	\N
20642	558	39	220	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.615681+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:39:2026-11-18:875:special:0:0	3	\N	\N
20643	558	38	221	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.621276+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:38:2026-11-18:875:special:0:0	3	\N	\N
20644	558	47	222	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.625746+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:47:2026-11-18:1549:none:0:0	3	\N	\N
20645	558	48	223	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.629752+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:48:2026-11-18:1549:none:0:0	3	\N	\N
20646	558	49	224	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.63339+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:49:2026-11-18:875:special:0:0	3	\N	\N
20647	558	44	225	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.636435+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:44:2026-11-18:875:special:0:0	3	\N	\N
20648	558	45	226	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.639787+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:45:2026-11-18:1449:none:0:0	3	\N	\N
20649	558	46	227	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.642464+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:46:2026-11-18:1449:none:0:0	3	\N	\N
20650	558	37	228	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.645057+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:37:2026-11-18:1449:none:0:0	3	\N	\N
20652	558	50	230	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.649667+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:50:2026-11-18:1449:none:0:0	3	\N	\N
20653	558	51	231	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.652228+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:51:2026-11-18:2799:special:0:0	3	\N	\N
20654	558	52	232	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.654717+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:52:2026-11-18:999:special:0:0	3	\N	\N
20655	558	53	233	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.657197+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:53:2026-11-18:1599:special:0:0	3	\N	\N
20656	558	42	234	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.65936+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:42:2026-11-18:999:special:0:0	3	\N	\N
20657	558	57	235	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.661505+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:57:2026-11-18:1199:none:0:0	3	\N	\N
20658	558	58	236	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.663681+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:58:2026-11-18:1199:none:0:0	3	\N	\N
20659	558	59	237	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:08.665778+00	2026-11-18 06:05:07.308816+00	accepted	scrape:store558:59:2026-11-18:1199:none:0:0	3	\N	\N
20660	561	9	238	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.304934+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:9:2026-11-18:399:none:0:0	3	\N	\N
20661	561	10	239	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.307787+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:10:2026-11-18:399:none:0:0	3	\N	\N
20662	561	11	240	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.310927+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:11:2026-11-18:329:special:0:0	3	\N	\N
20663	561	13	241	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.31415+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:13:2026-11-18:329:special:0:0	3	\N	\N
20664	561	14	242	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.317258+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:14:2026-11-18:329:special:0:0	3	\N	\N
20665	561	15	243	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.320601+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:15:2026-11-18:329:special:0:0	3	\N	\N
20666	561	3	244	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.323956+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:3:2026-11-18:329:special:0:0	3	\N	\N
20667	561	16	245	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.327177+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:16:2026-11-18:329:special:0:0	3	\N	\N
20668	561	18	246	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.330469+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:18:2026-11-18:329:special:0:0	3	\N	\N
20669	561	19	247	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.333867+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:19:2026-11-18:449:none:0:0	3	\N	\N
20670	561	20	248	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.337477+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:20:2026-11-18:329:special:0:0	3	\N	\N
20671	561	21	249	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.340713+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:21:2026-11-18:329:special:0:0	3	\N	\N
20672	561	4	250	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.342968+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:4:2026-11-18:875:special:0:0	3	\N	\N
20673	561	22	251	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.345187+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:22:2026-11-18:329:special:0:0	3	\N	\N
20674	561	61	252	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.347511+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:61:2026-11-18:329:special:0:0	3	\N	\N
20675	561	5	253	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.349749+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:5:2026-11-18:329:special:0:0	3	\N	\N
20677	561	23	255	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.354274+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:23:2026-11-18:359:special:0:0	3	\N	\N
20678	561	25	256	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.356474+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:25:2026-11-18:359:special:0:0	3	\N	\N
20679	561	68	257	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.35873+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:68:2026-11-18:359:special:0:0	3	\N	\N
20680	561	27	258	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.361001+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:27:2026-11-18:359:special:0:0	3	\N	\N
20681	561	28	259	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.363132+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:28:2026-11-18:449:none:0:0	3	\N	\N
20682	561	29	260	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.365606+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:29:2026-11-18:479:none:0:0	3	\N	\N
20683	561	30	261	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.368103+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:30:2026-11-18:299:special:0:0	3	\N	\N
20684	561	31	262	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.370563+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:31:2026-11-18:459:none:0:0	3	\N	\N
20685	561	1	263	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.373193+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:1:2026-11-18:579:none:0:0	3	\N	\N
20686	561	32	264	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.37547+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:32:2026-11-18:299:special:0:0	3	\N	\N
20687	561	33	265	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.3777+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:33:2026-11-18:299:special:0:0	3	\N	\N
20688	561	6	266	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.379772+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:6:2026-11-18:459:none:0:0	3	\N	\N
20689	561	34	267	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.381991+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:34:2026-11-18:579:none:0:0	3	\N	\N
20690	561	7	268	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.384259+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:7:2026-11-18:299:special:0:0	3	\N	\N
20691	561	2	269	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.386716+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:2:2026-11-18:579:none:0:0	3	\N	\N
20692	561	35	270	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.38962+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:35:2026-11-18:299:special:0:0	3	\N	\N
20693	561	36	271	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.391988+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:36:2026-11-18:579:none:0:0	3	\N	\N
20694	561	63	272	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.394271+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:63:2026-11-18:579:none:0:0	3	\N	\N
20695	561	64	273	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.39639+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:64:2026-11-18:479:none:0:0	3	\N	\N
20696	561	8	274	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:10.398501+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:8:2026-11-18:299:special:0:0	3	\N	\N
20697	561	43	275	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.111657+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:43:2026-11-18:875:special:0:0	3	\N	\N
20698	561	40	276	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.114333+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:40:2026-11-18:875:special:0:0	3	\N	\N
20699	561	39	277	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.11693+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:39:2026-11-18:875:special:0:0	3	\N	\N
20700	561	38	278	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.119329+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:38:2026-11-18:875:special:0:0	3	\N	\N
20701	561	47	279	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.121803+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:47:2026-11-18:1549:none:0:0	3	\N	\N
20702	561	48	280	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.124156+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:48:2026-11-18:1549:none:0:0	3	\N	\N
20703	561	49	281	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.126652+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:49:2026-11-18:875:special:0:0	3	\N	\N
20704	561	44	282	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.128987+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:44:2026-11-18:875:special:0:0	3	\N	\N
20705	561	45	283	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.131366+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:45:2026-11-18:1449:none:0:0	3	\N	\N
20706	561	46	284	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.133808+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:46:2026-11-18:1449:none:0:0	3	\N	\N
20707	561	37	285	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.13594+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:37:2026-11-18:1449:none:0:0	3	\N	\N
20709	561	50	287	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.140557+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:50:2026-11-18:1449:none:0:0	3	\N	\N
20710	561	51	288	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.142965+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:51:2026-11-18:2799:special:0:0	3	\N	\N
20711	561	52	289	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.145372+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:52:2026-11-18:999:special:0:0	3	\N	\N
20712	561	53	290	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.147759+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:53:2026-11-18:1599:special:0:0	3	\N	\N
20713	561	54	291	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.150077+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:54:2026-11-18:2599:none:0:0	3	\N	\N
20714	561	42	292	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.152091+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:42:2026-11-18:999:special:0:0	3	\N	\N
20715	561	41	293	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.154234+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:41:2026-11-18:999:special:0:0	3	\N	\N
20716	561	55	294	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.156287+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:55:2026-11-18:1599:special:0:0	3	\N	\N
20717	561	56	295	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.158596+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:56:2026-11-18:2599:none:0:0	3	\N	\N
20718	561	57	296	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.160642+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:57:2026-11-18:1199:none:0:0	3	\N	\N
20719	561	58	297	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.162779+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:58:2026-11-18:1199:none:0:0	3	\N	\N
20720	561	59	298	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:12.165095+00	2026-11-18 06:05:10.303445+00	accepted	scrape:store561:59:2026-11-18:1199:none:0:0	3	\N	\N
20721	562	4	299	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.847845+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:4:2026-11-18:875:special:0:0	3	\N	\N
20722	562	49	300	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.850374+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:49:2026-11-18:329:special:0:0	3	\N	\N
20723	562	13	301	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.852536+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:13:2026-11-18:329:special:0:0	3	\N	\N
20724	562	17	302	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.85483+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:17:2026-11-18:329:special:0:0	3	\N	\N
20725	562	21	303	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.857014+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:21:2026-11-18:329:special:0:0	3	\N	\N
20726	562	5	304	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.859147+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:5:2026-11-18:329:special:0:0	3	\N	\N
20727	562	27	305	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.861376+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:27:2026-11-18:359:special:0:0	3	\N	\N
20728	562	11	306	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.86363+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:11:2026-11-18:329:special:0:0	3	\N	\N
20729	562	12	307	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.865817+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:12:2026-11-18:449:none:0:0	3	\N	\N
20730	562	14	308	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.868093+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:14:2026-11-18:329:special:0:0	3	\N	\N
20731	562	15	309	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.870324+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:15:2026-11-18:329:special:0:0	3	\N	\N
20732	562	3	310	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.87252+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:3:2026-11-18:329:special:0:0	3	\N	\N
20733	562	18	311	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.87479+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:18:2026-11-18:329:special:0:0	3	\N	\N
20734	562	19	312	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.877025+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:19:2026-11-18:449:none:0:0	3	\N	\N
20735	562	20	313	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.879212+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:20:2026-11-18:329:special:0:0	3	\N	\N
20736	562	67	314	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.881475+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:67:2026-11-18:329:special:0:0	3	\N	\N
20737	562	61	315	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.883834+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:61:2026-11-18:329:special:0:0	3	\N	\N
20739	562	24	317	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.888615+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:24:2026-11-18:359:special:0:0	3	\N	\N
20740	562	25	318	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.891025+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:25:2026-11-18:359:special:0:0	3	\N	\N
20741	562	26	319	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.893341+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:26:2026-11-18:359:special:0:0	3	\N	\N
20742	562	68	320	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.895569+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:68:2026-11-18:359:special:0:0	3	\N	\N
20743	562	62	321	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.897796+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:62:2026-11-18:359:special:0:0	3	\N	\N
20744	562	28	322	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.90026+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:28:2026-11-18:449:none:0:0	3	\N	\N
20745	562	29	323	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.902935+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:29:2026-11-18:479:none:0:0	3	\N	\N
20746	562	30	324	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.905577+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:30:2026-11-18:299:special:0:0	3	\N	\N
20747	562	31	325	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.908126+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:31:2026-11-18:459:none:0:0	3	\N	\N
20748	562	1	326	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.910728+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:1:2026-11-18:579:none:0:0	3	\N	\N
20749	562	32	327	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.9129+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:32:2026-11-18:299:special:0:0	3	\N	\N
20750	562	33	328	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.915692+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:33:2026-11-18:299:special:0:0	3	\N	\N
20751	562	6	329	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.918076+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:6:2026-11-18:459:none:0:0	3	\N	\N
20752	562	34	330	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.920351+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:34:2026-11-18:579:none:0:0	3	\N	\N
20753	562	7	331	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.922659+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:7:2026-11-18:299:special:0:0	3	\N	\N
20754	562	2	332	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.925038+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:2:2026-11-18:579:none:0:0	3	\N	\N
20755	562	35	333	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.927272+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:35:2026-11-18:299:special:0:0	3	\N	\N
20756	562	36	334	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.929475+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:36:2026-11-18:579:none:0:0	3	\N	\N
20757	562	63	335	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.931707+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:63:2026-11-18:579:none:0:0	3	\N	\N
20758	562	64	336	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.933904+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:64:2026-11-18:479:none:0:0	3	\N	\N
20759	562	8	337	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.936035+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:8:2026-11-18:299:special:0:0	3	\N	\N
20760	562	65	338	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.939105+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:65:2026-11-18:579:none:0:0	3	\N	\N
20761	562	66	339	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:13.942014+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:66:2026-11-18:299:special:0:0	3	\N	\N
20762	562	38	340	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.586026+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:38:2026-11-18:875:special:0:0	3	\N	\N
20763	562	39	341	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.58861+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:39:2026-11-18:875:special:0:0	3	\N	\N
20764	562	44	342	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.590949+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:44:2026-11-18:875:special:0:0	3	\N	\N
20765	562	40	343	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.593229+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:40:2026-11-18:875:special:0:0	3	\N	\N
20766	562	47	344	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.595508+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:47:2026-11-18:1549:none:0:0	3	\N	\N
20767	562	49	345	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.59777+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:49:2026-11-18:875:special:0:0	3	\N	\N
20768	562	43	346	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.600152+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:43:2026-11-18:875:special:0:0	3	\N	\N
20769	562	48	347	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.602498+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:48:2026-11-18:1549:none:0:0	3	\N	\N
20770	562	45	348	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.604865+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:45:2026-11-18:1449:none:0:0	3	\N	\N
20771	562	46	349	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.607216+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:46:2026-11-18:1449:none:0:0	3	\N	\N
20772	562	37	350	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.609512+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:37:2026-11-18:1449:none:0:0	3	\N	\N
20774	562	50	352	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.614032+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:50:2026-11-18:1449:none:0:0	3	\N	\N
20775	562	51	353	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.616639+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:51:2026-11-18:2799:special:0:0	3	\N	\N
20776	562	52	354	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.619245+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:52:2026-11-18:999:special:0:0	3	\N	\N
20777	562	53	355	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.621787+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:53:2026-11-18:1599:special:0:0	3	\N	\N
20778	562	54	356	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.624283+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:54:2026-11-18:2599:none:0:0	3	\N	\N
20779	562	42	357	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.626333+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:42:2026-11-18:999:special:0:0	3	\N	\N
20780	562	41	358	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.62854+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:41:2026-11-18:999:special:0:0	3	\N	\N
20781	562	55	359	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.630667+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:55:2026-11-18:1599:special:0:0	3	\N	\N
20782	562	56	360	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:14.632796+00	2026-11-18 06:05:13.846402+00	accepted	scrape:store562:56:2026-11-18:2599:none:0:0	3	\N	\N
20783	563	21	361	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.132121+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:21:2026-11-18:329:special:0:0	3	\N	\N
20784	563	61	362	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.142849+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:61:2026-11-18:329:special:0:0	3	\N	\N
20785	563	11	363	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.148659+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:11:2026-11-18:329:special:0:0	3	\N	\N
20786	563	12	364	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.151286+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:12:2026-11-18:449:none:0:0	3	\N	\N
20787	563	13	365	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.153583+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:13:2026-11-18:329:special:0:0	3	\N	\N
20788	563	14	366	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.155799+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:14:2026-11-18:329:special:0:0	3	\N	\N
20789	563	15	367	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.15832+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:15:2026-11-18:329:special:0:0	3	\N	\N
20790	563	3	368	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.160673+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:3:2026-11-18:329:special:0:0	3	\N	\N
20791	563	16	369	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.162926+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:16:2026-11-18:329:special:0:0	3	\N	\N
20792	563	17	370	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.165229+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:17:2026-11-18:329:special:0:0	3	\N	\N
20793	563	18	371	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.167559+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:18:2026-11-18:329:special:0:0	3	\N	\N
20794	563	19	372	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.169768+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:19:2026-11-18:449:none:0:0	3	\N	\N
20795	563	20	373	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.172138+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:20:2026-11-18:329:special:0:0	3	\N	\N
20796	563	4	374	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.174502+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:4:2026-11-18:875:special:0:0	3	\N	\N
20797	563	22	375	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.176878+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:22:2026-11-18:329:special:0:0	3	\N	\N
20798	563	5	376	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.179173+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:5:2026-11-18:329:special:0:0	3	\N	\N
20800	563	23	378	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.183679+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:23:2026-11-18:359:special:0:0	3	\N	\N
20801	563	24	379	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.185776+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:24:2026-11-18:359:special:0:0	3	\N	\N
20802	563	25	380	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.188481+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:25:2026-11-18:359:special:0:0	3	\N	\N
20803	563	26	381	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.190833+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:26:2026-11-18:359:special:0:0	3	\N	\N
20804	563	68	382	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.193083+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:68:2026-11-18:359:special:0:0	3	\N	\N
20805	563	62	383	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.1954+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:62:2026-11-18:359:special:0:0	3	\N	\N
20806	563	27	384	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.197729+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:27:2026-11-18:359:special:0:0	3	\N	\N
20807	563	28	385	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.200014+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:28:2026-11-18:449:none:0:0	3	\N	\N
20808	563	29	386	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.202512+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:29:2026-11-18:479:none:0:0	3	\N	\N
20809	563	30	387	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.20502+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:30:2026-11-18:299:special:0:0	3	\N	\N
20810	563	31	388	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.207419+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:31:2026-11-18:459:none:0:0	3	\N	\N
20811	563	1	389	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.209903+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:1:2026-11-18:579:none:0:0	3	\N	\N
20812	563	32	390	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.212102+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:32:2026-11-18:299:special:0:0	3	\N	\N
20813	563	33	391	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.214348+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:33:2026-11-18:299:special:0:0	3	\N	\N
20814	563	6	392	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.216555+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:6:2026-11-18:459:none:0:0	3	\N	\N
20815	563	34	393	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.218861+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:34:2026-11-18:579:none:0:0	3	\N	\N
20816	563	7	394	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.221115+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:7:2026-11-18:299:special:0:0	3	\N	\N
20817	563	2	395	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.223351+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:2:2026-11-18:579:none:0:0	3	\N	\N
20818	563	35	396	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.225563+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:35:2026-11-18:299:special:0:0	3	\N	\N
20819	563	63	397	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.227835+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:63:2026-11-18:579:none:0:0	3	\N	\N
20820	563	64	398	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:17.229962+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:64:2026-11-18:479:none:0:0	3	\N	\N
20821	563	43	399	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:18.992765+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:43:2026-11-18:875:special:0:0	3	\N	\N
20822	563	42	400	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:18.995548+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:42:2026-11-18:999:special:0:0	3	\N	\N
20823	563	40	401	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:18.998061+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:40:2026-11-18:875:special:0:0	3	\N	\N
20824	563	39	402	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.000413+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:39:2026-11-18:875:special:0:0	3	\N	\N
20825	563	38	403	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.00291+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:38:2026-11-18:875:special:0:0	3	\N	\N
20826	563	47	404	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.005369+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:47:2026-11-18:1549:none:0:0	3	\N	\N
20827	563	48	405	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.007619+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:48:2026-11-18:1549:none:0:0	3	\N	\N
20828	563	49	406	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.009841+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:49:2026-11-18:875:special:0:0	3	\N	\N
20829	563	44	407	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.012153+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:44:2026-11-18:875:special:0:0	3	\N	\N
20830	563	45	408	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.014543+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:45:2026-11-18:1449:none:0:0	3	\N	\N
20831	563	46	409	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.016738+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:46:2026-11-18:1449:none:0:0	3	\N	\N
20832	563	37	410	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.018848+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:37:2026-11-18:1449:none:0:0	3	\N	\N
20834	563	50	412	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.022997+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:50:2026-11-18:1449:none:0:0	3	\N	\N
20835	563	51	413	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.025468+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:51:2026-11-18:2799:special:0:0	3	\N	\N
20836	563	52	414	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.027979+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:52:2026-11-18:999:special:0:0	3	\N	\N
20837	563	53	415	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.030464+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:53:2026-11-18:1599:special:0:0	3	\N	\N
20838	563	54	416	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.03289+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:54:2026-11-18:2599:none:0:0	3	\N	\N
20839	563	41	417	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.035045+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:41:2026-11-18:999:special:0:0	3	\N	\N
20840	563	55	418	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.037279+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:55:2026-11-18:1599:special:0:0	3	\N	\N
20841	563	56	419	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.039696+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:56:2026-11-18:2599:none:0:0	3	\N	\N
20842	563	57	420	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.041863+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:57:2026-11-18:1199:none:0:0	3	\N	\N
20843	563	58	421	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.043965+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:58:2026-11-18:1199:none:0:0	3	\N	\N
20844	563	59	422	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 06:05:19.046027+00	2026-11-18 06:05:17.126724+00	accepted	scrape:store563:59:2026-11-18:1199:none:0:0	3	\N	\N
22072	275	3	\N	515	\N	\N	none	\N	\N	\N	crowd	store	27	\N	\N	2026-11-18 11:26:46.380023+00	2026-11-18 11:26:46.380023+00	needs_review	\N	4	\N	\N
22157	555	328	85	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:00.418767+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:328:2026-11-18:479:none:0:0	3	\N	\N
22158	555	329	86	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:00.423886+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:329:2026-11-18:299:special:0:0	3	\N	\N
22159	555	330	87	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:00.428318+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:330:2026-11-18:459:none:0:0	3	\N	\N
22160	555	331	88	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:00.433136+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:331:2026-11-18:579:none:0:0	3	\N	\N
22185	555	332	113	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:01.676104+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:332:2026-11-18:2799:special:0:0	3	\N	\N
22186	555	333	114	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:01.680752+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:333:2026-11-18:999:special:0:0	3	\N	\N
22187	555	334	115	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:01.685061+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:334:2026-11-18:1599:special:0:0	3	\N	\N
22188	555	335	116	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:01.690049+00	2026-11-18 14:09:00.310254+00	accepted	scrape:store555:335:2026-11-18:2599:none:0:0	3	\N	\N
22272	558	328	200	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:06.383307+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:328:2026-11-18:479:none:0:0	3	\N	\N
22273	558	329	201	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:06.389264+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:329:2026-11-18:299:special:0:0	3	\N	\N
22274	558	330	202	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:06.393185+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:330:2026-11-18:459:none:0:0	3	\N	\N
22275	558	331	203	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:06.397193+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:331:2026-11-18:579:none:0:0	3	\N	\N
22303	558	332	231	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:07.516309+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:332:2026-11-18:2799:special:0:0	3	\N	\N
22304	558	333	232	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:07.52051+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:333:2026-11-18:999:special:0:0	3	\N	\N
22305	558	334	233	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:07.524895+00	2026-11-18 14:09:06.283597+00	accepted	scrape:store558:334:2026-11-18:1599:special:0:0	3	\N	\N
22395	562	328	323	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:12.563543+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:328:2026-11-18:479:none:0:0	3	\N	\N
22396	562	329	324	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:12.56765+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:329:2026-11-18:299:special:0:0	3	\N	\N
22397	562	330	325	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:12.572101+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:330:2026-11-18:459:none:0:0	3	\N	\N
22398	562	331	326	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:12.576262+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:331:2026-11-18:579:none:0:0	3	\N	\N
22425	562	332	353	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:13.529194+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:332:2026-11-18:2799:special:0:0	3	\N	\N
22426	562	333	354	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:13.533007+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:333:2026-11-18:999:special:0:0	3	\N	\N
22427	562	334	355	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:13.537132+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:334:2026-11-18:1599:special:0:0	3	\N	\N
22428	562	335	356	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:13.541281+00	2026-11-18 14:09:12.465893+00	accepted	scrape:store562:335:2026-11-18:2599:none:0:0	3	\N	\N
22943	\N	336	1021	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:20:02.065101+00	2026-11-18 21:20:00.001424+00	accepted	scrape:chain1:336:2026-11-18:440:none:0:0	1	\N	\N
22985	\N	338	1022	720	1200	720	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:20:04.305593+00	2026-11-18 21:20:04.249755+00	accepted	scrape:chain1:338:2026-11-18:720:special:0:0	1	\N	\N
22993	\N	298	977	6950	\N	6950	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:20:04.33553+00	2026-11-18 21:20:04.249755+00	accepted	scrape:chain1:298:2026-11-18:6950:none:0:0	1	\N	\N
23106	\N	272	1024	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.935831+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:272:2026-11-18:1050:special:0:0	2	\N	\N
23107	\N	339	1025	1500	\N	1000	multibuy	2	2100	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.942758+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:339:2026-11-18:1500:multibuy:2:2100	2	\N	\N
23108	\N	4	1026	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.947706+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:4:2026-11-18:1050:special:0:0	2	\N	\N
23109	\N	39	1027	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.952868+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:39:2026-11-18:1050:special:0:0	2	\N	\N
23110	\N	340	1028	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.958349+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:340:2026-11-18:1050:special:0:0	2	\N	\N
23111	\N	44	1029	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.964172+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:44:2026-11-18:1050:special:0:0	2	\N	\N
23112	\N	47	1030	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.969189+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:47:2026-11-18:1050:special:0:0	2	\N	\N
23113	\N	38	1031	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.974476+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:38:2026-11-18:1050:special:0:0	2	\N	\N
23114	\N	273	1032	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.978822+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:273:2026-11-18:470:multibuy:2:790	2	\N	\N
23115	\N	19	1033	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.983567+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:19:2026-11-18:470:multibuy:2:790	2	\N	\N
23116	\N	40	1034	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.988091+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:40:2026-11-18:1050:special:0:0	2	\N	\N
23117	\N	22	1035	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.992174+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:22:2026-11-18:470:multibuy:2:790	2	\N	\N
23118	\N	12	1036	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:01.99599+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:12:2026-11-18:470:multibuy:2:790	2	\N	\N
23119	\N	48	1037	1050	1750	525	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.000161+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:48:2026-11-18:1050:special:0:0	2	\N	\N
23120	\N	341	1038	1500	\N	1000	multibuy	2	2100	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.00491+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:341:2026-11-18:1500:multibuy:2:2100	2	\N	\N
23121	\N	3	1039	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.009043+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:3:2026-11-18:470:multibuy:2:790	2	\N	\N
23122	\N	21	1040	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.012896+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:21:2026-11-18:470:multibuy:2:790	2	\N	\N
23123	\N	67	1041	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.017098+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:67:2026-11-18:470:multibuy:2:790	2	\N	\N
23124	\N	20	1042	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.020893+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:20:2026-11-18:470:multibuy:2:790	2	\N	\N
23125	\N	61	1043	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.024967+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:61:2026-11-18:470:multibuy:2:790	2	\N	\N
22100	554	328	29	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:57.498169+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:328:2026-11-18:479:none:0:0	3	\N	\N
22101	554	329	30	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:57.503974+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:329:2026-11-18:299:special:0:0	3	\N	\N
22102	554	330	31	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:57.508985+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:330:2026-11-18:459:none:0:0	3	\N	\N
22103	554	331	1	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:57.513912+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:331:2026-11-18:579:none:0:0	3	\N	\N
22124	554	332	52	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:58.670868+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:332:2026-11-18:2799:special:0:0	3	\N	\N
22125	554	333	53	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:58.676076+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:333:2026-11-18:999:special:0:0	3	\N	\N
22126	554	334	54	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:58.680867+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:334:2026-11-18:1599:special:0:0	3	\N	\N
22127	554	335	55	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:08:58.685491+00	2026-11-18 14:08:56.502147+00	accepted	scrape:store554:335:2026-11-18:2599:none:0:0	3	\N	\N
22215	556	328	143	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:03.48965+00	2026-11-18 14:09:03.402899+00	accepted	scrape:store556:328:2026-11-18:479:none:0:0	3	\N	\N
22216	556	329	144	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:03.493788+00	2026-11-18 14:09:03.402899+00	accepted	scrape:store556:329:2026-11-18:299:special:0:0	3	\N	\N
22217	556	330	145	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:03.497752+00	2026-11-18 14:09:03.402899+00	accepted	scrape:store556:330:2026-11-18:459:none:0:0	3	\N	\N
22242	556	334	170	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:04.505098+00	2026-11-18 14:09:03.402899+00	accepted	scrape:store556:334:2026-11-18:1599:special:0:0	3	\N	\N
22243	556	335	171	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:04.509537+00	2026-11-18 14:09:03.402899+00	accepted	scrape:store556:335:2026-11-18:2599:none:0:0	3	\N	\N
22332	561	328	260	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:09.524188+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:328:2026-11-18:479:none:0:0	3	\N	\N
22333	561	329	261	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:09.528459+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:329:2026-11-18:299:special:0:0	3	\N	\N
22334	561	330	262	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:09.532407+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:330:2026-11-18:459:none:0:0	3	\N	\N
22335	561	331	263	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:09.536739+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:331:2026-11-18:579:none:0:0	3	\N	\N
22360	561	332	288	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:10.60293+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:332:2026-11-18:2799:special:0:0	3	\N	\N
22361	561	333	289	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:10.607253+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:333:2026-11-18:999:special:0:0	3	\N	\N
22362	561	334	290	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:10.611487+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:334:2026-11-18:1599:special:0:0	3	\N	\N
22363	561	335	291	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:10.615641+00	2026-11-18 14:09:09.404648+00	accepted	scrape:store561:335:2026-11-18:2599:none:0:0	3	\N	\N
22458	563	328	386	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:15.401459+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:328:2026-11-18:479:none:0:0	3	\N	\N
22459	563	329	387	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:15.405546+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:329:2026-11-18:299:special:0:0	3	\N	\N
22460	563	330	388	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:15.409535+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:330:2026-11-18:459:none:0:0	3	\N	\N
22461	563	331	389	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:15.41373+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:331:2026-11-18:579:none:0:0	3	\N	\N
22485	563	332	413	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:16.630923+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:332:2026-11-18:2799:special:0:0	3	\N	\N
22486	563	333	414	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:16.635168+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:333:2026-11-18:999:special:0:0	3	\N	\N
22487	563	334	415	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:16.640212+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:334:2026-11-18:1599:special:0:0	3	\N	\N
22488	563	335	416	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 14:09:16.64572+00	2026-11-18 14:09:15.281657+00	accepted	scrape:store563:335:2026-11-18:2599:none:0:0	3	\N	\N
22974	\N	337	963	7499	\N	1250	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:20:03.174409+00	2026-11-18 21:20:03.051254+00	accepted	scrape:chain1:337:2026-11-18:7499:none:0:0	1	\N	\N
23132	\N	333	1050	650	1300	650	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.524398+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:333:2026-11-18:650:special:0:0	2	\N	\N
23133	\N	278	1051	650	1300	650	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.54646+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:278:2026-11-18:650:special:0:0	2	\N	\N
23134	\N	42	1052	650	1300	650	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.562256+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:42:2026-11-18:650:special:0:0	2	\N	\N
23135	\N	335	1053	2200	\N	1100	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.573807+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:335:2026-11-18:2200:none:0:0	2	\N	\N
23136	\N	282	1054	650	1300	650	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.580152+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:282:2026-11-18:650:special:0:0	2	\N	\N
23137	\N	287	1055	320	\N	1280	multibuy	2	570	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.58659+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:287:2026-11-18:320:multibuy:2:570	2	\N	\N
23138	\N	329	1056	320	\N	1280	multibuy	2	570	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.591774+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:329:2026-11-18:320:multibuy:2:570	2	\N	\N
23139	\N	41	1057	650	1300	650	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.595905+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:41:2026-11-18:650:special:0:0	2	\N	\N
23140	\N	331	1058	560	\N	1184	multibuy	2	900	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.600285+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:331:2026-11-18:560:multibuy:2:900	2	\N	\N
23141	\N	70	1059	320	\N	1280	multibuy	2	570	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.604334+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:70:2026-11-18:320:multibuy:2:570	2	\N	\N
23142	\N	33	1060	320	\N	1280	multibuy	2	570	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.608606+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:33:2026-11-18:320:multibuy:2:570	2	\N	\N
23143	\N	285	1061	320	\N	1280	multibuy	2	570	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.612858+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:285:2026-11-18:320:multibuy:2:570	2	\N	\N
23144	\N	56	1062	2200	\N	1100	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.616901+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:56:2026-11-18:2200:none:0:0	2	\N	\N
23145	\N	332	1063	2900	\N	967	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.621342+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:332:2026-11-18:2900:none:0:0	2	\N	\N
23146	\N	334	1064	1500	\N	793	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:03.625733+00	2026-11-18 21:45:03.512711+00	accepted	scrape:chain2:334:2026-11-18:1500:none:0:0	2	\N	\N
23168	\N	37	1086	870	1450	435	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:06.400753+00	2026-11-18 21:45:06.394389+00	accepted	scrape:chain2:37:2026-11-18:870:special:0:0	2	\N	\N
23169	\N	351	1087	870	1450	435	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:06.42829+00	2026-11-18 21:45:06.394389+00	accepted	scrape:chain2:351:2026-11-18:870:special:0:0	2	\N	\N
23170	\N	25	1088	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:06.439026+00	2026-11-18 21:45:06.394389+00	accepted	scrape:chain2:25:2026-11-18:360:none:0:0	2	\N	\N
23126	\N	11	1044	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.028749+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:11:2026-11-18:470:multibuy:2:790	2	\N	\N
23127	\N	14	1045	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.032838+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:14:2026-11-18:470:multibuy:2:790	2	\N	\N
23128	\N	15	1046	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.036763+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:15:2026-11-18:470:multibuy:2:790	2	\N	\N
23129	\N	18	1047	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.04106+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:18:2026-11-18:470:multibuy:2:790	2	\N	\N
23130	\N	5	1048	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.0448+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:5:2026-11-18:470:multibuy:2:790	2	\N	\N
23131	\N	274	1049	470	\N	940	multibuy	2	790	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:02.048926+00	2026-11-18 21:45:00.003691+00	accepted	scrape:chain2:274:2026-11-18:470:multibuy:2:790	2	\N	\N
23147	\N	58	1065	1200	\N	1200	multibuy	2	1600	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.272874+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:58:2026-11-18:1200:multibuy:2:1600	2	\N	\N
23148	\N	342	1066	1200	\N	1200	multibuy	2	1600	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.292828+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:342:2026-11-18:1200:multibuy:2:1600	2	\N	\N
23149	\N	343	1067	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.298406+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:343:2026-11-18:1000:none:0:0	2	\N	\N
23150	\N	59	1068	1200	\N	1200	multibuy	2	1600	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.302404+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:59:2026-11-18:1200:multibuy:2:1600	2	\N	\N
23151	\N	344	1069	1700	\N	680	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.307397+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:344:2026-11-18:1700:none:0:0	2	\N	\N
23152	\N	300	1070	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.31103+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:300:2026-11-18:1000:none:0:0	2	\N	\N
23153	\N	57	1071	1200	\N	1200	multibuy	2	1600	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.315321+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:57:2026-11-18:1200:multibuy:2:1600	2	\N	\N
23154	\N	292	1072	1000	\N	500	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.319081+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:292:2026-11-18:1000:none:0:0	2	\N	\N
23155	\N	345	1073	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.324078+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:345:2026-11-18:440:none:0:0	2	\N	\N
23156	\N	314	1074	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.328049+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:314:2026-11-18:265:none:0:0	2	\N	\N
23157	\N	301	1075	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.332258+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:301:2026-11-18:440:none:0:0	2	\N	\N
23158	\N	346	1076	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.337195+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:346:2026-11-18:265:none:0:0	2	\N	\N
23159	\N	347	1077	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.343088+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:347:2026-11-18:265:none:0:0	2	\N	\N
23160	\N	297	1078	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.347007+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:297:2026-11-18:265:none:0:0	2	\N	\N
23161	\N	60	1079	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.351156+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:60:2026-11-18:440:none:0:0	2	\N	\N
23162	\N	348	1080	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.356034+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:348:2026-11-18:265:none:0:0	2	\N	\N
23163	\N	336	1081	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.360127+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:336:2026-11-18:440:none:0:0	2	\N	\N
23164	\N	299	1082	265	\N	1060	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.364065+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:299:2026-11-18:265:none:0:0	2	\N	\N
23165	\N	349	1083	350	\N	1000	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.369301+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:349:2026-11-18:350:none:0:0	2	\N	\N
23166	\N	350	1084	200	265	800	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.373981+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:350:2026-11-18:200:special:0:0	2	\N	\N
23167	\N	295	1085	440	\N	880	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:05.378061+00	2026-11-18 21:45:05.266594+00	accepted	scrape:chain2:295:2026-11-18:440:none:0:0	2	\N	\N
23174	\N	353	1092	900	\N	450	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:07.949014+00	2026-11-18 21:45:07.946303+00	accepted	scrape:chain2:353:2026-11-18:900:none:0:0	2	\N	\N
23175	\N	354	1093	275	\N	550	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:07.954903+00	2026-11-18 21:45:07.946303+00	accepted	scrape:chain2:354:2026-11-18:275:none:0:0	2	\N	\N
23195	\N	317	1094	440	550	587	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.067239+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:317:2026-11-18:440:special:0:0	2	\N	\N
23196	\N	315	1095	770	\N	385	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.071492+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:315:2026-11-18:770:none:0:0	2	\N	\N
23198	\N	319	1097	430	\N	860	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.079404+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:319:2026-11-18:430:none:0:0	2	\N	\N
23199	\N	318	1098	430	\N	860	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.083707+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:318:2026-11-18:430:none:0:0	2	\N	\N
23202	\N	321	1101	440	550	587	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.095251+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:321:2026-11-18:440:special:0:0	2	\N	\N
23205	\N	316	1104	440	550	587	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.106601+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:316:2026-11-18:440:special:0:0	2	\N	\N
23209	\N	319	1108	465	\N	930	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.122526+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:319:2026-11-18:465:none:0:0	2	\N	\N
23212	\N	355	1111	405	\N	1688	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:11.134593+00	2026-11-18 21:45:11.065558+00	accepted	scrape:chain2:355:2026-11-18:405:none:0:0	2	\N	\N
23171	\N	28	1089	360	\N	720	none	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:06.44359+00	2026-11-18 21:45:06.394389+00	accepted	scrape:chain2:28:2026-11-18:360:none:0:0	2	\N	\N
23172	\N	352	1090	290	360	580	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:06.448879+00	2026-11-18 21:45:06.394389+00	accepted	scrape:chain2:352:2026-11-18:290:special:0:0	2	\N	\N
23173	\N	27	1091	290	360	580	special	\N	\N	t	scrape	chain	\N	\N	\N	2026-11-18 21:45:06.453237+00	2026-11-18 21:45:06.394389+00	accepted	scrape:chain2:27:2026-11-18:290:special:0:0	2	\N	\N
23213	554	2	2	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.328523+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:2:2026-11-19:579:none:0:0	3	\N	\N
23214	554	3	3	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.335703+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:3:2026-11-19:329:special:0:0	3	\N	\N
23215	554	4	4	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.342601+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:4:2026-11-19:875:special:0:0	3	\N	\N
23216	554	5	5	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.349061+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:5:2026-11-19:329:special:0:0	3	\N	\N
23217	554	6	6	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.354574+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:6:2026-11-19:459:none:0:0	3	\N	\N
23218	554	7	7	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.359798+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:7:2026-11-19:299:special:0:0	3	\N	\N
23219	554	8	8	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.364092+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:8:2026-11-19:299:special:0:0	3	\N	\N
23220	554	9	9	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.368007+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:9:2026-11-19:399:none:0:0	3	\N	\N
23221	554	10	10	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.37162+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:10:2026-11-19:399:none:0:0	3	\N	\N
23222	554	11	11	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.375874+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:11:2026-11-19:329:special:0:0	3	\N	\N
23223	554	12	12	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.380041+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:12:2026-11-19:449:none:0:0	3	\N	\N
23224	554	13	13	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.384437+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:13:2026-11-19:329:special:0:0	3	\N	\N
23225	554	14	14	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.388945+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:14:2026-11-19:329:special:0:0	3	\N	\N
23226	554	15	15	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.393201+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:15:2026-11-19:329:special:0:0	3	\N	\N
23227	554	16	16	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.397251+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:16:2026-11-19:329:special:0:0	3	\N	\N
23228	554	17	17	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.401344+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:17:2026-11-19:329:special:0:0	3	\N	\N
23229	554	18	18	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.405208+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:18:2026-11-19:329:special:0:0	3	\N	\N
23230	554	19	19	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.410078+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:19:2026-11-19:449:none:0:0	3	\N	\N
23231	554	20	20	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.41415+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:20:2026-11-19:329:special:0:0	3	\N	\N
23232	554	21	21	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.418166+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:21:2026-11-19:329:special:0:0	3	\N	\N
23233	554	22	22	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.421767+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:22:2026-11-19:329:special:0:0	3	\N	\N
23234	554	23	23	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.425541+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:23:2026-11-19:359:special:0:0	3	\N	\N
23235	554	24	24	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.429074+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:24:2026-11-19:359:special:0:0	3	\N	\N
23236	554	25	25	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.432881+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:25:2026-11-19:359:special:0:0	3	\N	\N
23237	554	26	26	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.436891+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:26:2026-11-19:359:special:0:0	3	\N	\N
23238	554	27	27	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.441201+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:27:2026-11-19:359:special:0:0	3	\N	\N
23239	554	28	28	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.444954+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:28:2026-11-19:449:none:0:0	3	\N	\N
23240	554	328	29	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.449322+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:328:2026-11-19:479:none:0:0	3	\N	\N
23241	554	329	30	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.453388+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:329:2026-11-19:299:special:0:0	3	\N	\N
23242	554	330	31	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.457427+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:330:2026-11-19:459:none:0:0	3	\N	\N
23243	554	331	1	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.461458+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:331:2026-11-19:579:none:0:0	3	\N	\N
23244	554	32	32	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.465298+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:32:2026-11-19:299:special:0:0	3	\N	\N
23245	554	33	33	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.468864+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:33:2026-11-19:299:special:0:0	3	\N	\N
23246	554	34	34	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.472626+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:34:2026-11-19:579:none:0:0	3	\N	\N
23247	554	35	35	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.476169+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:35:2026-11-19:299:special:0:0	3	\N	\N
23248	554	36	36	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:57.479887+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:36:2026-11-19:579:none:0:0	3	\N	\N
23249	554	37	37	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.692439+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:37:2026-11-19:1449:none:0:0	3	\N	\N
23250	554	38	38	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.702745+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:38:2026-11-19:875:special:0:0	3	\N	\N
23251	554	39	39	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.709609+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:39:2026-11-19:875:special:0:0	3	\N	\N
23252	554	40	40	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.715507+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:40:2026-11-19:875:special:0:0	3	\N	\N
23253	554	356	41	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.721933+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:356:2026-11-19:1449:none:0:0	3	\N	\N
23254	554	41	42	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.731443+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:41:2026-11-19:999:special:0:0	3	\N	\N
23255	554	42	43	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.735416+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:42:2026-11-19:999:special:0:0	3	\N	\N
23256	554	43	44	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.739658+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:43:2026-11-19:875:special:0:0	3	\N	\N
23257	554	44	45	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.743605+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:44:2026-11-19:875:special:0:0	3	\N	\N
23258	554	45	46	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.747755+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:45:2026-11-19:1449:none:0:0	3	\N	\N
23259	554	46	47	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.751507+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:46:2026-11-19:1449:none:0:0	3	\N	\N
23260	554	47	48	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.755092+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:47:2026-11-19:1549:none:0:0	3	\N	\N
23261	554	48	49	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.758971+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:48:2026-11-19:1549:none:0:0	3	\N	\N
23262	554	49	50	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.76255+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:49:2026-11-19:875:special:0:0	3	\N	\N
23263	554	50	51	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.766459+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:50:2026-11-19:1449:none:0:0	3	\N	\N
23264	554	332	52	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.770539+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:332:2026-11-19:2799:special:0:0	3	\N	\N
23265	554	333	53	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.774721+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:333:2026-11-19:999:special:0:0	3	\N	\N
23266	554	334	54	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.778625+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:334:2026-11-19:1599:special:0:0	3	\N	\N
23267	554	335	55	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.783444+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:335:2026-11-19:2599:none:0:0	3	\N	\N
23268	554	55	56	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.787123+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:55:2026-11-19:1599:special:0:0	3	\N	\N
23269	554	56	57	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.7913+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:56:2026-11-19:2599:none:0:0	3	\N	\N
23270	554	57	58	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.794979+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:57:2026-11-19:1199:none:0:0	3	\N	\N
23271	554	58	59	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.798827+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:58:2026-11-19:1199:none:0:0	3	\N	\N
23272	554	59	60	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:08:58.802292+00	2026-11-19 02:08:56.498467+00	accepted	scrape:store554:59:2026-11-19:1199:none:0:0	3	\N	\N
23334	556	11	122	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.297118+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:11:2026-11-19:329:special:0:0	3	\N	\N
23335	556	12	123	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.301479+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:12:2026-11-19:449:none:0:0	3	\N	\N
23336	556	14	124	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.30517+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:14:2026-11-19:329:special:0:0	3	\N	\N
23337	556	3	125	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.309021+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:3:2026-11-19:329:special:0:0	3	\N	\N
23338	556	16	126	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.312873+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:16:2026-11-19:329:special:0:0	3	\N	\N
23339	556	17	127	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.317016+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:17:2026-11-19:329:special:0:0	3	\N	\N
23340	556	18	128	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.32102+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:18:2026-11-19:329:special:0:0	3	\N	\N
23341	556	49	129	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.324915+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:49:2026-11-19:329:special:0:0	3	\N	\N
23342	556	21	130	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.328692+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:21:2026-11-19:329:special:0:0	3	\N	\N
23343	556	4	131	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.332455+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:4:2026-11-19:875:special:0:0	3	\N	\N
23344	556	67	132	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.336192+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:67:2026-11-19:329:special:0:0	3	\N	\N
23345	556	61	133	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.340798+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:61:2026-11-19:329:special:0:0	3	\N	\N
23346	556	5	134	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.344479+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:5:2026-11-19:329:special:0:0	3	\N	\N
23347	556	23	135	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.34934+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:23:2026-11-19:359:special:0:0	3	\N	\N
23348	556	24	136	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.353032+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:24:2026-11-19:359:special:0:0	3	\N	\N
23349	556	25	137	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.356773+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:25:2026-11-19:359:special:0:0	3	\N	\N
23350	556	26	138	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.360455+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:26:2026-11-19:359:special:0:0	3	\N	\N
23351	556	68	139	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.364359+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:68:2026-11-19:359:special:0:0	3	\N	\N
23352	556	62	140	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.368153+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:62:2026-11-19:359:special:0:0	3	\N	\N
23353	556	27	141	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.372125+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:27:2026-11-19:359:special:0:0	3	\N	\N
23354	556	28	142	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.375939+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:28:2026-11-19:449:none:0:0	3	\N	\N
23355	556	328	143	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.380562+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:328:2026-11-19:479:none:0:0	3	\N	\N
23356	556	329	144	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.384996+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:329:2026-11-19:299:special:0:0	3	\N	\N
23357	556	330	145	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.389256+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:330:2026-11-19:459:none:0:0	3	\N	\N
23358	556	32	146	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.393394+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:32:2026-11-19:299:special:0:0	3	\N	\N
23359	556	34	147	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.397369+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:34:2026-11-19:579:none:0:0	3	\N	\N
23360	556	7	148	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.401094+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:7:2026-11-19:299:special:0:0	3	\N	\N
23361	556	2	149	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.404793+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:2:2026-11-19:579:none:0:0	3	\N	\N
23362	556	63	150	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.408433+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:63:2026-11-19:579:none:0:0	3	\N	\N
23363	556	64	151	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.41256+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:64:2026-11-19:479:none:0:0	3	\N	\N
23364	556	65	152	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.416182+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:65:2026-11-19:579:none:0:0	3	\N	\N
23365	556	66	153	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.419994+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:66:2026-11-19:299:special:0:0	3	\N	\N
23366	556	69	154	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.423565+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:69:2026-11-19:579:none:0:0	3	\N	\N
23367	556	70	155	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.427658+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:70:2026-11-19:299:special:0:0	3	\N	\N
23368	556	71	156	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:03.431407+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:71:2026-11-19:579:none:0:0	3	\N	\N
23369	556	45	157	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.487246+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:45:2026-11-19:1449:none:0:0	3	\N	\N
23273	555	10	61	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.285351+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:10:2026-11-19:399:none:0:0	3	\N	\N
23274	555	5	62	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.290355+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:5:2026-11-19:329:special:0:0	3	\N	\N
23275	555	60	63	439	\N	878	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.29463+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:60:2026-11-19:439:none:0:0	3	\N	\N
23276	555	9	64	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.300191+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:9:2026-11-19:399:none:0:0	3	\N	\N
23277	555	11	65	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.304463+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:11:2026-11-19:329:special:0:0	3	\N	\N
23278	555	12	66	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.308751+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:12:2026-11-19:449:none:0:0	3	\N	\N
23279	555	13	67	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.312708+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:13:2026-11-19:329:special:0:0	3	\N	\N
23280	555	14	68	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.31741+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:14:2026-11-19:329:special:0:0	3	\N	\N
23281	555	15	69	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.321583+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:15:2026-11-19:329:special:0:0	3	\N	\N
23282	555	3	70	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.325689+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:3:2026-11-19:329:special:0:0	3	\N	\N
23283	555	16	71	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.330246+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:16:2026-11-19:329:special:0:0	3	\N	\N
23284	555	17	72	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.33437+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:17:2026-11-19:329:special:0:0	3	\N	\N
23285	555	18	73	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.338315+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:18:2026-11-19:329:special:0:0	3	\N	\N
23286	555	19	74	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.342444+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:19:2026-11-19:449:none:0:0	3	\N	\N
23287	555	20	75	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.347159+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:20:2026-11-19:329:special:0:0	3	\N	\N
23288	555	49	76	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.351297+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:49:2026-11-19:329:special:0:0	3	\N	\N
23289	555	21	77	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.355305+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:21:2026-11-19:329:special:0:0	3	\N	\N
23290	555	4	78	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.359246+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:4:2026-11-19:875:special:0:0	3	\N	\N
23291	555	22	79	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.363414+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:22:2026-11-19:329:special:0:0	3	\N	\N
23292	555	61	80	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.36764+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:61:2026-11-19:329:special:0:0	3	\N	\N
23293	555	23	81	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.37143+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:23:2026-11-19:359:special:0:0	3	\N	\N
23294	555	25	82	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.375423+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:25:2026-11-19:359:special:0:0	3	\N	\N
23295	555	26	83	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.379231+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:26:2026-11-19:359:special:0:0	3	\N	\N
23296	555	62	84	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.383625+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:62:2026-11-19:359:special:0:0	3	\N	\N
23297	555	328	85	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.388072+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:328:2026-11-19:479:none:0:0	3	\N	\N
23298	555	329	86	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.393022+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:329:2026-11-19:299:special:0:0	3	\N	\N
23299	555	330	87	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.397498+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:330:2026-11-19:459:none:0:0	3	\N	\N
23300	555	331	88	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.403314+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:331:2026-11-19:579:none:0:0	3	\N	\N
23301	555	32	89	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.407551+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:32:2026-11-19:299:special:0:0	3	\N	\N
23302	555	33	90	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.411676+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:33:2026-11-19:299:special:0:0	3	\N	\N
23303	555	6	91	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.415715+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:6:2026-11-19:459:none:0:0	3	\N	\N
23304	555	34	92	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.419922+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:34:2026-11-19:579:none:0:0	3	\N	\N
23305	555	7	93	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.424038+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:7:2026-11-19:299:special:0:0	3	\N	\N
23306	555	2	94	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.428165+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:2:2026-11-19:579:none:0:0	3	\N	\N
23307	555	63	95	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.43212+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:63:2026-11-19:579:none:0:0	3	\N	\N
23308	555	64	96	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.435996+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:64:2026-11-19:479:none:0:0	3	\N	\N
23309	555	8	97	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.440227+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:8:2026-11-19:299:special:0:0	3	\N	\N
23310	555	65	98	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.44449+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:65:2026-11-19:579:none:0:0	3	\N	\N
23311	555	66	99	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:00.44873+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:66:2026-11-19:299:special:0:0	3	\N	\N
23312	555	37	100	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.480684+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:37:2026-11-19:1449:none:0:0	3	\N	\N
23313	555	40	101	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.485076+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:40:2026-11-19:875:special:0:0	3	\N	\N
23314	555	43	102	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.489326+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:43:2026-11-19:875:special:0:0	3	\N	\N
23315	555	39	103	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.493164+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:39:2026-11-19:875:special:0:0	3	\N	\N
23316	555	38	104	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.497241+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:38:2026-11-19:875:special:0:0	3	\N	\N
23317	555	45	105	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.500803+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:45:2026-11-19:1449:none:0:0	3	\N	\N
23318	555	46	106	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.504394+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:46:2026-11-19:1449:none:0:0	3	\N	\N
23319	555	57	108	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.507707+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:57:2026-11-19:1199:none:0:0	3	\N	\N
23320	555	47	109	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.511348+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:47:2026-11-19:1549:none:0:0	3	\N	\N
23321	555	49	110	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.515051+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:49:2026-11-19:875:special:0:0	3	\N	\N
23322	555	44	111	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.519108+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:44:2026-11-19:875:special:0:0	3	\N	\N
23323	555	356	107	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.522749+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:356:2026-11-19:1449:none:0:0	3	\N	\N
23324	555	50	112	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.527452+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:50:2026-11-19:1449:none:0:0	3	\N	\N
23325	555	332	113	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.531513+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:332:2026-11-19:2799:special:0:0	3	\N	\N
23326	555	333	114	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.53559+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:333:2026-11-19:999:special:0:0	3	\N	\N
23327	555	334	115	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.539878+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:334:2026-11-19:1599:special:0:0	3	\N	\N
23328	555	335	116	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.543888+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:335:2026-11-19:2599:none:0:0	3	\N	\N
23329	555	42	117	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.547823+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:42:2026-11-19:999:special:0:0	3	\N	\N
23330	555	41	118	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.551472+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:41:2026-11-19:999:special:0:0	3	\N	\N
23331	555	55	119	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.554846+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:55:2026-11-19:1599:special:0:0	3	\N	\N
23332	555	58	120	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.558444+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:58:2026-11-19:1199:none:0:0	3	\N	\N
23333	555	59	121	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:01.562081+00	2026-11-19 02:09:00.283234+00	accepted	scrape:store555:59:2026-11-19:1199:none:0:0	3	\N	\N
23389	558	9	177	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.302131+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:9:2026-11-19:399:none:0:0	3	\N	\N
23390	558	10	178	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.30639+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:10:2026-11-19:399:none:0:0	3	\N	\N
23391	558	11	179	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.310683+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:11:2026-11-19:329:special:0:0	3	\N	\N
23392	558	12	180	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.314772+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:12:2026-11-19:449:none:0:0	3	\N	\N
23393	558	14	181	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.318983+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:14:2026-11-19:329:special:0:0	3	\N	\N
23394	558	15	182	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.322978+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:15:2026-11-19:329:special:0:0	3	\N	\N
23395	558	3	183	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.328143+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:3:2026-11-19:329:special:0:0	3	\N	\N
23396	558	16	184	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.332258+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:16:2026-11-19:329:special:0:0	3	\N	\N
23397	558	17	185	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.336406+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:17:2026-11-19:329:special:0:0	3	\N	\N
23398	558	18	186	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.340526+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:18:2026-11-19:329:special:0:0	3	\N	\N
23399	558	19	187	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.34457+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:19:2026-11-19:449:none:0:0	3	\N	\N
23400	558	20	188	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.348511+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:20:2026-11-19:329:special:0:0	3	\N	\N
23401	558	21	189	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.352484+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:21:2026-11-19:329:special:0:0	3	\N	\N
23402	558	4	190	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.356241+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:4:2026-11-19:875:special:0:0	3	\N	\N
23403	558	22	191	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.360103+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:22:2026-11-19:329:special:0:0	3	\N	\N
23404	558	61	192	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.364024+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:61:2026-11-19:329:special:0:0	3	\N	\N
23405	558	23	193	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.367988+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:23:2026-11-19:359:special:0:0	3	\N	\N
23406	558	25	194	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.371449+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:25:2026-11-19:359:special:0:0	3	\N	\N
23407	558	26	195	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.375171+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:26:2026-11-19:359:special:0:0	3	\N	\N
23408	558	68	196	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.378865+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:68:2026-11-19:359:special:0:0	3	\N	\N
23409	558	62	197	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.382933+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:62:2026-11-19:359:special:0:0	3	\N	\N
23410	558	27	198	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.386713+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:27:2026-11-19:359:special:0:0	3	\N	\N
23411	558	28	199	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.390992+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:28:2026-11-19:449:none:0:0	3	\N	\N
23412	558	328	200	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.395171+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:328:2026-11-19:479:none:0:0	3	\N	\N
23413	558	329	201	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.399539+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:329:2026-11-19:299:special:0:0	3	\N	\N
23414	558	330	202	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.403518+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:330:2026-11-19:459:none:0:0	3	\N	\N
23415	558	331	203	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.407706+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:331:2026-11-19:579:none:0:0	3	\N	\N
23416	558	32	204	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.411297+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:32:2026-11-19:299:special:0:0	3	\N	\N
23417	558	33	205	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.415329+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:33:2026-11-19:299:special:0:0	3	\N	\N
23418	558	6	206	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.418885+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:6:2026-11-19:459:none:0:0	3	\N	\N
23419	558	34	207	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.423972+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:34:2026-11-19:579:none:0:0	3	\N	\N
23420	558	7	208	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.427585+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:7:2026-11-19:299:special:0:0	3	\N	\N
23421	558	2	209	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.431469+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:2:2026-11-19:579:none:0:0	3	\N	\N
23422	558	35	210	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.435133+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:35:2026-11-19:299:special:0:0	3	\N	\N
23423	558	36	211	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.439265+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:36:2026-11-19:579:none:0:0	3	\N	\N
23370	556	43	158	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.506073+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:43:2026-11-19:875:special:0:0	3	\N	\N
23371	556	40	159	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.527125+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:40:2026-11-19:875:special:0:0	3	\N	\N
23372	556	39	160	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.53574+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:39:2026-11-19:875:special:0:0	3	\N	\N
23373	556	38	161	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.542374+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:38:2026-11-19:875:special:0:0	3	\N	\N
23374	556	47	162	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.54798+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:47:2026-11-19:1549:none:0:0	3	\N	\N
23375	556	48	163	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.55299+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:48:2026-11-19:1549:none:0:0	3	\N	\N
23376	556	49	164	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.557176+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:49:2026-11-19:875:special:0:0	3	\N	\N
23377	556	44	165	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.561349+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:44:2026-11-19:875:special:0:0	3	\N	\N
23378	556	46	166	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.565068+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:46:2026-11-19:1449:none:0:0	3	\N	\N
23379	556	37	167	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.568783+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:37:2026-11-19:1449:none:0:0	3	\N	\N
23380	556	356	168	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.572492+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:356:2026-11-19:1449:none:0:0	3	\N	\N
23381	556	50	169	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.576388+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:50:2026-11-19:1449:none:0:0	3	\N	\N
23382	556	334	170	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.580389+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:334:2026-11-19:1599:special:0:0	3	\N	\N
23383	556	335	171	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.584884+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:335:2026-11-19:2599:none:0:0	3	\N	\N
23384	556	42	172	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.58899+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:42:2026-11-19:999:special:0:0	3	\N	\N
23385	556	41	173	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.592926+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:41:2026-11-19:999:special:0:0	3	\N	\N
23386	556	55	174	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.596658+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:55:2026-11-19:1599:special:0:0	3	\N	\N
23387	556	56	175	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.600517+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:56:2026-11-19:2599:none:0:0	3	\N	\N
23388	556	57	176	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:04.604196+00	2026-11-19 02:09:03.295532+00	accepted	scrape:store556:57:2026-11-19:1199:none:0:0	3	\N	\N
23450	561	9	238	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.509818+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:9:2026-11-19:399:none:0:0	3	\N	\N
23451	561	10	239	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.519321+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:10:2026-11-19:399:none:0:0	3	\N	\N
23452	561	11	240	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.526151+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:11:2026-11-19:329:special:0:0	3	\N	\N
23453	561	13	241	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.532034+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:13:2026-11-19:329:special:0:0	3	\N	\N
23454	561	14	242	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.536875+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:14:2026-11-19:329:special:0:0	3	\N	\N
23455	561	15	243	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.54123+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:15:2026-11-19:329:special:0:0	3	\N	\N
23456	561	3	244	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.544986+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:3:2026-11-19:329:special:0:0	3	\N	\N
23457	561	16	245	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.548991+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:16:2026-11-19:329:special:0:0	3	\N	\N
23458	561	18	246	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.552595+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:18:2026-11-19:329:special:0:0	3	\N	\N
23459	561	19	247	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.556397+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:19:2026-11-19:449:none:0:0	3	\N	\N
23460	561	20	248	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.560129+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:20:2026-11-19:329:special:0:0	3	\N	\N
23461	561	21	249	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.564034+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:21:2026-11-19:329:special:0:0	3	\N	\N
23462	561	4	250	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.567716+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:4:2026-11-19:875:special:0:0	3	\N	\N
23463	561	22	251	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.571474+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:22:2026-11-19:329:special:0:0	3	\N	\N
23464	561	61	252	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.575277+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:61:2026-11-19:329:special:0:0	3	\N	\N
23465	561	5	253	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.579272+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:5:2026-11-19:329:special:0:0	3	\N	\N
23466	561	323	254	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.58318+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:323:2026-11-19:329:special:0:0	3	\N	\N
23467	561	23	255	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.588388+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:23:2026-11-19:359:special:0:0	3	\N	\N
23468	561	25	256	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.591993+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:25:2026-11-19:359:special:0:0	3	\N	\N
23469	561	68	257	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.595812+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:68:2026-11-19:359:special:0:0	3	\N	\N
23470	561	27	258	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.599477+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:27:2026-11-19:359:special:0:0	3	\N	\N
23471	561	28	259	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.603187+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:28:2026-11-19:449:none:0:0	3	\N	\N
23472	561	328	260	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.607032+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:328:2026-11-19:479:none:0:0	3	\N	\N
23473	561	329	261	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.611021+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:329:2026-11-19:299:special:0:0	3	\N	\N
23474	561	330	262	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.614932+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:330:2026-11-19:459:none:0:0	3	\N	\N
23475	561	331	263	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.619004+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:331:2026-11-19:579:none:0:0	3	\N	\N
23476	561	32	264	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.622629+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:32:2026-11-19:299:special:0:0	3	\N	\N
23477	561	33	265	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.626346+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:33:2026-11-19:299:special:0:0	3	\N	\N
23478	561	6	266	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.629875+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:6:2026-11-19:459:none:0:0	3	\N	\N
23424	558	63	212	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.442918+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:63:2026-11-19:579:none:0:0	3	\N	\N
23425	558	64	213	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.446725+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:64:2026-11-19:479:none:0:0	3	\N	\N
23426	558	8	214	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.450505+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:8:2026-11-19:299:special:0:0	3	\N	\N
23427	558	65	215	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.454548+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:65:2026-11-19:579:none:0:0	3	\N	\N
23428	558	66	216	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.458206+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:66:2026-11-19:299:special:0:0	3	\N	\N
23429	558	69	217	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:06.462135+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:69:2026-11-19:579:none:0:0	3	\N	\N
23430	558	43	218	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.597105+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:43:2026-11-19:875:special:0:0	3	\N	\N
23431	558	40	219	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.601419+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:40:2026-11-19:875:special:0:0	3	\N	\N
23432	558	39	220	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.604973+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:39:2026-11-19:875:special:0:0	3	\N	\N
23433	558	38	221	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.608675+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:38:2026-11-19:875:special:0:0	3	\N	\N
23434	558	47	222	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.612363+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:47:2026-11-19:1549:none:0:0	3	\N	\N
23435	558	48	223	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.616394+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:48:2026-11-19:1549:none:0:0	3	\N	\N
23436	558	49	224	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.620002+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:49:2026-11-19:875:special:0:0	3	\N	\N
23437	558	44	225	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.623625+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:44:2026-11-19:875:special:0:0	3	\N	\N
23438	558	45	226	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.627263+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:45:2026-11-19:1449:none:0:0	3	\N	\N
23439	558	46	227	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.631138+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:46:2026-11-19:1449:none:0:0	3	\N	\N
23440	558	37	228	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.634707+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:37:2026-11-19:1449:none:0:0	3	\N	\N
23441	558	356	229	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.638775+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:356:2026-11-19:1449:none:0:0	3	\N	\N
23442	558	50	230	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.642482+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:50:2026-11-19:1449:none:0:0	3	\N	\N
23443	558	332	231	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.647921+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:332:2026-11-19:2799:special:0:0	3	\N	\N
23444	558	333	232	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.651837+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:333:2026-11-19:999:special:0:0	3	\N	\N
23445	558	334	233	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.655796+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:334:2026-11-19:1599:special:0:0	3	\N	\N
23446	558	42	234	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.659172+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:42:2026-11-19:999:special:0:0	3	\N	\N
23447	558	57	235	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.663087+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:57:2026-11-19:1199:none:0:0	3	\N	\N
23448	558	58	236	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.666696+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:58:2026-11-19:1199:none:0:0	3	\N	\N
23449	558	59	237	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:08.670616+00	2026-11-19 02:09:06.300674+00	accepted	scrape:store558:59:2026-11-19:1199:none:0:0	3	\N	\N
23511	562	4	299	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.485441+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:4:2026-11-19:875:special:0:0	3	\N	\N
23512	562	49	300	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.498765+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:49:2026-11-19:329:special:0:0	3	\N	\N
23513	562	13	301	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.507206+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:13:2026-11-19:329:special:0:0	3	\N	\N
23514	562	17	302	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.513345+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:17:2026-11-19:329:special:0:0	3	\N	\N
23515	562	21	303	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.520263+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:21:2026-11-19:329:special:0:0	3	\N	\N
23516	562	323	304	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.524822+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:323:2026-11-19:329:special:0:0	3	\N	\N
23517	562	27	305	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.528858+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:27:2026-11-19:359:special:0:0	3	\N	\N
23518	562	11	306	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.532803+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:11:2026-11-19:329:special:0:0	3	\N	\N
23519	562	12	307	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.53672+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:12:2026-11-19:449:none:0:0	3	\N	\N
23520	562	14	308	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.540701+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:14:2026-11-19:329:special:0:0	3	\N	\N
23521	562	15	309	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.544753+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:15:2026-11-19:329:special:0:0	3	\N	\N
23522	562	3	310	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.548558+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:3:2026-11-19:329:special:0:0	3	\N	\N
23523	562	18	311	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.552408+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:18:2026-11-19:329:special:0:0	3	\N	\N
23524	562	19	312	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.556316+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:19:2026-11-19:449:none:0:0	3	\N	\N
23525	562	20	313	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.560163+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:20:2026-11-19:329:special:0:0	3	\N	\N
23526	562	67	314	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.563975+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:67:2026-11-19:329:special:0:0	3	\N	\N
23527	562	61	315	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.567912+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:61:2026-11-19:329:special:0:0	3	\N	\N
23528	562	5	316	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.571648+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:5:2026-11-19:329:special:0:0	3	\N	\N
23529	562	24	317	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.575279+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:24:2026-11-19:359:special:0:0	3	\N	\N
23530	562	25	318	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.579002+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:25:2026-11-19:359:special:0:0	3	\N	\N
23531	562	26	319	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.583217+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:26:2026-11-19:359:special:0:0	3	\N	\N
23532	562	68	320	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.58707+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:68:2026-11-19:359:special:0:0	3	\N	\N
23479	561	34	267	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.633852+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:34:2026-11-19:579:none:0:0	3	\N	\N
23480	561	7	268	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.638089+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:7:2026-11-19:299:special:0:0	3	\N	\N
23481	561	2	269	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.642012+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:2:2026-11-19:579:none:0:0	3	\N	\N
23482	561	35	270	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.645679+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:35:2026-11-19:299:special:0:0	3	\N	\N
23483	561	36	271	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.649457+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:36:2026-11-19:579:none:0:0	3	\N	\N
23484	561	63	272	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.652976+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:63:2026-11-19:579:none:0:0	3	\N	\N
23485	561	64	273	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.656582+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:64:2026-11-19:479:none:0:0	3	\N	\N
23486	561	8	274	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:09.660084+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:8:2026-11-19:299:special:0:0	3	\N	\N
23487	561	43	275	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.697279+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:43:2026-11-19:875:special:0:0	3	\N	\N
23488	561	40	276	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.701495+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:40:2026-11-19:875:special:0:0	3	\N	\N
23489	561	39	277	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.705792+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:39:2026-11-19:875:special:0:0	3	\N	\N
23490	561	38	278	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.709839+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:38:2026-11-19:875:special:0:0	3	\N	\N
23491	561	47	279	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.716071+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:47:2026-11-19:1549:none:0:0	3	\N	\N
23492	561	48	280	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.719973+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:48:2026-11-19:1549:none:0:0	3	\N	\N
23493	561	49	281	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.723728+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:49:2026-11-19:875:special:0:0	3	\N	\N
23494	561	44	282	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.727224+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:44:2026-11-19:875:special:0:0	3	\N	\N
23495	561	45	283	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.730976+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:45:2026-11-19:1449:none:0:0	3	\N	\N
23496	561	46	284	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.734457+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:46:2026-11-19:1449:none:0:0	3	\N	\N
23497	561	37	285	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.738625+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:37:2026-11-19:1449:none:0:0	3	\N	\N
23498	561	356	286	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.742348+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:356:2026-11-19:1449:none:0:0	3	\N	\N
23499	561	50	287	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.746231+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:50:2026-11-19:1449:none:0:0	3	\N	\N
23500	561	332	288	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.750318+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:332:2026-11-19:2799:special:0:0	3	\N	\N
23501	561	333	289	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.75459+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:333:2026-11-19:999:special:0:0	3	\N	\N
23502	561	334	290	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.758498+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:334:2026-11-19:1599:special:0:0	3	\N	\N
23503	561	335	291	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.762592+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:335:2026-11-19:2599:none:0:0	3	\N	\N
23504	561	42	292	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.766331+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:42:2026-11-19:999:special:0:0	3	\N	\N
23505	561	41	293	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.770027+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:41:2026-11-19:999:special:0:0	3	\N	\N
23506	561	55	294	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.773456+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:55:2026-11-19:1599:special:0:0	3	\N	\N
23507	561	56	295	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.777073+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:56:2026-11-19:2599:none:0:0	3	\N	\N
23508	561	57	296	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.780726+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:57:2026-11-19:1199:none:0:0	3	\N	\N
23509	561	58	297	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.784817+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:58:2026-11-19:1199:none:0:0	3	\N	\N
23510	561	59	298	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:10.788887+00	2026-11-19 02:09:09.505855+00	accepted	scrape:store561:59:2026-11-19:1199:none:0:0	3	\N	\N
23573	563	21	361	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.477335+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:21:2026-11-19:329:special:0:0	3	\N	\N
23574	563	61	362	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.48706+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:61:2026-11-19:329:special:0:0	3	\N	\N
23575	563	11	363	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.492438+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:11:2026-11-19:329:special:0:0	3	\N	\N
23576	563	12	364	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.49667+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:12:2026-11-19:449:none:0:0	3	\N	\N
23577	563	13	365	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.500464+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:13:2026-11-19:329:special:0:0	3	\N	\N
23578	563	14	366	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.504463+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:14:2026-11-19:329:special:0:0	3	\N	\N
23579	563	15	367	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.508249+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:15:2026-11-19:329:special:0:0	3	\N	\N
23580	563	3	368	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.511983+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:3:2026-11-19:329:special:0:0	3	\N	\N
23581	563	16	369	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.515684+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:16:2026-11-19:329:special:0:0	3	\N	\N
23582	563	17	370	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.519539+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:17:2026-11-19:329:special:0:0	3	\N	\N
23583	563	18	371	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.523354+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:18:2026-11-19:329:special:0:0	3	\N	\N
23584	563	19	372	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.527163+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:19:2026-11-19:449:none:0:0	3	\N	\N
23585	563	20	373	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.531045+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:20:2026-11-19:329:special:0:0	3	\N	\N
23586	563	4	374	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.535937+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:4:2026-11-19:875:special:0:0	3	\N	\N
23587	563	22	375	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.540153+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:22:2026-11-19:329:special:0:0	3	\N	\N
23588	563	5	376	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.543922+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:5:2026-11-19:329:special:0:0	3	\N	\N
23533	562	62	321	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.591216+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:62:2026-11-19:359:special:0:0	3	\N	\N
23534	562	28	322	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.594938+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:28:2026-11-19:449:none:0:0	3	\N	\N
23535	562	328	323	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.599454+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:328:2026-11-19:479:none:0:0	3	\N	\N
23536	562	329	324	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.603522+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:329:2026-11-19:299:special:0:0	3	\N	\N
23537	562	330	325	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.60761+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:330:2026-11-19:459:none:0:0	3	\N	\N
23538	562	331	326	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.611426+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:331:2026-11-19:579:none:0:0	3	\N	\N
23539	562	32	327	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.616351+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:32:2026-11-19:299:special:0:0	3	\N	\N
23540	562	33	328	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.619996+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:33:2026-11-19:299:special:0:0	3	\N	\N
23541	562	6	329	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.623571+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:6:2026-11-19:459:none:0:0	3	\N	\N
23542	562	34	330	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.627044+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:34:2026-11-19:579:none:0:0	3	\N	\N
23543	562	7	331	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.630918+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:7:2026-11-19:299:special:0:0	3	\N	\N
23544	562	2	332	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.634506+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:2:2026-11-19:579:none:0:0	3	\N	\N
23545	562	35	333	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.638423+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:35:2026-11-19:299:special:0:0	3	\N	\N
23546	562	36	334	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.642038+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:36:2026-11-19:579:none:0:0	3	\N	\N
23547	562	63	335	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.645808+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:63:2026-11-19:579:none:0:0	3	\N	\N
23548	562	64	336	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.649366+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:64:2026-11-19:479:none:0:0	3	\N	\N
23549	562	8	337	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.653163+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:8:2026-11-19:299:special:0:0	3	\N	\N
23550	562	65	338	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.65687+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:65:2026-11-19:579:none:0:0	3	\N	\N
23551	562	66	339	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:12.660656+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:66:2026-11-19:299:special:0:0	3	\N	\N
23552	562	38	340	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.701819+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:38:2026-11-19:875:special:0:0	3	\N	\N
23553	562	39	341	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.720343+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:39:2026-11-19:875:special:0:0	3	\N	\N
23554	562	44	342	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.730255+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:44:2026-11-19:875:special:0:0	3	\N	\N
23555	562	40	343	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.73735+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:40:2026-11-19:875:special:0:0	3	\N	\N
23556	562	47	344	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.742975+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:47:2026-11-19:1549:none:0:0	3	\N	\N
23557	562	49	345	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.748287+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:49:2026-11-19:875:special:0:0	3	\N	\N
23558	562	43	346	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.752714+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:43:2026-11-19:875:special:0:0	3	\N	\N
23559	562	48	347	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.756956+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:48:2026-11-19:1549:none:0:0	3	\N	\N
23560	562	45	348	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.76071+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:45:2026-11-19:1449:none:0:0	3	\N	\N
23561	562	46	349	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.764513+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:46:2026-11-19:1449:none:0:0	3	\N	\N
23562	562	37	350	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.768044+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:37:2026-11-19:1449:none:0:0	3	\N	\N
23563	562	356	351	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.772906+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:356:2026-11-19:1449:none:0:0	3	\N	\N
23564	562	50	352	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.776455+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:50:2026-11-19:1449:none:0:0	3	\N	\N
23565	562	332	353	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.780438+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:332:2026-11-19:2799:special:0:0	3	\N	\N
23566	562	333	354	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.784752+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:333:2026-11-19:999:special:0:0	3	\N	\N
23567	562	334	355	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.789044+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:334:2026-11-19:1599:special:0:0	3	\N	\N
23568	562	335	356	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.793055+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:335:2026-11-19:2599:none:0:0	3	\N	\N
23569	562	42	357	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.796812+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:42:2026-11-19:999:special:0:0	3	\N	\N
23570	562	41	358	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.80024+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:41:2026-11-19:999:special:0:0	3	\N	\N
23571	562	55	359	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.803863+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:55:2026-11-19:1599:special:0:0	3	\N	\N
23572	562	56	360	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:13.807328+00	2026-11-19 02:09:12.479538+00	accepted	scrape:store562:56:2026-11-19:2599:none:0:0	3	\N	\N
23589	563	323	377	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.547849+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:323:2026-11-19:329:special:0:0	3	\N	\N
23590	563	23	378	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.551536+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:23:2026-11-19:359:special:0:0	3	\N	\N
23591	563	24	379	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.554995+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:24:2026-11-19:359:special:0:0	3	\N	\N
23592	563	25	380	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.558595+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:25:2026-11-19:359:special:0:0	3	\N	\N
23593	563	26	381	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.562366+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:26:2026-11-19:359:special:0:0	3	\N	\N
23594	563	68	382	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.566343+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:68:2026-11-19:359:special:0:0	3	\N	\N
23595	563	62	383	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.570113+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:62:2026-11-19:359:special:0:0	3	\N	\N
23596	563	27	384	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.574023+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:27:2026-11-19:359:special:0:0	3	\N	\N
23597	563	28	385	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.577623+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:28:2026-11-19:449:none:0:0	3	\N	\N
23598	563	328	386	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.581908+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:328:2026-11-19:479:none:0:0	3	\N	\N
23599	563	329	387	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.586167+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:329:2026-11-19:299:special:0:0	3	\N	\N
23600	563	330	388	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.590534+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:330:2026-11-19:459:none:0:0	3	\N	\N
23601	563	331	389	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.594485+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:331:2026-11-19:579:none:0:0	3	\N	\N
23602	563	32	390	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.598328+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:32:2026-11-19:299:special:0:0	3	\N	\N
23603	563	33	391	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.601903+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:33:2026-11-19:299:special:0:0	3	\N	\N
23604	563	6	392	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.605445+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:6:2026-11-19:459:none:0:0	3	\N	\N
23605	563	34	393	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.608891+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:34:2026-11-19:579:none:0:0	3	\N	\N
23606	563	7	394	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.612509+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:7:2026-11-19:299:special:0:0	3	\N	\N
23607	563	2	395	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.616081+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:2:2026-11-19:579:none:0:0	3	\N	\N
23608	563	35	396	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.61971+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:35:2026-11-19:299:special:0:0	3	\N	\N
23609	563	63	397	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.623133+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:63:2026-11-19:579:none:0:0	3	\N	\N
23610	563	64	398	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:15.627869+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:64:2026-11-19:479:none:0:0	3	\N	\N
23611	563	43	399	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.714043+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:43:2026-11-19:875:special:0:0	3	\N	\N
23612	563	42	400	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.7306+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:42:2026-11-19:999:special:0:0	3	\N	\N
23613	563	40	401	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.739423+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:40:2026-11-19:875:special:0:0	3	\N	\N
23614	563	39	402	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.743516+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:39:2026-11-19:875:special:0:0	3	\N	\N
23615	563	38	403	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.747261+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:38:2026-11-19:875:special:0:0	3	\N	\N
23616	563	47	404	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.751175+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:47:2026-11-19:1549:none:0:0	3	\N	\N
23617	563	48	405	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.754823+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:48:2026-11-19:1549:none:0:0	3	\N	\N
23618	563	49	406	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.758643+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:49:2026-11-19:875:special:0:0	3	\N	\N
23619	563	44	407	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.762474+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:44:2026-11-19:875:special:0:0	3	\N	\N
23620	563	45	408	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.766408+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:45:2026-11-19:1449:none:0:0	3	\N	\N
23621	563	46	409	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.770014+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:46:2026-11-19:1449:none:0:0	3	\N	\N
23622	563	37	410	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.7738+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:37:2026-11-19:1449:none:0:0	3	\N	\N
23623	563	356	411	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.777445+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:356:2026-11-19:1449:none:0:0	3	\N	\N
23624	563	50	412	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.781277+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:50:2026-11-19:1449:none:0:0	3	\N	\N
23625	563	332	413	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.785306+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:332:2026-11-19:2799:special:0:0	3	\N	\N
23626	563	333	414	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.789536+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:333:2026-11-19:999:special:0:0	3	\N	\N
23627	563	334	415	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.793572+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:334:2026-11-19:1599:special:0:0	3	\N	\N
23628	563	335	416	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.798046+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:335:2026-11-19:2599:none:0:0	3	\N	\N
23629	563	41	417	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.801828+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:41:2026-11-19:999:special:0:0	3	\N	\N
23630	563	55	418	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.805486+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:55:2026-11-19:1599:special:0:0	3	\N	\N
23631	563	56	419	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.808926+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:56:2026-11-19:2599:none:0:0	3	\N	\N
23632	563	57	420	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.812701+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:57:2026-11-19:1199:none:0:0	3	\N	\N
23633	563	58	421	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.816501+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:58:2026-11-19:1199:none:0:0	3	\N	\N
23634	563	59	422	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-19 02:09:16.821506+00	2026-11-19 02:09:15.472732+00	accepted	scrape:store563:59:2026-11-19:1199:none:0:0	3	\N	\N
1	554	1	1	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.809323+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:1:2026-11-18:579:none:0:0	3	\N	\N
2	554	2	2	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.81624+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:2:2026-11-18:579:none:0:0	3	\N	\N
3	554	3	3	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.820514+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:3:2026-11-18:329:special:0:0	3	\N	\N
4	554	4	4	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.82461+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:4:2026-11-18:875:special:0:0	3	\N	\N
5	554	5	5	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.828192+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:5:2026-11-18:329:special:0:0	3	\N	\N
6	554	6	6	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.831917+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:6:2026-11-18:459:none:0:0	3	\N	\N
7	554	7	7	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.834931+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:7:2026-11-18:299:special:0:0	3	\N	\N
8	554	8	8	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.838223+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:8:2026-11-18:299:special:0:0	3	\N	\N
9	554	9	9	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.841432+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:9:2026-11-18:399:none:0:0	3	\N	\N
10	554	10	10	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.844831+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:10:2026-11-18:399:none:0:0	3	\N	\N
11	554	11	11	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.848316+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:11:2026-11-18:329:special:0:0	3	\N	\N
12	554	12	12	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.851649+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:12:2026-11-18:449:none:0:0	3	\N	\N
13	554	13	13	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.854847+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:13:2026-11-18:329:special:0:0	3	\N	\N
14	554	14	14	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.857911+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:14:2026-11-18:329:special:0:0	3	\N	\N
15	554	15	15	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.861023+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:15:2026-11-18:329:special:0:0	3	\N	\N
16	554	16	16	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.86409+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:16:2026-11-18:329:special:0:0	3	\N	\N
17	554	17	17	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.867204+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:17:2026-11-18:329:special:0:0	3	\N	\N
18	554	18	18	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.870415+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:18:2026-11-18:329:special:0:0	3	\N	\N
19	554	19	19	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.873506+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:19:2026-11-18:449:none:0:0	3	\N	\N
20	554	20	20	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.876547+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:20:2026-11-18:329:special:0:0	3	\N	\N
21	554	21	21	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.879538+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:21:2026-11-18:329:special:0:0	3	\N	\N
22	554	22	22	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.882818+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:22:2026-11-18:329:special:0:0	3	\N	\N
23	554	23	23	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.885686+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:23:2026-11-18:359:special:0:0	3	\N	\N
24	554	24	24	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.888911+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:24:2026-11-18:359:special:0:0	3	\N	\N
25	554	25	25	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.891802+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:25:2026-11-18:359:special:0:0	3	\N	\N
26	554	26	26	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.894689+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:26:2026-11-18:359:special:0:0	3	\N	\N
27	554	27	27	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.897512+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:27:2026-11-18:359:special:0:0	3	\N	\N
28	554	28	28	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.900337+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:28:2026-11-18:449:none:0:0	3	\N	\N
29	554	29	29	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.903133+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:29:2026-11-18:479:none:0:0	3	\N	\N
30	554	30	30	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.906092+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:30:2026-11-18:299:special:0:0	3	\N	\N
31	554	31	31	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.908872+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:31:2026-11-18:459:none:0:0	3	\N	\N
32	554	32	32	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.911753+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:32:2026-11-18:299:special:0:0	3	\N	\N
33	554	33	33	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.9145+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:33:2026-11-18:299:special:0:0	3	\N	\N
34	554	34	34	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.917234+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:34:2026-11-18:579:none:0:0	3	\N	\N
35	554	35	35	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.920017+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:35:2026-11-18:299:special:0:0	3	\N	\N
36	554	36	36	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:47.922819+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:36:2026-11-18:579:none:0:0	3	\N	\N
37	554	37	37	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:48.99773+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:37:2026-11-18:1449:none:0:0	3	\N	\N
38	554	38	38	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.001118+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:38:2026-11-18:875:special:0:0	3	\N	\N
39	554	39	39	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.004209+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:39:2026-11-18:875:special:0:0	3	\N	\N
40	554	40	40	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.00743+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:40:2026-11-18:875:special:0:0	3	\N	\N
42	554	41	42	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.01252+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:41:2026-11-18:999:special:0:0	3	\N	\N
43	554	42	43	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.015389+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:42:2026-11-18:999:special:0:0	3	\N	\N
44	554	43	44	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.018245+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:43:2026-11-18:875:special:0:0	3	\N	\N
45	554	44	45	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.021146+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:44:2026-11-18:875:special:0:0	3	\N	\N
46	554	45	46	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.024016+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:45:2026-11-18:1449:none:0:0	3	\N	\N
47	554	46	47	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.026745+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:46:2026-11-18:1449:none:0:0	3	\N	\N
48	554	47	48	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.029705+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:47:2026-11-18:1549:none:0:0	3	\N	\N
49	554	48	49	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.032487+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:48:2026-11-18:1549:none:0:0	3	\N	\N
50	554	49	50	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.0353+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:49:2026-11-18:875:special:0:0	3	\N	\N
51	554	50	51	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.038378+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:50:2026-11-18:1449:none:0:0	3	\N	\N
52	554	51	52	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.041189+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:51:2026-11-18:2799:special:0:0	3	\N	\N
53	554	52	53	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.044168+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:52:2026-11-18:999:special:0:0	3	\N	\N
54	554	53	54	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.047207+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:53:2026-11-18:1599:special:0:0	3	\N	\N
55	554	54	55	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.050195+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:54:2026-11-18:2599:none:0:0	3	\N	\N
56	554	55	56	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.053055+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:55:2026-11-18:1599:special:0:0	3	\N	\N
57	554	56	57	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.05583+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:56:2026-11-18:2599:none:0:0	3	\N	\N
58	554	57	58	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.058584+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:57:2026-11-18:1199:none:0:0	3	\N	\N
59	554	58	59	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.061464+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:58:2026-11-18:1199:none:0:0	3	\N	\N
60	554	59	60	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:49.064351+00	2026-11-18 05:58:46.892636+00	accepted	scrape:554:59:2026-11-18:1199:none:0:0	3	\N	\N
61	555	10	61	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.69417+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:10:2026-11-18:399:none:0:0	3	\N	\N
62	555	5	62	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.697848+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:5:2026-11-18:329:special:0:0	3	\N	\N
63	555	60	63	439	\N	878	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.701307+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:60:2026-11-18:439:none:0:0	3	\N	\N
64	555	9	64	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.704007+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:9:2026-11-18:399:none:0:0	3	\N	\N
65	555	11	65	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.706655+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:11:2026-11-18:329:special:0:0	3	\N	\N
66	555	12	66	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.709088+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:12:2026-11-18:449:none:0:0	3	\N	\N
67	555	13	67	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.711508+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:13:2026-11-18:329:special:0:0	3	\N	\N
68	555	14	68	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.713911+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:14:2026-11-18:329:special:0:0	3	\N	\N
69	555	15	69	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.716162+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:15:2026-11-18:329:special:0:0	3	\N	\N
70	555	3	70	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.71848+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:3:2026-11-18:329:special:0:0	3	\N	\N
71	555	16	71	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.720893+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:16:2026-11-18:329:special:0:0	3	\N	\N
72	555	17	72	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.723135+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:17:2026-11-18:329:special:0:0	3	\N	\N
73	555	18	73	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.725545+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:18:2026-11-18:329:special:0:0	3	\N	\N
74	555	19	74	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.728218+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:19:2026-11-18:449:none:0:0	3	\N	\N
75	555	20	75	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.73063+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:20:2026-11-18:329:special:0:0	3	\N	\N
76	555	49	76	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.732829+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:49:2026-11-18:329:special:0:0	3	\N	\N
77	555	21	77	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.735219+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:21:2026-11-18:329:special:0:0	3	\N	\N
78	555	4	78	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.737558+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:4:2026-11-18:875:special:0:0	3	\N	\N
79	555	22	79	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.739864+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:22:2026-11-18:329:special:0:0	3	\N	\N
80	555	61	80	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.743323+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:61:2026-11-18:329:special:0:0	3	\N	\N
81	555	23	81	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.745512+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:23:2026-11-18:359:special:0:0	3	\N	\N
82	555	25	82	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.747709+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:25:2026-11-18:359:special:0:0	3	\N	\N
83	555	26	83	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.74983+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:26:2026-11-18:359:special:0:0	3	\N	\N
84	555	62	84	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.752756+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:62:2026-11-18:359:special:0:0	3	\N	\N
85	555	29	85	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.755453+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:29:2026-11-18:479:none:0:0	3	\N	\N
86	555	30	86	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.758058+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:30:2026-11-18:299:special:0:0	3	\N	\N
87	555	31	87	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.76064+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:31:2026-11-18:459:none:0:0	3	\N	\N
88	555	1	88	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.763363+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:1:2026-11-18:579:none:0:0	3	\N	\N
89	555	32	89	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.765706+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:32:2026-11-18:299:special:0:0	3	\N	\N
90	555	33	90	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.768048+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:33:2026-11-18:299:special:0:0	3	\N	\N
91	555	6	91	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.770271+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:6:2026-11-18:459:none:0:0	3	\N	\N
92	555	34	92	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.772501+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:34:2026-11-18:579:none:0:0	3	\N	\N
93	555	7	93	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.775012+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:7:2026-11-18:299:special:0:0	3	\N	\N
94	555	2	94	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.7772+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:2:2026-11-18:579:none:0:0	3	\N	\N
95	555	63	95	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.780253+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:63:2026-11-18:579:none:0:0	3	\N	\N
96	555	64	96	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.783364+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:64:2026-11-18:479:none:0:0	3	\N	\N
97	555	8	97	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.78578+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:8:2026-11-18:299:special:0:0	3	\N	\N
98	555	65	98	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.78899+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:65:2026-11-18:579:none:0:0	3	\N	\N
99	555	66	99	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:50.791914+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:66:2026-11-18:299:special:0:0	3	\N	\N
100	555	37	100	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.006955+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:37:2026-11-18:1449:none:0:0	3	\N	\N
101	555	40	101	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.017988+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:40:2026-11-18:875:special:0:0	3	\N	\N
102	555	43	102	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.029007+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:43:2026-11-18:875:special:0:0	3	\N	\N
103	555	39	103	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.035425+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:39:2026-11-18:875:special:0:0	3	\N	\N
104	555	38	104	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.040402+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:38:2026-11-18:875:special:0:0	3	\N	\N
105	555	45	105	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.044373+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:45:2026-11-18:1449:none:0:0	3	\N	\N
106	555	46	106	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.048104+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:46:2026-11-18:1449:none:0:0	3	\N	\N
108	555	57	108	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.054181+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:57:2026-11-18:1199:none:0:0	3	\N	\N
109	555	47	109	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.05713+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:47:2026-11-18:1549:none:0:0	3	\N	\N
110	555	49	110	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.059709+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:49:2026-11-18:875:special:0:0	3	\N	\N
111	555	44	111	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.062192+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:44:2026-11-18:875:special:0:0	3	\N	\N
112	555	50	112	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.064647+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:50:2026-11-18:1449:none:0:0	3	\N	\N
113	555	51	113	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.067307+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:51:2026-11-18:2799:special:0:0	3	\N	\N
114	555	52	114	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.069769+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:52:2026-11-18:999:special:0:0	3	\N	\N
115	555	53	115	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.07222+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:53:2026-11-18:1599:special:0:0	3	\N	\N
116	555	54	116	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.075015+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:54:2026-11-18:2599:none:0:0	3	\N	\N
117	555	42	117	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.077354+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:42:2026-11-18:999:special:0:0	3	\N	\N
118	555	41	118	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.079608+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:41:2026-11-18:999:special:0:0	3	\N	\N
119	555	55	119	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.081823+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:55:2026-11-18:1599:special:0:0	3	\N	\N
120	555	58	120	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.084017+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:58:2026-11-18:1199:none:0:0	3	\N	\N
121	555	59	121	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:52.086247+00	2026-11-18 05:58:50.692497+00	accepted	scrape:555:59:2026-11-18:1199:none:0:0	3	\N	\N
122	556	11	122	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.730332+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:11:2026-11-18:329:special:0:0	3	\N	\N
123	556	12	123	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.739466+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:12:2026-11-18:449:none:0:0	3	\N	\N
124	556	14	124	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.742088+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:14:2026-11-18:329:special:0:0	3	\N	\N
125	556	3	125	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.745305+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:3:2026-11-18:329:special:0:0	3	\N	\N
126	556	16	126	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.747667+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:16:2026-11-18:329:special:0:0	3	\N	\N
127	556	17	127	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.749979+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:17:2026-11-18:329:special:0:0	3	\N	\N
128	556	18	128	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.752314+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:18:2026-11-18:329:special:0:0	3	\N	\N
129	556	49	129	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.754455+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:49:2026-11-18:329:special:0:0	3	\N	\N
130	556	21	130	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.756749+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:21:2026-11-18:329:special:0:0	3	\N	\N
131	556	4	131	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.758885+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:4:2026-11-18:875:special:0:0	3	\N	\N
132	556	67	132	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.761899+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:67:2026-11-18:329:special:0:0	3	\N	\N
133	556	61	133	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.76421+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:61:2026-11-18:329:special:0:0	3	\N	\N
134	556	5	134	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.766516+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:5:2026-11-18:329:special:0:0	3	\N	\N
135	556	23	135	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.768767+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:23:2026-11-18:359:special:0:0	3	\N	\N
136	556	24	136	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.770945+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:24:2026-11-18:359:special:0:0	3	\N	\N
137	556	25	137	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.773154+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:25:2026-11-18:359:special:0:0	3	\N	\N
138	556	26	138	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.77542+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:26:2026-11-18:359:special:0:0	3	\N	\N
139	556	68	139	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.77831+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:68:2026-11-18:359:special:0:0	3	\N	\N
140	556	62	140	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.780514+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:62:2026-11-18:359:special:0:0	3	\N	\N
141	556	27	141	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.782793+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:27:2026-11-18:359:special:0:0	3	\N	\N
142	556	28	142	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.785251+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:28:2026-11-18:449:none:0:0	3	\N	\N
143	556	29	143	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.78818+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:29:2026-11-18:479:none:0:0	3	\N	\N
144	556	30	144	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.790934+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:30:2026-11-18:299:special:0:0	3	\N	\N
145	556	31	145	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.793664+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:31:2026-11-18:459:none:0:0	3	\N	\N
146	556	32	146	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.795972+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:32:2026-11-18:299:special:0:0	3	\N	\N
147	556	34	147	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.798191+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:34:2026-11-18:579:none:0:0	3	\N	\N
148	556	7	148	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.800498+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:7:2026-11-18:299:special:0:0	3	\N	\N
149	556	2	149	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.802784+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:2:2026-11-18:579:none:0:0	3	\N	\N
150	556	63	150	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.804988+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:63:2026-11-18:579:none:0:0	3	\N	\N
151	556	64	151	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.807142+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:64:2026-11-18:479:none:0:0	3	\N	\N
152	556	65	152	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.809303+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:65:2026-11-18:579:none:0:0	3	\N	\N
153	556	66	153	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.811718+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:66:2026-11-18:299:special:0:0	3	\N	\N
154	556	69	154	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.814748+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:69:2026-11-18:579:none:0:0	3	\N	\N
155	556	70	155	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.817693+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:70:2026-11-18:299:special:0:0	3	\N	\N
156	556	71	156	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:53.820618+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:71:2026-11-18:579:none:0:0	3	\N	\N
157	556	45	157	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:54.992044+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:45:2026-11-18:1449:none:0:0	3	\N	\N
158	556	43	158	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.003867+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:43:2026-11-18:875:special:0:0	3	\N	\N
159	556	40	159	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.014788+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:40:2026-11-18:875:special:0:0	3	\N	\N
160	556	39	160	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.02537+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:39:2026-11-18:875:special:0:0	3	\N	\N
161	556	38	161	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.035835+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:38:2026-11-18:875:special:0:0	3	\N	\N
162	556	47	162	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.046006+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:47:2026-11-18:1549:none:0:0	3	\N	\N
163	556	48	163	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.052513+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:48:2026-11-18:1549:none:0:0	3	\N	\N
164	556	49	164	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.057411+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:49:2026-11-18:875:special:0:0	3	\N	\N
165	556	44	165	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.061615+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:44:2026-11-18:875:special:0:0	3	\N	\N
166	556	46	166	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.065267+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:46:2026-11-18:1449:none:0:0	3	\N	\N
167	556	37	167	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.068986+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:37:2026-11-18:1449:none:0:0	3	\N	\N
169	556	50	169	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.074759+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:50:2026-11-18:1449:none:0:0	3	\N	\N
170	556	53	170	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.077752+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:53:2026-11-18:1599:special:0:0	3	\N	\N
171	556	54	171	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.080509+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:54:2026-11-18:2599:none:0:0	3	\N	\N
172	556	42	172	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.082808+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:42:2026-11-18:999:special:0:0	3	\N	\N
173	556	41	173	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.085171+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:41:2026-11-18:999:special:0:0	3	\N	\N
174	556	55	174	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.087608+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:55:2026-11-18:1599:special:0:0	3	\N	\N
175	556	56	175	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.089815+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:56:2026-11-18:2599:none:0:0	3	\N	\N
176	556	57	176	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:55.091994+00	2026-11-18 05:58:53.723784+00	accepted	scrape:556:57:2026-11-18:1199:none:0:0	3	\N	\N
177	558	9	177	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.650182+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:9:2026-11-18:399:none:0:0	3	\N	\N
178	558	10	178	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.659257+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:10:2026-11-18:399:none:0:0	3	\N	\N
179	558	11	179	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.665481+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:11:2026-11-18:329:special:0:0	3	\N	\N
180	558	12	180	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.670368+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:12:2026-11-18:449:none:0:0	3	\N	\N
181	558	14	181	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.674659+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:14:2026-11-18:329:special:0:0	3	\N	\N
182	558	15	182	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.678439+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:15:2026-11-18:329:special:0:0	3	\N	\N
183	558	3	183	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.681715+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:3:2026-11-18:329:special:0:0	3	\N	\N
184	558	16	184	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.684828+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:16:2026-11-18:329:special:0:0	3	\N	\N
185	558	17	185	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.687851+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:17:2026-11-18:329:special:0:0	3	\N	\N
186	558	18	186	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.690474+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:18:2026-11-18:329:special:0:0	3	\N	\N
187	558	19	187	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.69286+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:19:2026-11-18:449:none:0:0	3	\N	\N
188	558	20	188	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.695296+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:20:2026-11-18:329:special:0:0	3	\N	\N
189	558	21	189	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.697668+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:21:2026-11-18:329:special:0:0	3	\N	\N
190	558	4	190	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.699918+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:4:2026-11-18:875:special:0:0	3	\N	\N
191	558	22	191	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.702224+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:22:2026-11-18:329:special:0:0	3	\N	\N
192	558	61	192	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.704537+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:61:2026-11-18:329:special:0:0	3	\N	\N
193	558	23	193	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.70686+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:23:2026-11-18:359:special:0:0	3	\N	\N
194	558	25	194	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.709288+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:25:2026-11-18:359:special:0:0	3	\N	\N
195	558	26	195	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.711884+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:26:2026-11-18:359:special:0:0	3	\N	\N
196	558	68	196	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.714172+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:68:2026-11-18:359:special:0:0	3	\N	\N
197	558	62	197	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.7166+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:62:2026-11-18:359:special:0:0	3	\N	\N
198	558	27	198	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.718948+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:27:2026-11-18:359:special:0:0	3	\N	\N
199	558	28	199	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.721315+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:28:2026-11-18:449:none:0:0	3	\N	\N
200	558	29	200	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.723807+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:29:2026-11-18:479:none:0:0	3	\N	\N
201	558	30	201	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.726355+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:30:2026-11-18:299:special:0:0	3	\N	\N
202	558	31	202	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.72923+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:31:2026-11-18:459:none:0:0	3	\N	\N
203	558	1	203	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.732091+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:1:2026-11-18:579:none:0:0	3	\N	\N
204	558	32	204	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.734429+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:32:2026-11-18:299:special:0:0	3	\N	\N
205	558	33	205	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.736761+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:33:2026-11-18:299:special:0:0	3	\N	\N
206	558	6	206	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.739326+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:6:2026-11-18:459:none:0:0	3	\N	\N
207	558	34	207	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.741645+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:34:2026-11-18:579:none:0:0	3	\N	\N
208	558	7	208	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.744041+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:7:2026-11-18:299:special:0:0	3	\N	\N
209	558	2	209	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.746341+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:2:2026-11-18:579:none:0:0	3	\N	\N
210	558	35	210	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.748634+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:35:2026-11-18:299:special:0:0	3	\N	\N
211	558	36	211	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.750954+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:36:2026-11-18:579:none:0:0	3	\N	\N
212	558	63	212	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.753326+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:63:2026-11-18:579:none:0:0	3	\N	\N
213	558	64	213	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.755496+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:64:2026-11-18:479:none:0:0	3	\N	\N
214	558	8	214	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.757683+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:8:2026-11-18:299:special:0:0	3	\N	\N
215	558	65	215	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.759805+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:65:2026-11-18:579:none:0:0	3	\N	\N
216	558	66	216	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.761939+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:66:2026-11-18:299:special:0:0	3	\N	\N
217	558	69	217	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:56.764169+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:69:2026-11-18:579:none:0:0	3	\N	\N
218	558	43	218	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:57.976196+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:43:2026-11-18:875:special:0:0	3	\N	\N
219	558	40	219	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:57.98729+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:40:2026-11-18:875:special:0:0	3	\N	\N
220	558	39	220	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:57.998532+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:39:2026-11-18:875:special:0:0	3	\N	\N
221	558	38	221	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.005687+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:38:2026-11-18:875:special:0:0	3	\N	\N
222	558	47	222	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.010753+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:47:2026-11-18:1549:none:0:0	3	\N	\N
223	558	48	223	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.015136+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:48:2026-11-18:1549:none:0:0	3	\N	\N
224	558	49	224	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.019027+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:49:2026-11-18:875:special:0:0	3	\N	\N
225	558	44	225	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.022591+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:44:2026-11-18:875:special:0:0	3	\N	\N
226	558	45	226	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.025592+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:45:2026-11-18:1449:none:0:0	3	\N	\N
227	558	46	227	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.028473+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:46:2026-11-18:1449:none:0:0	3	\N	\N
228	558	37	228	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.031107+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:37:2026-11-18:1449:none:0:0	3	\N	\N
230	558	50	230	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.035916+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:50:2026-11-18:1449:none:0:0	3	\N	\N
231	558	51	231	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.038732+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:51:2026-11-18:2799:special:0:0	3	\N	\N
232	558	52	232	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.041247+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:52:2026-11-18:999:special:0:0	3	\N	\N
233	558	53	233	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.043839+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:53:2026-11-18:1599:special:0:0	3	\N	\N
234	558	42	234	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.046091+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:42:2026-11-18:999:special:0:0	3	\N	\N
235	558	57	235	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.048353+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:57:2026-11-18:1199:none:0:0	3	\N	\N
236	558	58	236	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.050542+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:58:2026-11-18:1199:none:0:0	3	\N	\N
237	558	59	237	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:58.052684+00	2026-11-18 05:58:56.644305+00	accepted	scrape:558:59:2026-11-18:1199:none:0:0	3	\N	\N
238	561	9	238	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.726713+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:9:2026-11-18:399:none:0:0	3	\N	\N
239	561	10	239	399	\N	1209	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.73572+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:10:2026-11-18:399:none:0:0	3	\N	\N
240	561	11	240	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.742222+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:11:2026-11-18:329:special:0:0	3	\N	\N
241	561	13	241	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.747373+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:13:2026-11-18:329:special:0:0	3	\N	\N
242	561	14	242	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.751371+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:14:2026-11-18:329:special:0:0	3	\N	\N
243	561	15	243	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.755037+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:15:2026-11-18:329:special:0:0	3	\N	\N
244	561	3	244	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.758477+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:3:2026-11-18:329:special:0:0	3	\N	\N
245	561	16	245	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.761759+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:16:2026-11-18:329:special:0:0	3	\N	\N
246	561	18	246	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.7645+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:18:2026-11-18:329:special:0:0	3	\N	\N
247	561	19	247	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.767146+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:19:2026-11-18:449:none:0:0	3	\N	\N
248	561	20	248	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.769622+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:20:2026-11-18:329:special:0:0	3	\N	\N
249	561	21	249	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.772232+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:21:2026-11-18:329:special:0:0	3	\N	\N
250	561	4	250	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.774574+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:4:2026-11-18:875:special:0:0	3	\N	\N
251	561	22	251	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.776937+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:22:2026-11-18:329:special:0:0	3	\N	\N
252	561	61	252	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.779247+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:61:2026-11-18:329:special:0:0	3	\N	\N
253	561	5	253	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.781607+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:5:2026-11-18:329:special:0:0	3	\N	\N
255	561	23	255	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.786303+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:23:2026-11-18:359:special:0:0	3	\N	\N
256	561	25	256	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.789066+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:25:2026-11-18:359:special:0:0	3	\N	\N
257	561	68	257	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.791652+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:68:2026-11-18:359:special:0:0	3	\N	\N
258	561	27	258	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.794073+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:27:2026-11-18:359:special:0:0	3	\N	\N
259	561	28	259	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.796432+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:28:2026-11-18:449:none:0:0	3	\N	\N
260	561	29	260	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.799013+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:29:2026-11-18:479:none:0:0	3	\N	\N
261	561	30	261	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.801808+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:30:2026-11-18:299:special:0:0	3	\N	\N
262	561	31	262	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.80442+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:31:2026-11-18:459:none:0:0	3	\N	\N
263	561	1	263	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.807096+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:1:2026-11-18:579:none:0:0	3	\N	\N
264	561	32	264	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.809291+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:32:2026-11-18:299:special:0:0	3	\N	\N
265	561	33	265	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.811655+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:33:2026-11-18:299:special:0:0	3	\N	\N
266	561	6	266	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.813959+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:6:2026-11-18:459:none:0:0	3	\N	\N
267	561	34	267	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.816476+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:34:2026-11-18:579:none:0:0	3	\N	\N
268	561	7	268	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.818955+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:7:2026-11-18:299:special:0:0	3	\N	\N
269	561	2	269	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.821422+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:2:2026-11-18:579:none:0:0	3	\N	\N
270	561	35	270	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.823626+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:35:2026-11-18:299:special:0:0	3	\N	\N
271	561	36	271	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.825774+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:36:2026-11-18:579:none:0:0	3	\N	\N
272	561	63	272	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.828+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:63:2026-11-18:579:none:0:0	3	\N	\N
273	561	64	273	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.830187+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:64:2026-11-18:479:none:0:0	3	\N	\N
274	561	8	274	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:58:59.832544+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:8:2026-11-18:299:special:0:0	3	\N	\N
275	561	43	275	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.965181+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:43:2026-11-18:875:special:0:0	3	\N	\N
276	561	40	276	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.976162+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:40:2026-11-18:875:special:0:0	3	\N	\N
277	561	39	277	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.986462+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:39:2026-11-18:875:special:0:0	3	\N	\N
278	561	38	278	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.992124+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:38:2026-11-18:875:special:0:0	3	\N	\N
279	561	47	279	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.994503+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:47:2026-11-18:1549:none:0:0	3	\N	\N
280	561	48	280	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.996669+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:48:2026-11-18:1549:none:0:0	3	\N	\N
281	561	49	281	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:00.999112+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:49:2026-11-18:875:special:0:0	3	\N	\N
282	561	44	282	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.00154+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:44:2026-11-18:875:special:0:0	3	\N	\N
283	561	45	283	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.004095+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:45:2026-11-18:1449:none:0:0	3	\N	\N
284	561	46	284	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.006405+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:46:2026-11-18:1449:none:0:0	3	\N	\N
285	561	37	285	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.008595+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:37:2026-11-18:1449:none:0:0	3	\N	\N
287	561	50	287	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.012917+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:50:2026-11-18:1449:none:0:0	3	\N	\N
288	561	51	288	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.0154+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:51:2026-11-18:2799:special:0:0	3	\N	\N
289	561	52	289	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.01778+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:52:2026-11-18:999:special:0:0	3	\N	\N
290	561	53	290	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.020153+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:53:2026-11-18:1599:special:0:0	3	\N	\N
291	561	54	291	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.022646+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:54:2026-11-18:2599:none:0:0	3	\N	\N
292	561	42	292	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.024833+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:42:2026-11-18:999:special:0:0	3	\N	\N
293	561	41	293	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.027016+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:41:2026-11-18:999:special:0:0	3	\N	\N
294	561	55	294	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.029145+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:55:2026-11-18:1599:special:0:0	3	\N	\N
295	561	56	295	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.031526+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:56:2026-11-18:2599:none:0:0	3	\N	\N
296	561	57	296	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.033761+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:57:2026-11-18:1199:none:0:0	3	\N	\N
297	561	58	297	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.036054+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:58:2026-11-18:1199:none:0:0	3	\N	\N
298	561	59	298	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:01.03859+00	2026-11-18 05:58:59.721082+00	accepted	scrape:561:59:2026-11-18:1199:none:0:0	3	\N	\N
299	562	4	299	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.68377+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:4:2026-11-18:875:special:0:0	3	\N	\N
300	562	49	300	329	449	164	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.687721+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:49:2026-11-18:329:special:0:0	3	\N	\N
301	562	13	301	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.691311+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:13:2026-11-18:329:special:0:0	3	\N	\N
302	562	17	302	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.69369+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:17:2026-11-18:329:special:0:0	3	\N	\N
303	562	21	303	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.695906+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:21:2026-11-18:329:special:0:0	3	\N	\N
304	562	5	304	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.698253+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:5:2026-11-18:329:special:0:0	3	\N	\N
305	562	27	305	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.700528+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:27:2026-11-18:359:special:0:0	3	\N	\N
306	562	11	306	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.702896+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:11:2026-11-18:329:special:0:0	3	\N	\N
307	562	12	307	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.705224+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:12:2026-11-18:449:none:0:0	3	\N	\N
308	562	14	308	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.707609+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:14:2026-11-18:329:special:0:0	3	\N	\N
309	562	15	309	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.709862+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:15:2026-11-18:329:special:0:0	3	\N	\N
310	562	3	310	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.71256+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:3:2026-11-18:329:special:0:0	3	\N	\N
311	562	18	311	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.715164+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:18:2026-11-18:329:special:0:0	3	\N	\N
312	562	19	312	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.717634+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:19:2026-11-18:449:none:0:0	3	\N	\N
313	562	20	313	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.719902+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:20:2026-11-18:329:special:0:0	3	\N	\N
314	562	67	314	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.722429+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:67:2026-11-18:329:special:0:0	3	\N	\N
315	562	61	315	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.724929+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:61:2026-11-18:329:special:0:0	3	\N	\N
317	562	24	317	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.7297+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:24:2026-11-18:359:special:0:0	3	\N	\N
318	562	25	318	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.732111+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:25:2026-11-18:359:special:0:0	3	\N	\N
319	562	26	319	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.734321+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:26:2026-11-18:359:special:0:0	3	\N	\N
320	562	68	320	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.736641+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:68:2026-11-18:359:special:0:0	3	\N	\N
321	562	62	321	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.739366+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:62:2026-11-18:359:special:0:0	3	\N	\N
322	562	28	322	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.741609+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:28:2026-11-18:449:none:0:0	3	\N	\N
323	562	29	323	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.744152+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:29:2026-11-18:479:none:0:0	3	\N	\N
324	562	30	324	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.746636+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:30:2026-11-18:299:special:0:0	3	\N	\N
325	562	31	325	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.749048+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:31:2026-11-18:459:none:0:0	3	\N	\N
326	562	1	326	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.751817+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:1:2026-11-18:579:none:0:0	3	\N	\N
327	562	32	327	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.754107+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:32:2026-11-18:299:special:0:0	3	\N	\N
328	562	33	328	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.75644+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:33:2026-11-18:299:special:0:0	3	\N	\N
329	562	6	329	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.758714+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:6:2026-11-18:459:none:0:0	3	\N	\N
330	562	34	330	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.761078+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:34:2026-11-18:579:none:0:0	3	\N	\N
331	562	7	331	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.763499+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:7:2026-11-18:299:special:0:0	3	\N	\N
332	562	2	332	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.765969+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:2:2026-11-18:579:none:0:0	3	\N	\N
333	562	35	333	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.768495+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:35:2026-11-18:299:special:0:0	3	\N	\N
334	562	36	334	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.770857+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:36:2026-11-18:579:none:0:0	3	\N	\N
335	562	63	335	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.773117+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:63:2026-11-18:579:none:0:0	3	\N	\N
336	562	64	336	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.775423+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:64:2026-11-18:479:none:0:0	3	\N	\N
337	562	8	337	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.777781+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:8:2026-11-18:299:special:0:0	3	\N	\N
338	562	65	338	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.780026+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:65:2026-11-18:579:none:0:0	3	\N	\N
339	562	66	339	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:02.782329+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:66:2026-11-18:299:special:0:0	3	\N	\N
340	562	38	340	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.867715+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:38:2026-11-18:875:special:0:0	3	\N	\N
341	562	39	341	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.870448+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:39:2026-11-18:875:special:0:0	3	\N	\N
342	562	44	342	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.872997+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:44:2026-11-18:875:special:0:0	3	\N	\N
343	562	40	343	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.875492+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:40:2026-11-18:875:special:0:0	3	\N	\N
344	562	47	344	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.877901+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:47:2026-11-18:1549:none:0:0	3	\N	\N
345	562	49	345	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.880258+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:49:2026-11-18:875:special:0:0	3	\N	\N
346	562	43	346	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.882673+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:43:2026-11-18:875:special:0:0	3	\N	\N
347	562	48	347	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.885114+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:48:2026-11-18:1549:none:0:0	3	\N	\N
348	562	45	348	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.887661+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:45:2026-11-18:1449:none:0:0	3	\N	\N
349	562	46	349	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.890096+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:46:2026-11-18:1449:none:0:0	3	\N	\N
350	562	37	350	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.892296+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:37:2026-11-18:1449:none:0:0	3	\N	\N
352	562	50	352	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.896444+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:50:2026-11-18:1449:none:0:0	3	\N	\N
353	562	51	353	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.898936+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:51:2026-11-18:2799:special:0:0	3	\N	\N
354	562	52	354	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.901668+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:52:2026-11-18:999:special:0:0	3	\N	\N
355	562	53	355	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.904477+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:53:2026-11-18:1599:special:0:0	3	\N	\N
356	562	54	356	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.907085+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:54:2026-11-18:2599:none:0:0	3	\N	\N
357	562	42	357	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.909225+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:42:2026-11-18:999:special:0:0	3	\N	\N
358	562	41	358	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.91159+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:41:2026-11-18:999:special:0:0	3	\N	\N
359	562	55	359	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.913903+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:55:2026-11-18:1599:special:0:0	3	\N	\N
360	562	56	360	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:03.916259+00	2026-11-18 05:59:02.681685+00	accepted	scrape:562:56:2026-11-18:2599:none:0:0	3	\N	\N
361	563	21	361	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.643591+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:21:2026-11-18:329:special:0:0	3	\N	\N
362	563	61	362	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.646135+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:61:2026-11-18:329:special:0:0	3	\N	\N
363	563	11	363	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.648682+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:11:2026-11-18:329:special:0:0	3	\N	\N
364	563	12	364	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.65116+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:12:2026-11-18:449:none:0:0	3	\N	\N
365	563	13	365	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.653591+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:13:2026-11-18:329:special:0:0	3	\N	\N
366	563	14	366	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.656175+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:14:2026-11-18:329:special:0:0	3	\N	\N
367	563	15	367	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.658646+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:15:2026-11-18:329:special:0:0	3	\N	\N
368	563	3	368	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.661006+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:3:2026-11-18:329:special:0:0	3	\N	\N
369	563	16	369	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.663378+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:16:2026-11-18:329:special:0:0	3	\N	\N
370	563	17	370	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.665741+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:17:2026-11-18:329:special:0:0	3	\N	\N
371	563	18	371	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.668346+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:18:2026-11-18:329:special:0:0	3	\N	\N
372	563	19	372	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.670752+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:19:2026-11-18:449:none:0:0	3	\N	\N
373	563	20	373	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.67323+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:20:2026-11-18:329:special:0:0	3	\N	\N
374	563	4	374	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.675557+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:4:2026-11-18:875:special:0:0	3	\N	\N
375	563	22	375	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.678011+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:22:2026-11-18:329:special:0:0	3	\N	\N
376	563	5	376	329	449	658	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.680444+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:5:2026-11-18:329:special:0:0	3	\N	\N
378	563	23	378	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.684912+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:23:2026-11-18:359:special:0:0	3	\N	\N
379	563	24	379	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.687386+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:24:2026-11-18:359:special:0:0	3	\N	\N
380	563	25	380	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.689797+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:25:2026-11-18:359:special:0:0	3	\N	\N
381	563	26	381	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.692045+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:26:2026-11-18:359:special:0:0	3	\N	\N
382	563	68	382	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.694365+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:68:2026-11-18:359:special:0:0	3	\N	\N
383	563	62	383	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.696721+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:62:2026-11-18:359:special:0:0	3	\N	\N
384	563	27	384	359	449	718	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.698941+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:27:2026-11-18:359:special:0:0	3	\N	\N
385	563	28	385	449	\N	898	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.701155+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:28:2026-11-18:449:none:0:0	3	\N	\N
386	563	29	386	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.703642+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:29:2026-11-18:479:none:0:0	3	\N	\N
387	563	30	387	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.706068+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:30:2026-11-18:299:special:0:0	3	\N	\N
388	563	31	388	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.708652+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:31:2026-11-18:459:none:0:0	3	\N	\N
389	563	1	389	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.711093+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:1:2026-11-18:579:none:0:0	3	\N	\N
390	563	32	390	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.713273+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:32:2026-11-18:299:special:0:0	3	\N	\N
391	563	33	391	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.715544+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:33:2026-11-18:299:special:0:0	3	\N	\N
392	563	6	392	459	\N	1293	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.717755+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:6:2026-11-18:459:none:0:0	3	\N	\N
393	563	34	393	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.719957+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:34:2026-11-18:579:none:0:0	3	\N	\N
394	563	7	394	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.722198+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:7:2026-11-18:299:special:0:0	3	\N	\N
395	563	2	395	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.724472+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:2:2026-11-18:579:none:0:0	3	\N	\N
396	563	35	396	299	369	1196	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.726693+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:35:2026-11-18:299:special:0:0	3	\N	\N
397	563	63	397	579	\N	1224	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.729327+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:63:2026-11-18:579:none:0:0	3	\N	\N
398	563	64	398	479	\N	1452	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:05.732144+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:64:2026-11-18:479:none:0:0	3	\N	\N
399	563	43	399	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.960207+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:43:2026-11-18:875:special:0:0	3	\N	\N
400	563	42	400	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.963142+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:42:2026-11-18:999:special:0:0	3	\N	\N
401	563	40	401	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.96584+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:40:2026-11-18:875:special:0:0	3	\N	\N
402	563	39	402	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.968449+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:39:2026-11-18:875:special:0:0	3	\N	\N
403	563	38	403	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.970953+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:38:2026-11-18:875:special:0:0	3	\N	\N
404	563	47	404	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.973408+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:47:2026-11-18:1549:none:0:0	3	\N	\N
405	563	48	405	1549	\N	774	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.975866+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:48:2026-11-18:1549:none:0:0	3	\N	\N
406	563	49	406	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.97825+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:49:2026-11-18:875:special:0:0	3	\N	\N
407	563	44	407	875	1549	438	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.980711+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:44:2026-11-18:875:special:0:0	3	\N	\N
408	563	45	408	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.983331+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:45:2026-11-18:1449:none:0:0	3	\N	\N
409	563	46	409	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.98588+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:46:2026-11-18:1449:none:0:0	3	\N	\N
410	563	37	410	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.988461+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:37:2026-11-18:1449:none:0:0	3	\N	\N
412	563	50	412	1449	\N	724	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.993194+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:50:2026-11-18:1449:none:0:0	3	\N	\N
413	563	51	413	2799	3699	933	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.995864+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:51:2026-11-18:2799:special:0:0	3	\N	\N
414	563	52	414	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:06.998478+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:52:2026-11-18:999:special:0:0	3	\N	\N
415	563	53	415	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.001007+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:53:2026-11-18:1599:special:0:0	3	\N	\N
416	563	54	416	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.003497+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:54:2026-11-18:2599:none:0:0	3	\N	\N
417	563	41	417	999	1399	999	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.00582+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:41:2026-11-18:999:special:0:0	3	\N	\N
418	563	55	418	1599	2099	845	special	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.008135+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:55:2026-11-18:1599:special:0:0	3	\N	\N
419	563	56	419	2599	\N	1300	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.01039+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:56:2026-11-18:2599:none:0:0	3	\N	\N
420	563	57	420	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.012695+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:57:2026-11-18:1199:none:0:0	3	\N	\N
421	563	58	421	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.015089+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:58:2026-11-18:1199:none:0:0	3	\N	\N
422	563	59	422	1199	\N	1199	none	\N	\N	\N	scrape	store	\N	\N	\N	2026-11-18 05:59:07.017345+00	2026-11-18 05:59:05.642129+00	accepted	scrape:563:59:2026-11-18:1199:none:0:0	3	\N	\N
\.


--
-- Data for Name: photos; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.photos (id, token, filename, content_type, bytes, sha256, width, height, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: price_alerts; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.price_alerts (id, device_id, product_id, family_slug, chain_code, store_id, max_price_cents, is_active, last_notified_at, created_at) FROM stdin;
\.


--
-- Data for Name: price_daily; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.price_daily (day, chain_id, product_id, price_cents, was_price_cents, promo_kind, source) FROM stdin;
2026-11-18	3	65	579	\N	none	scrape
2026-11-18	1	12	350	470	special	scrape
2026-11-18	1	4	1750	\N	none	scrape
2026-11-18	1	14	350	470	special	scrape
2026-11-18	1	39	1750	\N	none	scrape
2026-11-18	1	40	1750	\N	none	scrape
2026-11-18	1	49	1750	\N	none	scrape
2026-11-18	1	67	350	470	special	scrape
2026-11-18	1	47	1750	\N	none	scrape
2026-11-18	3	332	2799	3699	special	scrape
2026-11-18	1	61	350	470	special	scrape
2026-11-18	1	18	350	470	special	scrape
2026-11-18	1	295	440	\N	none	scrape
2026-11-18	1	275	550	\N	none	scrape
2026-11-18	1	43	1750	\N	none	scrape
2026-11-18	1	25	360	\N	none	scrape
2026-11-18	1	53	1500	\N	none	scrape
2026-11-18	1	29	470	\N	none	scrape
2026-11-18	1	1	450	560	special	scrape
2026-11-18	3	333	999	1399	special	scrape
2026-11-18	1	42	1300	\N	none	scrape
2026-11-18	1	52	1300	\N	none	scrape
2026-11-18	1	30	320	\N	none	scrape
2026-11-18	1	276	6249	\N	none	scrape
2026-11-18	1	277	6249	\N	none	scrape
2026-11-18	1	278	1300	\N	none	scrape
2026-11-18	1	279	6249	\N	none	scrape
2026-11-18	1	280	6249	\N	none	scrape
2026-11-18	1	7	320	\N	none	scrape
2026-11-18	1	281	6249	\N	none	scrape
2026-11-18	1	55	1500	\N	none	scrape
2026-11-18	1	284	6249	\N	none	scrape
2026-11-18	1	285	320	\N	none	scrape
2026-11-18	1	56	2200	\N	none	scrape
2026-11-18	1	287	320	\N	none	scrape
2026-11-18	1	286	2500	\N	none	scrape
2026-11-18	1	288	1300	\N	none	scrape
2026-11-18	1	289	1300	\N	none	scrape
2026-11-18	1	34	450	560	special	scrape
2026-11-18	1	66	320	\N	none	scrape
2026-11-18	1	290	7499	\N	none	scrape
2026-11-18	1	8	320	\N	none	scrape
2026-11-18	1	21	350	470	special	scrape
2026-11-18	3	334	1599	2099	special	scrape
2026-11-18	1	291	1000	\N	none	scrape
2026-11-18	1	314	265	\N	none	scrape
2026-11-18	3	335	2599	\N	none	scrape
2026-11-18	1	292	1000	\N	none	scrape
2026-11-19	1	12	350	470	special	scrape
2026-11-18	1	59	720	1200	special	scrape
2026-11-18	1	298	6255	\N	none	scrape
2026-11-18	1	68	360	\N	none	scrape
2026-11-18	1	309	400	\N	none	scrape
2026-11-19	1	4	1750	\N	none	scrape
2026-11-18	1	303	350	\N	none	scrape
2026-11-18	1	58	720	1200	special	scrape
2026-11-19	1	39	1750	\N	none	scrape
2026-11-19	1	40	1750	\N	none	scrape
2026-11-18	1	304	1000	\N	none	scrape
2026-11-18	1	306	265	\N	none	scrape
2026-11-18	1	305	265	\N	none	scrape
2026-11-18	1	37	870	1450	special	scrape
2026-11-18	1	272	1750	\N	none	scrape
2026-11-18	1	307	265	\N	none	scrape
2026-11-18	1	62	360	\N	none	scrape
2026-11-19	1	48	1750	\N	none	scrape
2026-11-19	1	49	1750	\N	none	scrape
2026-11-18	3	61	329	449	special	scrape
2026-11-18	1	308	265	\N	none	scrape
2026-11-18	1	50	870	1450	special	scrape
2026-11-19	1	47	1750	\N	none	scrape
2026-11-18	1	41	1300	\N	none	scrape
2026-11-18	1	45	870	1450	special	scrape
2026-11-18	1	28	360	\N	none	scrape
2026-11-18	1	46	870	1450	special	scrape
2026-11-19	1	19	350	470	special	scrape
2026-11-18	1	316	550	\N	none	scrape
2026-11-19	1	67	350	470	special	scrape
2026-11-18	1	315	690	770	special	scrape
2026-11-19	1	3	350	470	special	scrape
2026-11-18	1	320	330	430	special	scrape
2026-11-18	1	311	275	\N	none	scrape
2026-11-18	1	312	450	700	special	scrape
2026-11-18	1	313	6095	\N	none	scrape
2026-11-19	1	22	350	470	special	scrape
2026-11-19	1	61	350	470	special	scrape
2026-11-18	3	70	299	369	special	scrape
2026-11-18	1	318	330	430	special	scrape
2026-11-18	3	323	329	449	special	scrape
2026-11-18	3	68	359	449	special	scrape
2026-11-18	3	328	479	\N	none	scrape
2026-11-18	1	302	1290	\N	none	scrape
2026-11-18	1	297	265	\N	none	scrape
2026-11-18	1	5	350	470	special	scrape
2026-11-18	1	299	265	\N	none	scrape
2026-11-18	1	57	720	1200	special	scrape
2026-11-18	1	15	350	470	special	scrape
2026-11-18	1	321	550	\N	none	scrape
2026-11-18	3	329	299	369	special	scrape
2026-11-18	3	330	459	\N	none	scrape
2026-11-18	3	331	579	\N	none	scrape
2026-11-18	3	69	579	\N	none	scrape
2026-11-18	3	64	479	\N	none	scrape
2026-11-19	1	18	350	470	special	scrape
2026-11-19	1	274	350	470	special	scrape
2026-11-19	1	275	550	\N	none	scrape
2026-11-19	1	43	1750	\N	none	scrape
2026-11-19	1	11	350	470	special	scrape
2026-11-19	1	21	350	470	special	scrape
2026-11-19	1	5	350	470	special	scrape
2026-11-19	1	38	1750	\N	none	scrape
2026-11-19	3	24	359	449	special	scrape
2026-11-19	1	14	350	470	special	scrape
2026-11-19	1	15	350	470	special	scrape
2026-11-19	1	336	440	\N	none	scrape
2026-11-19	1	44	1750	\N	none	scrape
2026-11-19	3	27	359	449	special	scrape
2026-11-19	3	28	449	\N	none	scrape
2026-11-18	3	60	439	\N	none	scrape
2026-11-18	3	19	449	\N	none	scrape
2026-11-18	1	48	1750	\N	none	scrape
2026-11-18	1	319	330	430	special	scrape
2026-11-18	1	19	350	470	special	scrape
2026-11-18	1	3	350	470	special	scrape
2026-11-18	1	22	350	470	special	scrape
2026-11-18	1	11	350	470	special	scrape
2026-11-18	1	274	350	470	special	scrape
2026-11-18	3	67	329	449	special	scrape
2026-11-18	3	20	329	449	special	scrape
2026-11-18	3	4	875	1549	special	scrape
2026-11-18	3	22	329	449	special	scrape
2026-11-18	1	54	2200	\N	none	scrape
2026-11-18	1	51	2500	\N	none	scrape
2026-11-18	1	282	1300	\N	none	scrape
2026-11-18	1	33	320	\N	none	scrape
2026-11-18	1	317	570	\N	none	scrape
2026-11-18	1	32	320	\N	none	scrape
2026-11-18	1	322	1400	\N	none	scrape
2026-11-18	3	5	329	449	special	scrape
2026-11-18	3	23	359	449	special	scrape
2026-11-18	3	24	359	449	special	scrape
2026-11-18	1	294	720	1200	special	scrape
2026-11-18	1	296	6950	\N	none	scrape
2026-11-18	1	301	440	\N	none	scrape
2026-11-18	3	25	359	449	special	scrape
2026-11-18	1	273	350	470	special	scrape
2026-11-18	3	26	359	449	special	scrape
2026-11-18	1	27	360	\N	none	scrape
2026-11-18	3	62	359	449	special	scrape
2026-11-18	3	27	359	449	special	scrape
2026-11-19	3	69	579	\N	none	scrape
2026-11-18	3	28	449	\N	none	scrape
2026-11-18	3	32	299	369	special	scrape
2026-11-18	3	33	299	369	special	scrape
2026-11-19	1	54	2200	\N	none	scrape
2026-11-18	3	6	459	\N	none	scrape
2026-11-18	3	34	579	\N	none	scrape
2026-11-18	1	310	900	\N	none	scrape
2026-11-18	3	71	579	\N	none	scrape
2026-11-18	3	29	479	\N	none	scrape
2026-11-18	3	30	299	369	special	scrape
2026-11-18	3	31	459	\N	none	scrape
2026-11-18	3	7	299	369	special	scrape
2026-11-18	1	20	350	470	special	scrape
2026-11-18	3	1	579	\N	none	scrape
2026-11-18	1	283	1500	\N	none	scrape
2026-11-18	1	293	440	\N	none	scrape
2026-11-18	1	60	440	\N	none	scrape
2026-11-18	1	300	1000	\N	none	scrape
2026-11-18	1	38	1750	\N	none	scrape
2026-11-18	1	44	1750	\N	none	scrape
2026-11-18	3	36	579	\N	none	scrape
2026-11-18	3	2	579	\N	none	scrape
2026-11-18	3	35	299	369	special	scrape
2026-11-18	3	63	579	\N	none	scrape
2026-11-18	3	9	399	\N	none	scrape
2026-11-18	3	10	399	\N	none	scrape
2026-11-18	3	21	329	449	special	scrape
2026-11-18	3	11	329	449	special	scrape
2026-11-18	3	12	449	\N	none	scrape
2026-11-18	3	48	1549	\N	none	scrape
2026-11-18	3	13	329	449	special	scrape
2026-11-18	3	56	2599	\N	none	scrape
2026-11-18	3	14	329	449	special	scrape
2026-11-18	3	15	329	449	special	scrape
2026-11-19	1	51	2500	\N	none	scrape
2026-11-18	3	3	329	449	special	scrape
2026-11-19	1	1	450	560	special	scrape
2026-11-19	1	41	1300	\N	none	scrape
2026-11-19	1	42	1300	\N	none	scrape
2026-11-18	3	16	329	449	special	scrape
2026-11-19	3	68	359	449	special	scrape
2026-11-19	3	33	299	369	special	scrape
2026-11-19	1	282	1300	\N	none	scrape
2026-11-18	3	17	329	449	special	scrape
2026-11-19	1	56	2200	\N	none	scrape
2026-11-19	1	278	1300	\N	none	scrape
2026-11-19	1	276	6249	\N	none	scrape
2026-11-18	3	18	329	449	special	scrape
2026-11-19	1	277	6249	\N	none	scrape
2026-11-19	1	30	320	\N	none	scrape
2026-11-19	1	279	6249	\N	none	scrape
2026-11-19	1	280	6249	\N	none	scrape
2026-11-19	1	281	6249	\N	none	scrape
2026-11-19	3	70	299	369	special	scrape
2026-11-19	1	284	6249	\N	none	scrape
2026-11-19	1	55	1500	\N	none	scrape
2026-11-19	3	71	579	\N	none	scrape
2026-11-19	3	67	329	449	special	scrape
2026-11-19	1	33	320	\N	none	scrape
2026-11-19	1	285	320	\N	none	scrape
2026-11-19	1	287	320	\N	none	scrape
2026-11-19	1	286	2500	\N	none	scrape
2026-11-19	1	288	1300	\N	none	scrape
2026-11-19	1	289	1300	\N	none	scrape
2026-11-19	1	32	320	\N	none	scrape
2026-11-19	1	34	450	560	special	scrape
2026-11-19	1	29	470	\N	none	scrape
2026-11-19	1	52	1300	\N	none	scrape
2026-11-19	1	7	320	\N	none	scrape
2026-11-18	3	8	299	369	special	scrape
2026-11-18	3	66	299	369	special	scrape
2026-11-18	3	51	2799	3699	special	scrape
2026-11-18	3	52	999	1399	special	scrape
2026-11-18	3	53	1599	2099	special	scrape
2026-11-18	3	54	2599	\N	none	scrape
2026-11-18	3	43	875	1549	special	scrape
2026-11-18	3	42	999	1399	special	scrape
2026-11-18	3	40	875	1549	special	scrape
2026-11-18	3	39	875	1549	special	scrape
2026-11-18	3	38	875	1549	special	scrape
2026-11-18	3	47	1549	\N	none	scrape
2026-11-18	3	49	875	1549	special	scrape
2026-11-18	3	44	875	1549	special	scrape
2026-11-18	3	45	1449	\N	none	scrape
2026-11-18	3	46	1449	\N	none	scrape
2026-11-18	3	37	1449	\N	none	scrape
2026-11-18	3	50	1449	\N	none	scrape
2026-11-18	3	41	999	1399	special	scrape
2026-11-18	3	55	1599	2099	special	scrape
2026-11-18	3	57	1199	\N	none	scrape
2026-11-18	3	58	1199	\N	none	scrape
2026-11-18	3	59	1199	\N	none	scrape
2026-11-19	1	66	320	\N	none	scrape
2026-11-19	3	12	449	\N	none	scrape
2026-11-19	1	337	7499	\N	none	scrape
2026-11-19	3	60	439	\N	none	scrape
2026-11-19	3	13	329	449	special	scrape
2026-11-19	3	14	329	449	special	scrape
2026-11-19	1	8	320	\N	none	scrape
2026-11-19	3	15	329	449	special	scrape
2026-11-19	3	3	329	449	special	scrape
2026-11-19	3	16	329	449	special	scrape
2026-11-19	1	59	720	1200	special	scrape
2026-11-19	3	17	329	449	special	scrape
2026-11-19	3	19	449	\N	none	scrape
2026-11-19	1	294	720	1200	special	scrape
2026-11-19	1	295	440	\N	none	scrape
2026-11-19	1	296	6950	\N	none	scrape
2026-11-19	1	298	6950	\N	none	scrape
2026-11-19	1	301	440	\N	none	scrape
2026-11-19	1	303	350	\N	none	scrape
2026-11-19	3	4	875	1549	special	scrape
2026-11-19	3	5	329	449	special	scrape
2026-11-19	3	323	329	449	special	scrape
2026-11-19	3	62	359	449	special	scrape
2026-11-19	3	6	459	\N	none	scrape
2026-11-19	3	7	299	369	special	scrape
2026-11-19	3	2	579	\N	none	scrape
2026-11-19	3	63	579	\N	none	scrape
2026-11-19	3	64	479	\N	none	scrape
2026-11-19	3	9	399	\N	none	scrape
2026-11-19	3	10	399	\N	none	scrape
2026-11-19	1	306	265	\N	none	scrape
2026-11-19	1	272	1750	\N	none	scrape
2026-11-19	1	50	870	1450	special	scrape
2026-11-19	3	8	299	369	special	scrape
2026-11-19	1	62	360	\N	none	scrape
2026-11-19	3	65	579	\N	none	scrape
2026-11-19	3	66	299	369	special	scrape
2026-11-19	3	61	329	449	special	scrape
2026-11-19	3	11	329	449	special	scrape
2026-11-19	1	46	870	1450	special	scrape
2026-11-19	1	45	870	1450	special	scrape
2026-11-19	1	27	360	\N	none	scrape
2026-11-19	1	28	360	\N	none	scrape
2026-11-19	1	305	265	\N	none	scrape
2026-11-19	1	338	720	1200	special	scrape
2026-11-19	1	37	870	1450	special	scrape
2026-11-19	1	307	265	\N	none	scrape
2026-11-19	1	293	440	\N	none	scrape
2026-11-19	1	304	1000	\N	none	scrape
2026-11-19	1	58	720	1200	special	scrape
2026-11-19	1	60	440	\N	none	scrape
2026-11-19	1	302	1290	\N	none	scrape
2026-11-19	1	283	1500	\N	none	scrape
2026-11-19	1	300	1000	\N	none	scrape
2026-11-19	1	297	265	\N	none	scrape
2026-11-19	1	309	400	\N	none	scrape
2026-11-19	1	273	350	470	special	scrape
2026-11-19	1	292	1000	\N	none	scrape
2026-11-19	1	299	265	\N	none	scrape
2026-11-19	1	57	720	1200	special	scrape
2026-11-19	1	291	1000	\N	none	scrape
2026-11-19	1	314	265	\N	none	scrape
2026-11-19	1	308	265	\N	none	scrape
2026-11-19	1	310	900	\N	none	scrape
2026-11-19	1	311	275	\N	none	scrape
2026-11-19	1	312	450	700	special	scrape
2026-11-19	1	313	6095	\N	none	scrape
2026-11-19	1	53	1500	\N	none	scrape
2026-11-19	1	25	360	\N	none	scrape
2026-11-19	1	316	550	\N	none	scrape
2026-11-19	1	318	330	430	special	scrape
2026-11-19	1	315	690	770	special	scrape
2026-11-19	1	320	330	430	special	scrape
2026-11-19	1	321	550	\N	none	scrape
2026-11-19	1	319	330	430	special	scrape
2026-11-19	1	317	570	\N	none	scrape
2026-11-19	1	20	350	470	special	scrape
2026-11-19	1	68	360	\N	none	scrape
2026-11-19	1	322	1400	\N	none	scrape
2026-11-19	2	39	1050	1750	special	scrape
2026-11-19	2	40	1050	1750	special	scrape
2026-11-19	2	12	470	\N	multibuy	scrape
2026-11-19	2	48	1050	1750	special	scrape
2026-11-19	2	341	1500	\N	multibuy	scrape
2026-11-19	2	3	470	\N	multibuy	scrape
2026-11-19	2	11	470	\N	multibuy	scrape
2026-11-19	2	14	470	\N	multibuy	scrape
2026-11-19	2	18	470	\N	multibuy	scrape
2026-11-19	2	333	650	1300	special	scrape
2026-11-19	2	278	650	1300	special	scrape
2026-11-19	2	42	650	1300	special	scrape
2026-11-19	2	335	2200	\N	none	scrape
2026-11-19	2	282	650	1300	special	scrape
2026-11-19	2	287	320	\N	multibuy	scrape
2026-11-19	2	329	320	\N	multibuy	scrape
2026-11-19	2	331	560	\N	multibuy	scrape
2026-11-19	2	70	320	\N	multibuy	scrape
2026-11-19	2	33	320	\N	multibuy	scrape
2026-11-19	2	285	320	\N	multibuy	scrape
2026-11-19	2	56	2200	\N	none	scrape
2026-11-19	2	332	2900	\N	none	scrape
2026-11-19	2	334	1500	\N	none	scrape
2026-11-19	2	58	1200	\N	multibuy	scrape
2026-11-19	2	342	1200	\N	multibuy	scrape
2026-11-19	2	343	1000	\N	none	scrape
2026-11-19	2	59	1200	\N	multibuy	scrape
2026-11-19	2	344	1700	\N	none	scrape
2026-11-19	2	300	1000	\N	none	scrape
2026-11-19	2	57	1200	\N	multibuy	scrape
2026-11-19	2	292	1000	\N	none	scrape
2026-11-19	2	345	440	\N	none	scrape
2026-11-19	2	314	265	\N	none	scrape
2026-11-19	2	301	440	\N	none	scrape
2026-11-19	2	346	265	\N	none	scrape
2026-11-19	2	347	265	\N	none	scrape
2026-11-19	2	297	265	\N	none	scrape
2026-11-19	2	60	440	\N	none	scrape
2026-11-19	2	348	265	\N	none	scrape
2026-11-19	2	336	440	\N	none	scrape
2026-11-19	2	299	265	\N	none	scrape
2026-11-19	2	349	350	\N	none	scrape
2026-11-19	2	350	200	265	special	scrape
2026-11-19	2	295	440	\N	none	scrape
2026-11-19	2	37	870	1450	special	scrape
2026-11-19	2	25	360	\N	none	scrape
2026-11-19	2	28	360	\N	none	scrape
2026-11-19	2	352	290	360	special	scrape
2026-11-19	2	27	290	360	special	scrape
2026-11-19	2	353	900	\N	none	scrape
2026-11-19	2	354	275	\N	none	scrape
2026-11-19	2	19	470	\N	multibuy	scrape
2026-11-19	2	273	470	\N	multibuy	scrape
2026-11-19	2	272	1050	1750	special	scrape
2026-11-19	2	22	470	\N	multibuy	scrape
2026-11-19	2	38	1050	1750	special	scrape
2026-11-19	2	339	1500	\N	multibuy	scrape
2026-11-19	2	4	1050	1750	special	scrape
2026-11-19	2	44	1050	1750	special	scrape
2026-11-19	2	41	650	1300	special	scrape
2026-11-19	2	5	470	\N	multibuy	scrape
2026-11-19	2	351	870	1450	special	scrape
2026-11-19	2	340	1050	1750	special	scrape
2026-11-19	2	61	470	\N	multibuy	scrape
2026-11-19	2	15	470	\N	multibuy	scrape
2026-11-19	2	67	470	\N	multibuy	scrape
2026-11-19	2	47	1050	1750	special	scrape
2026-11-19	2	274	470	\N	multibuy	scrape
2026-11-19	2	21	470	\N	multibuy	scrape
2026-11-19	2	20	470	\N	multibuy	scrape
2026-11-19	3	21	329	449	special	scrape
2026-11-19	2	321	440	550	special	scrape
2026-11-19	3	18	329	449	special	scrape
2026-11-19	2	316	440	550	special	scrape
2026-11-19	2	318	430	\N	none	scrape
2026-11-19	2	315	770	\N	none	scrape
2026-11-19	2	319	430	\N	none	scrape
2026-11-19	2	317	440	570	special	scrape
2026-11-19	2	355	405	\N	none	scrape
2026-11-19	3	20	329	449	special	scrape
2026-11-19	3	22	329	449	special	scrape
2026-11-19	3	36	579	\N	none	scrape
2026-11-19	3	23	359	449	special	scrape
2026-11-19	3	25	359	449	special	scrape
2026-11-19	3	26	359	449	special	scrape
2026-11-19	3	328	479	\N	none	scrape
2026-11-19	3	329	299	369	special	scrape
2026-11-19	3	330	459	\N	none	scrape
2026-11-19	3	331	579	\N	none	scrape
2026-11-19	3	32	299	369	special	scrape
2026-11-19	3	34	579	\N	none	scrape
2026-11-19	3	35	299	369	special	scrape
2026-11-19	3	40	875	1549	special	scrape
2026-11-19	3	39	875	1549	special	scrape
2026-11-19	3	38	875	1549	special	scrape
2026-11-19	3	37	1449	\N	none	scrape
2026-11-19	3	44	875	1549	special	scrape
2026-11-19	3	45	1449	\N	none	scrape
2026-11-19	3	46	1449	\N	none	scrape
2026-11-19	3	356	1449	\N	none	scrape
2026-11-19	3	50	1449	\N	none	scrape
2026-11-19	3	332	2799	3699	special	scrape
2026-11-19	3	333	999	1399	special	scrape
2026-11-19	3	334	1599	2099	special	scrape
2026-11-19	3	335	2599	\N	none	scrape
2026-11-19	3	41	999	1399	special	scrape
2026-11-19	3	55	1599	2099	special	scrape
2026-11-19	3	56	2599	\N	none	scrape
2026-11-19	3	57	1199	\N	none	scrape
2026-11-19	3	58	1199	\N	none	scrape
2026-11-19	3	59	1199	\N	none	scrape
2026-11-19	3	43	875	1549	special	scrape
2026-11-19	3	42	999	1399	special	scrape
2026-11-19	3	47	1549	\N	none	scrape
2026-11-19	3	48	1549	\N	none	scrape
2026-11-19	3	49	875	1549	special	scrape
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.products (id, slug, brand, name, variant, size_ml, pack_count, barcode, category, source, is_active, created_at, updated_at, canonical_product_id, family_slug, caffeine_mg_per_100ml, status, image_url, normalised_barcode) FROM stdin;
336	v-original-500ml	V	Original	\N	500	1	29415767677207	energy	auto	t	2026-11-18 21:20:00.001424+00	2026-11-18 21:20:00.001424+00	\N	v-original-500ml	32.00	verified	\N	\N
338	v-refresh-pineapple-watermelon-zero-250ml-x4	V	Refresh Pineapple Watermelon Zero	\N	250	4	9415767119062	energy	auto	t	2026-11-18 21:20:04.249755+00	2026-11-18 21:20:04.249755+00	\N	v-refresh-pineapple-watermelon-zero-250ml	32.00	verified	\N	9415767119062
339	monster-ultra-250ml-x6	Monster	Ultra	\N	250	6	\N	energy	auto	t	2026-11-18 21:45:00.003691+00	2026-11-18 21:45:00.003691+00	\N	monster-ultra-250ml	32.00	verified	\N	\N
340	monster-peach-500ml-x4	Monster	Peach	\N	500	4	\N	energy	auto	t	2026-11-18 21:45:00.003691+00	2026-11-18 21:45:00.003691+00	\N	monster-peach-500ml	32.00	verified	\N	\N
341	monster-green-250ml-x6	Monster	Green	\N	250	6	\N	energy	auto	t	2026-11-18 21:45:00.003691+00	2026-11-18 21:45:00.003691+00	\N	monster-green-250ml	32.00	verified	\N	\N
342	v-pineapple-250ml-x4	V	Pineapple	\N	250	4	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-pineapple-250ml	32.00	verified	\N	\N
343	v-original-500ml-x4	V	Original	\N	500	4	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-original-500ml	32.00	verified	\N	\N
344	v-green-250ml-x10	V	Green	\N	250	10	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-green-250ml	32.00	verified	\N	\N
345	v-raspberry-500ml	V	Raspberry	\N	500	1	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-raspberry-500ml	32.00	verified	\N	\N
346	v-purple-sour-candy-250ml	V	Purple Sour Candy	\N	250	1	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-purple-sour-candy-250ml	32.00	verified	\N	\N
347	v-lemonade-iceblock-250ml	V	Lemonade Iceblock	\N	250	1	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-lemonade-iceblock-250ml	32.00	verified	\N	\N
348	v-zero-original-250ml	V	Zero Original	\N	250	1	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-zero-original-250ml	32.00	verified	\N	\N
349	v-original-glass-350ml	V	Original Glass	\N	350	1	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-original-glass-350ml	32.00	verified	\N	\N
350	v-strawberries-cream-250ml	V	Strawberries Cream	\N	250	1	\N	energy	auto	t	2026-11-18 21:45:05.266594+00	2026-11-18 21:45:05.266594+00	\N	v-strawberries-cream-250ml	32.00	verified	\N	\N
353	rockstar-original-500ml-x4	Rockstar	Original	\N	500	4	\N	energy	auto	t	2026-11-18 21:45:07.946303+00	2026-11-18 21:45:07.946303+00	\N	rockstar-original-500ml	32.00	verified	\N	\N
354	rockstar-guava-500ml	Rockstar	Guava	\N	500	1	\N	energy	auto	t	2026-11-18 21:45:07.946303+00	2026-11-18 21:45:07.946303+00	\N	rockstar-guava-500ml	32.00	verified	\N	\N
355	dare-charged-strong-latte-iced-coffee-240ml	Dare	Charged Strong Latte Iced Coffee	\N	240	1	\N	iced-coffee	auto	t	2026-11-18 21:45:11.065558+00	2026-11-18 21:45:11.065558+00	\N	dare-charged-strong-latte-iced-coffee-240ml	32.00	verified	\N	\N
356	mother-original-free-500ml-x4	Mother	Original Free	\N	500	4	\N	energy	auto	t	2026-11-19 02:08:56.498467+00	2026-11-19 02:08:56.498467+00	\N	mother-original-free-500ml	32.00	verified	\N	\N
2	red-bull-zero-473ml	Red Bull	Zero	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-zero-473ml	32.00	verified	\N	\N
272	monster-ultra-500ml-x4	Monster	Ultra	\N	500	4	19342866000502	energy	auto	t	2026-11-18 06:05:19.909648+00	2026-11-18 06:58:48.176377+00	\N	monster-ultra-500ml	32.00	verified	\N	9342866000502
273	monster-ultra-500ml	Monster	Ultra	\N	500	1	19342866000496	energy	auto	t	2026-11-18 06:05:19.909648+00	2026-11-18 06:58:48.176377+00	\N	monster-ultra-500ml	32.00	verified	\N	9342866000496
274	monster-ultra-peachy-keen-500ml	Monster	Ultra Peachy Keen	\N	500	1	19342866003282	energy	auto	t	2026-11-18 06:05:19.909648+00	2026-11-18 06:58:48.176377+00	\N	monster-ultra-peachy-keen-500ml	32.00	verified	\N	9342866003282
278	red-bull-sudachi-lime-250ml-x4	Red Bull	Sudachi Lime	\N	250	4	9002490298548	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-sudachi-lime-250ml	32.00	verified	\N	9002490298548
282	red-bull-white-peach-edition-250ml-x4	Red Bull	White Peach Edition	\N	250	4	9002490292621	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-white-peach-edition-250ml	32.00	verified	\N	9002490292621
283	red-bull-white-peach-edition-473ml-x4	Red Bull	White Peach Edition	\N	473	4	9002490305680	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-white-peach-edition-473ml	32.00	verified	\N	9002490305680
285	red-bull-sudachi-lime-250ml	Red Bull	Sudachi Lime	\N	250	1	9002490297398	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-sudachi-lime-250ml	32.00	verified	\N	9002490297398
286	red-bull-free-250ml-x12	Red Bull	Free	\N	250	12	9002490202088	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-free-250ml	32.00	verified	\N	9002490202088
287	red-bull-cherry-sakura-edition-250ml	Red Bull	Cherry Sakura Edition	\N	250	1	9002490297046	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-cherry-sakura-edition-250ml	32.00	verified	\N	9002490297046
288	red-bull-berry-edition-250ml-x4	Red Bull	Berry Edition	\N	250	4	9002490285395	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-berry-edition-250ml	32.00	verified	\N	9002490285395
299	v-blue-250ml	V	Blue	\N	250	1	19415767624105	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-blue-250ml	32.00	verified	\N	9415767624105
300	v-blue-500ml-x4	V	Blue	\N	500	4	19415767014975	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-blue-500ml	32.00	verified	\N	9415767014975
301	v-strawberry-crush-500ml	V	Strawberry Crush	\N	500	1	19415767015279	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-strawberry-crush-500ml	32.00	verified	\N	9415767015279
302	v-green-330ml-x6	V	Green	\N	330	6	9415767116764	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-green-330ml	32.00	verified	\N	9415767116764
303	v-guarana-350ml	V	Guarana	\N	350	1	19415767677583	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-guarana-350ml	32.00	verified	\N	9415767677583
304	v-zero-500ml-x4	V	Zero	\N	500	4	19415767018959	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-zero-500ml	32.00	verified	\N	9415767018959
305	v-zero-250ml	V	Zero	\N	250	1	19415767676111	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-zero-250ml	32.00	verified	\N	9415767676111
306	v-refresh-peach-nectarine-250ml	V	Refresh Peach Nectarine	\N	250	1	9415767116399	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-refresh-peach-nectarine-250ml	32.00	verified	\N	9415767116399
307	v-refresh-pineapple-watermelon-zero-250ml	V	Refresh Pineapple Watermelon Zero	\N	250	1	9415767119222	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-refresh-pineapple-watermelon-zero-250ml	32.00	verified	\N	9415767119222
308	v-zero-blackcurrant-yuzu-250ml	V	Zero Blackcurrant Yuzu	\N	250	1	9415767011298	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-zero-blackcurrant-yuzu-250ml	32.00	verified	\N	9415767011298
309	celsius-sunset-vibe-sparkling-mango-passionfruit-330ml	Celsius	Sunset Vibe Sparkling Mango Passionfruit	\N	330	1	9415767913981	energy	auto	t	2026-11-18 06:05:25.779304+00	2026-11-18 06:58:48.176377+00	\N	celsius-sunset-vibe-sparkling-mango-passionfruit-330ml	32.00	verified	\N	9415767913981
310	rockstar-tropical-guava-500ml-x4	Rockstar	Tropical Guava	\N	500	4	19414789968266	energy	auto	t	2026-11-18 06:05:26.825095+00	2026-11-18 06:58:48.176377+00	\N	rockstar-tropical-guava-500ml	32.00	verified	\N	9414789968266
314	v-blue-zero-250ml	V	Blue Zero	\N	250	1	19415767015606	energy	auto	t	2026-11-18 06:05:26.825095+00	2026-11-18 06:58:48.176377+00	\N	v-blue-zero-250ml	32.00	verified	\N	9415767015606
315	dare-espresso-iced-coffee-2000ml	Dare	Espresso Iced Coffee	\N	2000	1	19310199080843	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-espresso-iced-coffee-2000ml	32.00	verified	\N	9310199080843
316	dare-caramel-latte-iced-coffee-750ml	Dare	Caramel Latte Iced Coffee	\N	750	1	19310232958979	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-caramel-latte-iced-coffee-750ml	32.00	verified	\N	9310232958979
317	dare-double-espresso-iced-coffee-750ml	Dare	Double Espresso Iced Coffee	\N	750	1	19310232957545	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-double-espresso-iced-coffee-750ml	32.00	verified	\N	9310232957545
318	dare-intense-espresso-iced-coffee-500ml	Dare	Intense Espresso Iced Coffee	\N	500	1	19310232961184	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-intense-espresso-iced-coffee-500ml	32.00	verified	\N	9310232961184
319	dare-no-added-double-espresso-iced-coffee-500ml	Dare	No Added Double Espresso Iced Coffee	\N	500	1	19310232959235	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-no-added-double-espresso-iced-coffee-500ml	32.00	verified	\N	9310232959235
320	dare-protein-mocha-iced-coffee-500ml	Dare	Protein Mocha Iced Coffee	\N	500	1	19310232962471	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-protein-mocha-iced-coffee-500ml	32.00	verified	\N	9310232962471
321	dare-mocha-iced-coffee-flavoured-milk-750ml	Dare	Mocha Iced Coffee Flavoured Milk	\N	750	1	19310232957552	iced-coffee	auto	t	2026-11-18 06:05:29.130598+00	2026-11-18 07:01:43.207948+00	\N	dare-mocha-iced-coffee-flavoured-milk-750ml	32.00	verified	\N	9310232957552
31	red-bull-355ml	Red Bull	Original	\N	355	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-355ml	32.00	verified	\N	\N
325	v-berry-500ml	V	Berry	\N	250	1	9300633099999	energy	crowd	t	2026-11-18 07:01:57.124226+00	2026-11-18 07:01:57.220067+00	\N	v-berry-500ml	32.00	verified	\N	9300633099999
1	red-bull-473ml	Red Bull	Original	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-473ml	32.00	verified	\N	\N
4	monster-ultra-strawberry-500ml-x4	Monster	Ultra Strawberry	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-strawberry-500ml	32.00	verified	\N	\N
5	monster-zero-500ml	Monster	Zero	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-zero-500ml	32.00	verified	\N	\N
6	red-bull-free-355ml	Red Bull	Free	\N	355	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-355ml	32.00	verified	\N	\N
7	red-bull-zero-250ml	Red Bull	Zero	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-zero-250ml	32.00	verified	\N	\N
8	red-bull-free-berry-ed-250ml	Red Bull	Free Berry Ed	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-berry-ed-250ml	32.00	verified	\N	\N
9	celsius-mango-lemon-330ml	Celsius	Mango Lemon	\N	330	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	celsius-mango-lemon-330ml	32.00	verified	\N	\N
10	celsius-watermelon-lemonade-330ml	Celsius	Watermelon Lemonade	\N	330	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	celsius-watermelon-lemonade-330ml	32.00	verified	\N	\N
11	monster-aussie-lemonade-500ml	Monster	Aussie Lemonade	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-aussie-lemonade-500ml	32.00	verified	\N	\N
12	monster-bad-apple-500ml	Monster	Bad Apple	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-bad-apple-500ml	32.00	verified	\N	\N
13	monster-ultra-rosa-500ml	Monster	Ultra Rosa	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-rosa-500ml	32.00	verified	\N	\N
14	monster-green-500ml	Monster	Green	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-green-500ml	32.00	verified	\N	\N
15	monster-lando-norris-zero-500ml	Monster	Lando Norris Zero	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-lando-norris-zero-500ml	32.00	verified	\N	\N
16	monster-papillon-500ml	Monster	Papillon	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-papillon-500ml	32.00	verified	\N	\N
17	monster-pipeline-punch-500ml	Monster	Pipeline Punch	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-pipeline-punch-500ml	32.00	verified	\N	\N
18	monster-rio-punch-500ml	Monster	Rio Punch	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-rio-punch-500ml	32.00	verified	\N	\N
19	monster-ultra-blue-hawaiian-500ml	Monster	Ultra Blue Hawaiian	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-blue-hawaiian-500ml	32.00	verified	\N	\N
20	monster-ultra-fiesta-mango-500ml	Monster	Ultra Fiesta Mango	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-fiesta-mango-500ml	32.00	verified	\N	\N
21	monster-ultra-ruby-red-500ml	Monster	Ultra Ruby Red	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-ruby-red-500ml	32.00	verified	\N	\N
22	monster-ultra-vice-500ml	Monster	Ultra Vice	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-vice-500ml	32.00	verified	\N	\N
23	mother-frosty-berry-500ml	Mother	Frosty Berry	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-frosty-berry-500ml	32.00	verified	\N	\N
24	mother-passion-500ml	Mother	Passion	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-passion-500ml	32.00	verified	\N	\N
25	mother-original-500ml	Mother	Original	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-original-500ml	32.00	verified	\N	\N
26	mother-free-500ml	Mother	Free	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-free-500ml	32.00	verified	\N	\N
27	mother-watermelon-500ml	Mother	Watermelon	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-watermelon-500ml	32.00	verified	\N	\N
28	mother-white-gummy-500ml	Mother	White Gummy	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-white-gummy-500ml	32.00	verified	\N	\N
32	red-bull-red-edition-250ml	Red Bull	Red Edition	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-red-edition-250ml	32.00	verified	\N	\N
33	red-bull-free-250ml	Red Bull	Free	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-250ml	32.00	verified	\N	\N
34	red-bull-free-473ml	Red Bull	Free	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-473ml	32.00	verified	\N	\N
35	red-bull-exotic-passionfruit-250ml	Red Bull	Exotic Passionfruit	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-exotic-passionfruit-250ml	32.00	verified	\N	\N
36	red-bull-exotic-passionfruit-473ml	Red Bull	Exotic Passionfruit	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-exotic-passionfruit-473ml	32.00	verified	\N	\N
37	mother-original-500ml-x4	Mother	Original	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-original-500ml	32.00	verified	\N	\N
39	monster-mango-loco-500ml-x4	Monster	Mango Loco	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-mango-loco-500ml	32.00	verified	\N	\N
40	monster-green-500ml-x4	Monster	Green	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-green-500ml	32.00	verified	\N	\N
41	red-bull-zero-250ml-x4	Red Bull	Zero	\N	250	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-zero-250ml	32.00	verified	\N	\N
42	red-bull-free-250ml-x4	Red Bull	Free	\N	250	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-250ml	32.00	verified	\N	\N
43	monster-aussie-lemonade-500ml-x4	Monster	Aussie Lemonade	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-aussie-lemonade-500ml	32.00	verified	\N	\N
44	monster-ultra-violet-500ml-x4	Monster	Ultra Violet	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-violet-500ml	32.00	verified	\N	\N
45	mother-frosty-berry-500ml-x4	Mother	Frosty Berry	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-frosty-berry-500ml	32.00	verified	\N	\N
29	red-bull-330ml	Red Bull	Original	\N	330	1	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-330ml	32.00	verified	\N	\N
30	red-bull-250ml	Red Bull	Original	\N	250	1	90435324	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-250ml	32.00	verified	\N	90435324
3	monster-mango-loco-500ml	Monster	Mango Loco	\N	500	1	9342866000635	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 11:26:46.380023+00	\N	monster-mango-loco-500ml	32.00	verified	\N	9342866000635
328	red-bull-original-330ml	Red Bull	Original	\N	330	1	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-330ml	32.00	verified	\N	\N
329	red-bull-original-250ml	Red Bull	Original	\N	250	1	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-250ml	32.00	verified	\N	\N
330	red-bull-original-355ml	Red Bull	Original	\N	355	1	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-355ml	32.00	verified	\N	\N
331	red-bull-original-473ml	Red Bull	Original	\N	473	1	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-473ml	32.00	verified	\N	\N
46	mother-lava-guava-500ml-x4	Mother	Lava Guava	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-lava-guava-500ml	32.00	verified	\N	\N
47	monster-lando-norris-500ml-x4	Monster	Lando Norris	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-lando-norris-500ml	32.00	verified	\N	\N
48	monster-rio-punch-500ml-x4	Monster	Rio Punch	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-rio-punch-500ml	32.00	verified	\N	\N
49	monster-ultra-peachy-keen-500ml-x4	Monster	Ultra Peachy Keen	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	monster-ultra-peachy-keen-500ml	32.00	verified	\N	\N
50	mother-rainbow-sherbet-500ml-x4	Mother	Rainbow Sherbet	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	mother-rainbow-sherbet-500ml	32.00	verified	\N	\N
55	red-bull-free-473ml-x4	Red Bull	Free	\N	473	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-473ml	32.00	verified	\N	\N
56	red-bull-free-250ml-x8	Red Bull	Free	\N	250	8	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	red-bull-free-250ml	32.00	verified	\N	\N
57	v-blue-250ml-x4	V	Blue	\N	250	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	v-blue-250ml	32.00	verified	\N	\N
58	v-original-250ml-x4	V	Original	\N	250	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	v-original-250ml	32.00	verified	\N	\N
59	v-free-250ml-x4	V	Free	\N	250	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 05:58:46.892636+00	\N	v-free-250ml	32.00	verified	\N	\N
60	v-blue-500ml	V	Blue	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	v-blue-500ml	32.00	verified	\N	\N
61	monster-ultra-violet-500ml	Monster	Ultra Violet	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	monster-ultra-violet-500ml	32.00	verified	\N	\N
62	mother-rainbow-sherbet-500ml	Mother	Rainbow Sherbet	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	mother-rainbow-sherbet-500ml	32.00	verified	\N	\N
63	red-bull-red-edition-473ml	Red Bull	Red Edition	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	red-bull-red-edition-473ml	32.00	verified	\N	\N
64	red-bull-free-330ml	Red Bull	Free	\N	330	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	red-bull-free-330ml	32.00	verified	\N	\N
65	red-bull-free-berry-ed-473ml	Red Bull	Free Berry Ed	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	red-bull-free-berry-ed-473ml	32.00	verified	\N	\N
66	red-bull-free-lilac-grapefruit-250ml	Red Bull	Free Lilac Grapefruit	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:50.692497+00	2026-11-18 05:58:50.692497+00	\N	red-bull-free-lilac-grapefruit-250ml	32.00	verified	\N	\N
67	monster-ultra-strawberry-dreams-500ml	Monster	Ultra Strawberry Dreams	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:53.723784+00	2026-11-18 05:58:53.723784+00	\N	monster-ultra-strawberry-dreams-500ml	32.00	verified	\N	\N
68	mother-lava-guava-500ml	Mother	Lava Guava	\N	500	1	\N	energy	auto	t	2026-11-18 05:58:53.723784+00	2026-11-18 05:58:53.723784+00	\N	mother-lava-guava-500ml	32.00	verified	\N	\N
69	red-bull-free-lilac-grapefruit-473ml	Red Bull	Free Lilac Grapefruit	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:53.723784+00	2026-11-18 05:58:53.723784+00	\N	red-bull-free-lilac-grapefruit-473ml	32.00	verified	\N	\N
70	red-bull-white-peach-250ml	Red Bull	White Peach	\N	250	1	\N	energy	auto	t	2026-11-18 05:58:53.723784+00	2026-11-18 05:58:53.723784+00	\N	red-bull-white-peach-250ml	32.00	verified	\N	\N
71	red-bull-white-peach-473ml	Red Bull	White Peach	\N	473	1	\N	energy	auto	t	2026-11-18 05:58:53.723784+00	2026-11-18 05:58:53.723784+00	\N	red-bull-white-peach-473ml	32.00	verified	\N	\N
275	monster-white-500ml	Monster	White	\N	500	1	\N	energy	auto	t	2026-11-18 06:05:19.909648+00	2026-11-18 06:05:19.909648+00	\N	monster-white-500ml	32.00	verified	\N	\N
276	red-bull-red-edition-watermelon-flavour-473ml-x12	Red Bull	Red Edition Watermelon Flavour	\N	473	12	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-red-edition-watermelon-flavour-473ml	32.00	verified	\N	\N
277	red-bull-summer-edition-white-peach-473ml-x12	Red Bull	Summer Edition White Peach	\N	473	12	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-summer-edition-white-peach-473ml	32.00	verified	\N	\N
279	red-bull-free-cherry-sakura-473ml-x12	Red Bull	Free Cherry Sakura	\N	473	12	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-free-cherry-sakura-473ml	32.00	verified	\N	\N
280	red-bull-summer-edition-sudachi-lime-473ml-x12	Red Bull	Summer Edition Sudachi Lime	\N	473	12	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-summer-edition-sudachi-lime-473ml	32.00	verified	\N	\N
281	red-bull-free-berry-edition-forest-fruits-473ml-x12	Red Bull	Free Berry Edition Forest Fruits	\N	473	12	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-free-berry-edition-forest-fruits-473ml	32.00	verified	\N	\N
284	red-bull-free-lilac-edition-grapefruit-blossom-473ml-x12	Red Bull	Free Lilac Edition Grapefruit Blossom	\N	473	12	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-free-lilac-edition-grapefruit-blossom-473ml	32.00	verified	\N	\N
51	red-bull-250ml-x12	Red Bull	Original	\N	250	12	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-250ml	32.00	verified	\N	\N
52	red-bull-250ml-x4	Red Bull	Original	\N	250	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-250ml	32.00	verified	\N	\N
53	red-bull-473ml-x4	Red Bull	Original	\N	473	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-473ml	32.00	verified	\N	\N
54	red-bull-250ml-x8	Red Bull	Original	\N	250	8	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 07:38:29.27329+00	\N	red-bull-250ml	32.00	verified	\N	\N
296	v-blue-6000ml	V	Blue	\N	6000	1	\N	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:05:24.430403+00	\N	v-blue-6000ml	32.00	verified	\N	\N
298	v-raspberry-lemonade-250ml-x4	V	Raspberry Lemonade	\N	250	4	\N	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:05:24.430403+00	\N	v-raspberry-lemonade-250ml	32.00	verified	\N	\N
311	rockstar-guava-punched-500ml	Rockstar	Guava Punched	\N	500	1	20818094004620	energy	auto	t	2026-11-18 06:05:26.825095+00	2026-11-18 06:05:26.825095+00	\N	rockstar-guava-punched-500ml	32.00	verified	\N	\N
312	rockstar-sodastream-soda-mix-440ml	Rockstar	Sodastream Soda Mix	\N	440	1	67290113763014	energy	auto	t	2026-11-18 06:05:26.825095+00	2026-11-18 06:05:26.825095+00	\N	rockstar-sodastream-soda-mix-440ml	32.00	verified	\N	\N
313	rockstar-guava-punch-12-500ml	Rockstar	Guava Punch 12	\N	500	1	\N	energy	auto	t	2026-11-18 06:05:26.825095+00	2026-11-18 06:05:26.825095+00	\N	rockstar-guava-punch-12-500ml	32.00	verified	\N	\N
323	monster-zero-ultra-500ml	Monster	Zero Ultra	\N	500	1	\N	energy	auto	t	2026-11-18 06:06:12.44389+00	2026-11-18 06:06:12.44389+00	\N	monster-zero-ultra-500ml	32.00	verified	\N	\N
38	monster-ultra-zero-500ml-x4	Monster	Ultra Zero	\N	500	4	\N	energy	auto	t	2026-11-18 05:58:46.892636+00	2026-11-18 06:09:16.951204+00	272	monster-ultra-zero-500ml	32.00	verified	\N	\N
289	red-bull-lilac-edition-free-250ml-x4	Red Bull	Lilac Edition Free	\N	250	4	9002490289942	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:58:48.176377+00	\N	red-bull-lilac-edition-free-250ml	32.00	verified	\N	9002490289942
292	v-grape-burst-500ml-x4	V	Grape Burst	\N	500	4	19415767013633	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-grape-burst-500ml	32.00	verified	\N	9415767013633
293	v-grape-zero-500ml	V	Grape Zero	\N	500	1	19415767015095	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-grape-zero-500ml	32.00	verified	\N	9415767015095
294	v-refresh-blackcurrant-yuzu-250ml-x4	V	Refresh Blackcurrant Yuzu	\N	250	4	9415767011830	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-refresh-blackcurrant-yuzu-250ml	32.00	verified	\N	9415767011830
295	v-grape-burst-500ml	V	Grape Burst	\N	500	1	19415767013848	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 06:58:48.176377+00	\N	v-grape-burst-500ml	32.00	verified	\N	9415767013848
322	prime-hydration-glowberry-sports-500ml	Prime	Hydration Glowberry Sports	\N	500	1	\N	hydration	auto	t	2026-11-18 06:05:30.652681+00	2026-11-18 07:01:43.207948+00	\N	prime-hydration-glowberry-sports-500ml	32.00	verified	\N	\N
291	v-500ml-x4	V	Original	\N	500	4	19415767014517	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 07:38:29.27329+00	\N	v-500ml	32.00	verified	\N	9415767014517
297	v-250ml	V	Original	\N	250	1	19415767677118	energy	auto	t	2026-11-18 06:05:24.430403+00	2026-11-18 07:38:29.27329+00	\N	v-250ml	32.00	verified	\N	9415767677118
290	red-bull-24x-250ml	Red Bull	Original	\N	250	24	\N	energy	auto	t	2026-11-18 06:05:23.286967+00	2026-11-18 06:05:23.286967+00	\N	red-bull-24x-250ml	32.00	verified	\N	\N
332	red-bull-original-250ml-x12	Red Bull	Original	\N	250	12	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-250ml	32.00	verified	\N	\N
333	red-bull-original-250ml-x4	Red Bull	Original	\N	250	4	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-250ml	32.00	verified	\N	\N
334	red-bull-original-473ml-x4	Red Bull	Original	\N	473	4	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-473ml	32.00	verified	\N	\N
335	red-bull-original-250ml-x8	Red Bull	Original	\N	250	8	\N	energy	auto	t	2026-11-18 14:08:56.502147+00	2026-11-18 14:08:56.502147+00	\N	red-bull-original-250ml	32.00	verified	\N	\N
337	red-bull-original-250ml-x24	Red Bull	Original	\N	250	24	\N	energy	auto	t	2026-11-18 21:20:03.051254+00	2026-11-18 21:20:03.051254+00	\N	red-bull-original-250ml	32.00	verified	\N	\N
351	mother-free-500ml-x4	Mother	Free	\N	500	4	\N	energy	auto	t	2026-11-18 21:45:06.394389+00	2026-11-18 21:45:06.394389+00	\N	mother-free-500ml	32.00	verified	\N	\N
352	mother-rainbow-sherbert-500ml	Mother	Rainbow Sherbert	\N	500	1	\N	energy	auto	t	2026-11-18 21:45:06.394389+00	2026-11-18 21:45:06.394389+00	\N	mother-rainbow-sherbert-500ml	32.00	verified	\N	\N
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.reports (id, observation_id, device_id, reason, note, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.schema_migrations (name, applied_at) FROM stdin;
002_chain_scope.sql	2026-11-18 06:01:01.439583+00
003_product_aliases.sql	2026-11-18 06:06:54.921814+00
004_feature_pack.sql	2026-11-18 06:57:30.907216+00
005_barcodes.sql	2026-11-18 06:59:35.523237+00
006_price_daily.sql	2026-11-18 07:00:26.946184+00
007_search_trgm.sql	2026-11-18 07:39:53.249061+00
\.


--
-- Data for Name: scrape_runs; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.scrape_runs (id, chain_code, store_id, started_at, finished_at, status, items_seen, observations_written, products_created, error) FROM stdin;
2	spudshed	\N	2026-11-18 05:58:46.892636+00	2026-11-18 05:59:07.023223+00	ok	487	412	71	\N
4	woolworths	\N	2026-11-18 05:59:36.06791+00	2026-11-18 06:00:03.306101+00	ok	288	11954	72	\N
5	woolworths	\N	2026-11-18 06:01:05.560848+00	2026-11-18 06:01:19.628124+00	ok	288	138	1	\N
6	coles	\N	2026-11-18 06:01:20.495288+00	2026-11-18 06:01:33.102593+00	ok	140	106	52	\N
7	woolworths	\N	2026-11-18 06:02:56.756673+00	2026-11-18 06:03:07.50161+00	ok	288	104	51	\N
8	coles	\N	2026-11-18 06:03:08.366473+00	2026-11-18 06:03:08.585136+00	error	0	0	0	buildId: could not extract buildId from coles.com.au homepage
9	coles	\N	2026-11-18 06:04:27.059458+00	2026-11-18 06:04:39.708741+00	ok	140	77	24	\N
10	spudshed	\N	2026-11-18 06:04:57.551181+00	2026-11-18 06:05:19.051763+00	ok	487	412	0	\N
11	woolworths	\N	2026-11-18 06:05:19.909648+00	2026-11-18 06:05:30.670281+00	ok	288	104	51	\N
12	coles	\N	2026-11-18 06:05:31.548806+00	2026-11-18 06:05:31.831517+00	error	0	0	0	buildId: could not extract buildId from coles.com.au homepage
13	spudshed	\N	2026-11-18 06:05:59.674322+00	2026-11-18 06:06:19.792632+00	ok	487	3	1	\N
14	coles	\N	2026-11-18 06:08:17.287537+00	2026-11-18 06:08:32.706289+00	error	0	0	0	buildId: could not obtain buildId (bot wall)
15	spudshed	\N	2026-11-18 07:00:36.673752+00	2026-11-18 07:00:56.906122+00	ok	487	0	0	\N
16	woolworths	\N	2026-11-18 07:03:37.512706+00	2026-11-18 07:03:48.469874+00	ok	288	0	0	\N
17	spudshed	\N	2026-11-18 14:08:56.502147+00	2026-11-18 14:09:16.67237+00	ok	487	52	8	\N
18	spudshed	\N	2026-11-18 20:08:56.507282+00	2026-11-18 20:09:16.768282+00	ok	487	0	0	\N
19	woolworths	\N	2026-11-18 21:20:00.001424+00	2026-11-18 21:20:11.188665+00	ok	288	4	3	\N
20	coles	\N	2026-11-18 21:45:00.003691+00	2026-11-18 21:45:12.393097+00	ok	140	78	17	\N
21	spudshed	\N	2026-11-19 02:08:56.498467+00	2026-11-19 02:09:16.825221+00	ok	487	422	1	\N
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: drinkwatch
--

COPY public.stores (id, chain_id, name, suburb, state, postcode, lat, lon, website, external_ref, is_active, created_at) FROM stdin;
17	7	Caltex Naval Base	Naval Base	WA	6165	-32.2064169	115.7848158	https://betterchoicefuel.com.au/	osm:node/419627400	t	2026-11-18 05:53:55.180371+00
20	2	Coles	Karawara	WA	6152	-32.0105446	115.8864897	https://www.coles.com.au/	osm:node/454837973	t	2026-11-18 05:53:55.180371+00
30	4	Tucker Fresh Broadway IGA	Crawley	WA	6009	-31.9841144	115.8149978	https://tuckerfreshiga.com.au/broadway/	osm:node/569968915	t	2026-11-18 05:53:55.180371+00
37	4	Belvidere Supa IGA	Belmont	WA	6104	-31.9464247	115.9403955	https://www.iga.com.au/	osm:node/606292009	t	2026-11-18 05:53:55.180371+00
38	7	Caltex Belmont	Belmont	WA	6104	-31.9464114	115.9395674	\N	osm:node/606292014	t	2026-11-18 05:53:55.180371+00
40	4	IGA	Joondalup	WA	6027	-31.7283422	115.764633	\N	osm:node/610757925	t	2026-11-18 05:53:55.180371+00
48	4	Glen Forrest IGA	Glen Forrest	WA	6071	-31.9034502	116.1038238	\N	osm:node/663490342	t	2026-11-18 05:53:55.180371+00
58	7	Caltex	Como	WA	6152	-31.9989132	115.8624154	\N	osm:node/853323890	t	2026-11-18 05:53:55.180371+00
60	7	EG Australia	Warnbro	WA	6169	-32.3458481	115.7615305	\N	osm:node/865859032	t	2026-11-18 05:53:55.180371+00
67	1	Woolworths	Dianella	WA	6059	-31.8951749	115.8721954	https://www.woolworths.com.au/	osm:node/1361288034	t	2026-11-18 05:53:55.180371+00
68	2	Coles	Dianella	WA	6059	-31.8953433	115.8711279	https://www.coles.com.au/	osm:node/1361288079	t	2026-11-18 05:53:55.180371+00
78	4	IGA	Bertram	WA	6167	-32.2462658	115.8466483	\N	osm:node/1653778835	t	2026-11-18 05:53:55.180371+00
88	4	IGA Maylands	Maylands	WA	6051	-31.9302452	115.8959565	http://maylandsparkiga.com.au	osm:node/1973347833	t	2026-11-18 05:53:55.180371+00
114	4	IGA X-press	Aubin Grove	WA	6164	-32.1678487	115.8616113	https://www.iga.com.au	osm:node/2479734231	t	2026-11-18 05:53:55.180371+00
129	1	Woolworths	Palmyra	WA	6157	-32.0387596	115.7772526	https://www.woolworths.com.au/	osm:node/2583203053	t	2026-11-18 05:53:55.180371+00
176	7	Caltex	Barragup	WA	6209	-32.5573897	115.7868958	\N	osm:node/4756706427	t	2026-11-18 05:53:55.180371+00
182	7	EG Ampol South Lake	South Lake	WA	6164	-32.1152601	115.8371988	https://eg-australia.com	osm:node/5008551423	t	2026-11-18 05:53:55.180371+00
160	3	Spudshed	Morley	WA	6062	-31.8950402	115.8944663	https://www.spudshed.com.au/	osm:node/4449999091	f	2026-11-18 05:53:55.180371+00
130	4	IGA Leeming	Leeming	WA	\N	-32.0786077	115.8571111	\N	osm:node/2629986137	t	2026-11-18 05:53:55.180371+00
131	7	Ampol Butler	Butler	WA	\N	-31.6258963	115.7185958	\N	osm:node/2655194154	t	2026-11-18 05:53:55.180371+00
197	2	Coles	High Wycombe	WA	6057	-31.9349221	116.0048017	https://www.coles.com.au/	osm:node/5869781682	t	2026-11-18 05:53:55.180371+00
211	7	Caltex	Victoria Park	WA	6100	-31.9698365	115.8921452	\N	osm:node/6943158251	t	2026-11-18 05:53:55.180371+00
214	7	Ampol Foodary Rockingham	Rockingham	WA	6168	-32.2768769	115.7499224	\N	osm:node/7105904840	t	2026-11-18 05:53:55.180371+00
219	4	IGA	Wembley Downs	WA	6019	-31.9106748	115.7741906	\N	osm:node/7440010681	t	2026-11-18 05:53:55.180371+00
232	4	IGA Balga	Balga	WA	6061	-31.8561756	115.83806	https://iga.com.au/	osm:node/8788466896	t	2026-11-18 05:53:55.180371+00
233	5	7-Eleven Balga	Balga	WA	6061	-31.8564856	115.8375112	\N	osm:node/8788466910	t	2026-11-18 05:53:55.180371+00
250	8	BP	Baldivis	WA	\N	-32.3095986	115.7965165	\N	osm:node/8978989617	t	2026-11-18 05:53:55.180371+00
252	7	Caltex Roleystone	Roleystone	WA	6111	-32.1157007	116.0832658	\N	osm:node/9236674762	t	2026-11-18 05:53:55.180371+00
217	3	Spudshed	Innaloo	WA	\N	-31.8994268	115.8012012	https://www.spudshed.com.au/store-location-innaloo/	osm:node/7349754234	f	2026-11-18 05:53:55.180371+00
192	4	IGA Bedford	Bedford	WA	\N	-31.9102834	115.8878788	\N	osm:node/5656169221	t	2026-11-18 05:53:55.180371+00
193	8	BP Welshpool	Welshpool	WA	\N	-31.9862627	115.9371139	https://map.bp.com/en-AU/AU/gas-station/kewdale/bp-welshpool/7772	osm:node/5755367521	t	2026-11-18 05:53:55.180371+00
194	2	Coles Subiaco	Subiaco	WA	\N	-31.9438496	115.8228937	https://www.coles.com.au/	osm:node/5785330344	t	2026-11-18 05:53:55.180371+00
195	2	Coles Floreat	Floreat	WA	\N	-31.9373759	115.7926134	https://www.coles.com.au/	osm:node/5785372990	t	2026-11-18 05:53:55.180371+00
196	5	7 Eleven Morley	Embleton	WA	\N	-31.9033208	115.9030524	\N	osm:node/5865959685	t	2026-11-18 05:53:55.180371+00
255	1	Woolworths	Hocking	WA	6065	-31.769039	115.8195949	https://woolworths.com.au	osm:node/9432344154	t	2026-11-18 05:53:55.180371+00
268	7	Caltex	Byford	WA	6122	-32.2074316	115.9776422	\N	osm:node/9920273685	t	2026-11-18 05:53:55.180371+00
289	6	Vibe Subiaco	Subiaco	WA	6008	-31.9522258	115.8310223	\N	osm:node/10910595555	t	2026-11-18 05:53:55.180371+00
290	7	Caltex	Osborne Park	WA	6017	-31.913625	115.8284098	\N	osm:node/10936227645	t	2026-11-18 05:53:55.180371+00
294	8	BP Embleton	Embleton	WA	6062	-31.8950334	115.9234673	https://map.bp.com/en-AU/AU/gas-station/embleton/bp-embleton/8394	osm:node/11133371909	t	2026-11-18 05:53:55.180371+00
300	7	Ampol	\N	WA	\N	-32.6853377	115.7757953	\N	osm:node/11643636059	t	2026-11-18 05:53:55.180371+00
301	7	Ampol	\N	WA	\N	-32.6854235	115.7783407	\N	osm:node/11643636060	t	2026-11-18 05:53:55.180371+00
303	2	Coles	Hillarys	WA	6025	-31.8094455	115.7433867	https://www.coles.com.au/find-stores/coles/wa/hillarys-371	osm:node/11806194535	t	2026-11-18 05:53:55.180371+00
315	7	Caltex	Meadow Springs	WA	6210	-32.493354	115.7471731	\N	osm:node/11834188194	t	2026-11-18 05:53:55.180371+00
322	2	Coles	Caversham	WA	6055	-31.8676448	115.9671875	\N	osm:node/11834413687	t	2026-11-18 05:53:55.180371+00
358	7	Ampol Foodary	Rivervale	WA	6103	-31.9535246	115.9135216	https://locations.ampol.com.au/en/ampol-foodary-rivervale	osm:node/12273576972	t	2026-11-18 05:53:55.180371+00
362	4	The Good Grocer IGA East Fremantle	East Fremantle	WA	6158	-32.0415755	115.7647267	\N	osm:node/12632889780	t	2026-11-18 05:53:55.180371+00
363	4	Tucker Fresh Atwell IGA	Atwell	WA	6164	-32.1363551	115.8669392	\N	osm:node/12750879506	t	2026-11-18 05:53:55.180371+00
364	4	Bullsbrook IGA	Bullsbrook	WA	6084	-31.672481	116.0311544	\N	osm:node/12874602058	t	2026-11-18 05:53:55.180371+00
371	8	BP	Ballajura	WA	6066	-31.8265452	115.8771946	https://map.bp.com/en-AU/AU/gas-station/ballajura/bp-ballajura/6330	osm:node/13202515575	t	2026-11-18 05:53:55.180371+00
375	1	Woolworths	Dayton	WA	6055	-31.8494734	115.9678377	https://www.woolworths.com.au/shop/storelocator/4434	osm:node/13449403703	t	2026-11-18 05:53:55.180371+00
385	4	IGA Local Grocer Westminster	Westminster	WA	6061	-31.8698018	115.8367458	\N	osm:node/14040523156	t	2026-11-18 05:53:55.180371+00
390	7	Ampol Foodary Applecross	Applecross	WA	6153	-32.0114738	115.8509973	\N	osm:way/47414496	t	2026-11-18 05:53:55.180371+00
455	7	Caltex Butler	Butler	WA	6036	-31.6542509	115.7125099	\N	osm:way/826324424	t	2026-11-18 05:53:55.180371+00
323	2	Coles Innaloo	Innaloo	WA	\N	-31.9016049	115.8003459	\N	osm:node/11834415588	t	2026-11-18 05:53:55.180371+00
324	1	Woolworths Innaloo	Innaloo	WA	\N	-31.9003008	115.7997246	\N	osm:node/11834415589	t	2026-11-18 05:53:55.180371+00
396	2	Coles	Inglewood	WA	6052	-31.9164847	115.8903161	https://www.coles.com.au/	osm:way/145169229	t	2026-11-18 05:53:55.180371+00
400	7	Caltex	Hamilton Hill	WA	6163	-32.0931222	115.7830375	\N	osm:way/164843212	t	2026-11-18 05:53:55.180371+00
407	7	Caltex Mount Lawley	Mount Lawley	WA	6050	-31.9253941	115.8819844	\N	osm:way/225708507	t	2026-11-18 05:53:55.180371+00
413	7	Ampol	Canning Vale	WA	6155	-32.0632887	115.9263696	\N	osm:way/290176500	t	2026-11-18 05:53:55.180371+00
420	7	EG Ampol	Greenwood	WA	6024	-31.8217065	115.8204314	\N	osm:way/371361651	t	2026-11-18 05:53:55.180371+00
421	4	IGA Local Grocer Bayswater	Bayswater	WA	6053	-31.9186739	115.9129969	\N	osm:way/376078045	t	2026-11-18 05:53:55.180371+00
422	7	EG Australia	Hillarys	WA	6025	-31.7966846	115.7455657	\N	osm:way/421585857	t	2026-11-18 05:53:55.180371+00
424	2	Coles	Parkwood	WA	6147	-32.0394312	115.9076519	https://www.coles.com.au/	osm:way/441742677	t	2026-11-18 05:53:55.180371+00
425	7	Caltex Star Mart	Madeley	WA	6065	-31.8169381	115.8213854	https://www.caltex.com/au/en.html	osm:way/442376991	t	2026-11-18 05:53:55.180371+00
430	7	Ampol Foodary	Leederville	WA	6007	-31.9366535	115.8400891	\N	osm:way/500805802	t	2026-11-18 05:53:55.180371+00
444	6	Vibe Kalamunda	Kalamunda	WA	6076	-31.9735791	116.0593205	\N	osm:way/715751857	t	2026-11-18 05:53:55.180371+00
454	7	Caltex Yanchep	Yanchep	WA	6035	-31.5477847	115.6414387	\N	osm:way/826052437	t	2026-11-18 05:53:55.180371+00
392	8	BP Nookenburra	Woodlands	WA	\N	-31.9026339	115.7991893	https://map.bp.com/en-AU/AU/gas-station/innaloo/bp-innaloo/6196	osm:way/50775272	t	2026-11-18 05:53:55.180371+00
393	4	IGA Hilton	Hilton	WA	\N	-32.0750412	115.7819925	\N	osm:way/57746295	t	2026-11-18 05:53:55.180371+00
395	7	Ampol Baldivis	Baldivis	WA	\N	-32.3307038	115.8209173	\N	osm:way/136962738	t	2026-11-18 05:53:55.180371+00
466	4	Kalamunda IGA Food Market	Kalamunda	WA	6076	-31.9716424	116.0563878	\N	osm:way/959085124	t	2026-11-18 05:53:55.180371+00
467	8	BP Ellenbrook	Ellenbrook	WA	6069	-31.7755179	115.9630236	https://map.bp.com/en-AU/AU/gas-station/ellenbrook/bp-ellenbrook/9779	osm:way/961833569	t	2026-11-18 05:53:55.180371+00
468	2	Coles	Dawesville	WA	6211	-32.6301251	115.6314772	\N	osm:way/966014172	t	2026-11-18 05:53:55.180371+00
473	1	Woolworths	North Coogee	WA	6163	-32.1030081	115.7625698	https://www.woolworths.com.au/shop/storelocator/wa-north-coogee-4995	osm:way/1035666160	t	2026-11-18 05:53:55.180371+00
487	2	Coles	Yokine	WA	6060	-31.909721	115.8486653	https://www.coles.com.au/find-stores/coles/wa/yokine-347	osm:way/1150051053	t	2026-11-18 05:53:55.180371+00
490	8	BP	Attadale	WA	\N	-32.0315935	115.8089145	https://map.bp.com/en-AU/AU/gas-station/attadale/bp-attadale/6188	osm:way/1167485124	t	2026-11-18 05:53:55.180371+00
502	1	Woolworths	Secret Harbour	WA	6173	-32.4076957	115.7586397	https://www.woolworths.com.au/	osm:way/1298946077	t	2026-11-18 05:53:55.180371+00
520	5	7-Eleven	Mandurah	WA	6210	-32.5355754	115.7369506	\N	osm:way/1410280418	t	2026-11-18 05:53:55.180371+00
523	6	Vibe Morley	Morley	WA	6062	-31.8878431	115.8899552	https://vibepetroleum.com/	osm:way/1416296338	t	2026-11-18 05:53:55.180371+00
525	7	Caltex	Ocean Reef	WA	6027	-31.7652	115.7410734	\N	osm:way/1423554767	t	2026-11-18 05:53:55.180371+00
526	6	Vibe	Jandakot	WA	6164	-32.0906954	115.8689185	https://vibepetroleum.com/	osm:way/1425958471	t	2026-11-18 05:53:55.180371+00
528	8	BP	Jindalee	WA	6036	-31.6363574	115.6895334	https://www.bp.com/en_au/australia.html	osm:way/1426186944	t	2026-11-18 05:53:55.180371+00
533	5	7 Eleven	Bassendean	WA	6054	-31.906354	115.9309724	https://www.7eleven.com.au/	osm:way/1437032108	t	2026-11-18 05:53:55.180371+00
534	6	Vibe Roadhouse Upper Swan	Upper Swan	WA	6069	-31.7658248	116.0317231	\N	osm:way/1453266126	t	2026-11-18 05:53:55.180371+00
535	5	7-Eleven	Dayton	WA	6055	-31.8480176	115.9672522	\N	osm:way/1466371808	t	2026-11-18 05:53:55.180371+00
536	5	7-Eleven	Malaga	WA	6090	-31.8567309	115.9077772	https://www.7eleven.com.au/	osm:way/1466665542	t	2026-11-18 05:53:55.180371+00
538	1	Woolworths	Perth Airport	WA	6105	-31.9364336	115.9492065	\N	osm:way/1493312188	t	2026-11-18 05:53:55.180371+00
543	7	Caltex Glen Forrest	Glen Forrest	WA	6071	-31.9033273	116.1047151	\N	osm:way/1527839159	t	2026-11-18 05:53:55.180371+00
518	1	Woolworths Mundaring	Mundaring	WA	\N	-31.9012591	116.1643292	https://www.woolworths.com.au/	osm:way/1365106169	t	2026-11-18 05:53:55.180371+00
140	3	Spudshed	Karawara	WA	\N	-32.0116073	115.8852585	https://www.spudshed.com.au/?stores=waterford-store	osm:node/3128673471	f	2026-11-18 05:53:55.180371+00
188	3	Spudshed	Bentley	WA	\N	-32.0008075	115.9202626	https://www.spudshed.com.au/	osm:node/5580587912	f	2026-11-18 05:53:55.180371+00
215	3	Spudshed	Spearwood	WA	\N	-32.115701	115.7833445	https://www.spudshed.com.au/	osm:node/7349754224	f	2026-11-18 05:53:55.180371+00
216	3	Spudshed	Thornlie	WA	\N	-32.0556928	115.9628318	\N	osm:node/7349754232	f	2026-11-18 05:53:55.180371+00
218	3	Spudshed	Wangara	WA	6065	-31.7904885	115.8214782	https://www.spudshed.com.au/spudshed-wanneroo/	osm:node/7349754235	f	2026-11-18 05:53:55.180371+00
221	3	Spudshed	Bellevue	WA	\N	-31.896666	116.0167683	https://www.spudshed.com.au	osm:node/7676055787	f	2026-11-18 05:53:55.180371+00
235	3	Spudshed	Ellenbrook	WA	\N	-31.778257	115.9639456	https://www.spudshed.com.au	osm:node/8897219933	f	2026-11-18 05:53:55.180371+00
336	3	Spudshed	Westminster	WA	\N	-31.8630324	115.8292451	\N	osm:node/11861796049	f	2026-11-18 05:53:55.180371+00
372	3	Spudshed	Joondalup	WA	\N	-31.7566103	115.7707967	\N	osm:node/13236536912	f	2026-11-18 05:53:55.180371+00
386	3	Spudshed	Upper Swan	WA	\N	-31.7657276	116.0315959	\N	osm:node/14106525956	f	2026-11-18 05:53:55.180371+00
405	3	Spudshed	Jandakot	WA	6164	-32.0901687	115.870598	https://www.spudshed.com.au/?stores=store-location-jandakot	osm:way/203456654	f	2026-11-18 05:53:55.180371+00
429	3	Spudshed	Baldivis	WA	6171	-32.2983447	115.8075931	https://baldivis.spudshed.com.au/	osm:way/490524365	f	2026-11-18 05:53:55.180371+00
519	8	BP Morley	Morley	WA	\N	-31.8945855	115.896709	\N	osm:way/1391313231	t	2026-11-18 05:53:55.180371+00
521	8	BP Coodanup	Coodanup	WA	\N	-32.5357824	115.7376707	\N	osm:way/1410280421	t	2026-11-18 05:53:55.180371+00
522	7	Foodary	North Yunderup	WA	\N	-32.5670409	115.7981744	\N	osm:way/1410879096	t	2026-11-18 05:53:55.180371+00
524	4	IGA Maylands	Maylands	WA	\N	-31.9290435	115.8918598	\N	osm:way/1420201700	t	2026-11-18 05:53:55.180371+00
527	5	7 Eleven	Butler	WA	\N	-31.6354216	115.7058297	\N	osm:way/1426176956	t	2026-11-18 05:53:55.180371+00
529	5	7-Eleven Brabham	Brabham	WA	\N	-31.8328026	115.9682485	\N	osm:way/1426516644	t	2026-11-18 05:53:55.180371+00
530	7	EG Ampol	Brabham	WA	\N	-31.832945	115.9670392	\N	osm:way/1426516647	t	2026-11-18 05:53:55.180371+00
531	8	BP Forrestdale	Haynes	WA	\N	-32.1375001	115.9695436	https://map.bp.com/en-AU/AU/gas-station/forrestdale/bp-forrestdale/8609	osm:way/1430883272	t	2026-11-18 05:53:55.180371+00
532	5	7-Eleven Mindarie	Mindarie	WA	\N	-31.692922	115.719068	\N	osm:way/1435593422	t	2026-11-18 05:53:55.180371+00
537	1	Woolworths Armadale	Armadale	WA	\N	-32.1492294	116.0148516	\N	osm:way/1475042426	t	2026-11-18 05:53:55.180371+00
539	1	Woolworths Baldivis	Baldivis	WA	\N	-32.3334295	115.8167837	https://www.woolworths.com.au/	osm:way/1499819395	t	2026-11-18 05:53:55.180371+00
540	2	Coles Baldivis	Baldivis	WA	\N	-32.332239	115.814819	https://www.coles.com.au/	osm:way/1499819428	t	2026-11-18 05:53:55.180371+00
541	5	7-Eleven Caversham	Caversham	WA	\N	-31.8754297	115.9743708	\N	osm:way/1512021717	t	2026-11-18 05:53:55.180371+00
542	6	Vibe Cooloongup	Cooloongup	WA	\N	-32.2977726	115.8073884	\N	osm:way/1524469913	t	2026-11-18 05:53:55.180371+00
450	3	Spudshed	Kelmscott	WA	\N	-32.1149647	116.0145076	https://www.spudshed.com.au/	osm:way/786101507	f	2026-11-18 05:53:55.180371+00
546	3	Spudshed	Furnissdale	WA	\N	-32.5491254	115.773876	\N	osm:way/1530388473	f	2026-11-18 05:53:55.180371+00
554	3	SpudShed Baldivis	Baldivis	WA	6171	-32.2984551	115.8075738	https://baldivis.spudshed.com.au	spudshed:baldivis	t	2026-11-18 05:56:39.481001+00
555	3	SpudShed Kelmscott	Kelmscott	WA	6111	-32.1106962	116.0129832	https://kelmscott.spudshed.com.au	spudshed:kelmscott	t	2026-11-18 05:56:39.481001+00
557	3	SpudShed Perth	Perth	WA	6102	\N	\N	\N	spudshed:perth	f	2026-11-18 05:57:23.948386+00
558	3	SpudShed Bunbury	Bunbury	WA	6230	-33.3371927	115.657774	https://bunbury.spudshed.com.au	spudshed:bunbury	t	2026-11-18 05:57:23.948386+00
559	3	SpudShed Karlkurla	Karlkurla	WA	6430	\N	\N	\N	spudshed:karlkurla	f	2026-11-18 05:57:23.948386+00
560	3	SpudShed Karawara	Karawara	WA	6152	\N	\N	\N	spudshed:karawara	f	2026-11-18 05:57:23.948386+00
556	3	SpudShed Ballajura	Ballajura	WA	6066	-31.8400042	115.8960089	https://ballajura.spudshed.com.au	spudshed:ballajura	t	2026-11-18 05:57:23.948386+00
561	3	SpudShed Bentley Plaza	Perth	WA	6102	-32.0039488	115.9076043	https://bentleyplaza.spudshed.com.au	spudshed:bentleyplaza	t	2026-11-18 05:58:00.152652+00
562	3	SpudShed Kalgoorlie	Karlkurla	WA	6430	-30.7376165	121.4283698	https://kalgoorlie.spudshed.com.au	spudshed:kalgoorlie	t	2026-11-18 05:58:00.152652+00
563	3	SpudShed Waterford	Karawara	WA	6152	-32.0086201	115.8812666	https://waterford.spudshed.com.au	spudshed:waterford	t	2026-11-18 05:58:00.152652+00
1	7	Ampol Crawley	Crawley	WA	\N	-31.9776186	115.813663	\N	osm:node/33121767	t	2026-11-18 05:53:55.180371+00
2	7	Caltex	North Perth	WA	\N	-31.9367299	115.8578969	\N	osm:node/33121776	t	2026-11-18 05:53:55.180371+00
3	2	Coles Thornlie	Thornlie	WA	\N	-32.0691928	115.9500425	https://www.coles.com.au/	osm:node/117191633	t	2026-11-18 05:53:55.180371+00
4	7	Ampol Falcon	Falcon	WA	\N	-32.5811097	115.6614449	\N	osm:node/188774820	t	2026-11-18 05:53:55.180371+00
5	8	BP Halls Head	Halls Head	WA	\N	-32.5506147	115.7014428	https://map.bp.com/en-AU/AU/gas-station/halls-head/bp-halls-head/6170	osm:node/189480425	t	2026-11-18 05:53:55.180371+00
6	7	Caltex Langford	Lynwood	WA	\N	-32.0472561	115.9324946	https://caltex.com	osm:node/197129809	t	2026-11-18 05:53:55.180371+00
7	7	Caltex	Canning Vale	WA	\N	-32.0870392	115.9165644	\N	osm:node/197132644	t	2026-11-18 05:53:55.180371+00
8	2	Coles Kalamunda	Kalamunda	WA	\N	-31.9728148	116.0594191	https://www.coles.com.au/find-stores/coles/wa/kalamunda-394	osm:node/270862126	t	2026-11-18 05:53:55.180371+00
9	4	IGA Lesmurdie	Lesmurdie	WA	\N	-32.0056818	116.0453216	\N	osm:node/271831572	t	2026-11-18 05:53:55.180371+00
10	4	Lesmurdie IGA	Lesmurdie	WA	\N	-31.9994832	116.0526559	\N	osm:node/271842300	t	2026-11-18 05:53:55.180371+00
11	7	Caltex Wattle Grove	Wattle Grove	WA	\N	-32.0063657	115.9888378	\N	osm:node/275807535	t	2026-11-18 05:53:55.180371+00
12	7	Ampol Westminster	Westminster	WA	\N	-31.8680735	115.8299432	\N	osm:node/277838662	t	2026-11-18 05:53:55.180371+00
13	4	IGA Brentwood	Brentwood	WA	\N	-32.0407309	115.8488442	\N	osm:node/292193983	t	2026-11-18 05:53:55.180371+00
14	7	Ampol Mosman Park	Mosman Park	WA	\N	-32.012002	115.7556011	\N	osm:node/342653147	t	2026-11-18 05:53:55.180371+00
15	1	Woolworths Perth Cultural Centre	Perth Cultural Centre	WA	\N	-31.9530101	115.8604222	https://www.woolworths.com.au/	osm:node/369959816	t	2026-11-18 05:53:55.180371+00
16	2	Coles Scarborough	Scarborough	WA	\N	-31.8952171	115.7573181	https://www.coles.com.au/	osm:node/370584885	t	2026-11-18 05:53:55.180371+00
18	8	BP Karnup	Golden Bay	WA	\N	-32.4274142	115.7746261	https://map.bp.com/en-AU/AU/gas-station/karnup/bp-floopers-roadhouse/4088	osm:node/419635404	t	2026-11-18 05:53:55.180371+00
19	4	Carine Glades IGA	Carine	WA	\N	-31.8451629	115.7866831	\N	osm:node/442399824	t	2026-11-18 05:53:55.180371+00
21	4	IGA Ballajura	Ballajura	WA	\N	-31.8403974	115.8965069	\N	osm:node/484136080	t	2026-11-18 05:53:55.180371+00
22	1	Woolworths Kingsley	Kingsley	WA	\N	-31.7988803	115.7943719	https://www.woolworths.com.au/	osm:node/493879801	t	2026-11-18 05:53:55.180371+00
23	4	IGA Kingsley	Kingsley	WA	\N	-31.8079123	115.7898643	https://www.iga.com.au/stores/all-foods-market-kingsley-iga/	osm:node/493880391	t	2026-11-18 05:53:55.180371+00
24	8	BP Kingsley	Kingsley	WA	\N	-31.7998505	115.7960456	https://map.bp.com/en-AU/AU/gas-station/woodvale/bp-woodvale/6141	osm:node/493881342	t	2026-11-18 05:53:55.180371+00
25	4	Supa IGA	Merriwa	WA	\N	-31.6695671	115.7163621	\N	osm:node/505063722	t	2026-11-18 05:53:55.180371+00
26	4	IGA Rivervale	Rivervale	WA	\N	-31.9628555	115.9148112	\N	osm:node/553017719	t	2026-11-18 05:53:55.180371+00
27	4	Wembley IGA	Jolimont	WA	\N	-31.9403904	115.8125282	\N	osm:node/560730916	t	2026-11-18 05:53:55.180371+00
28	8	BP Canning Vale	Canning Vale	WA	\N	-32.0821462	115.9089727	https://map.bp.com/en-AU/AU/gas-station/canning-vale/bp-canning-vale/9073	osm:node/567276116	t	2026-11-18 05:53:55.180371+00
29	2	Coles Mundaring	Mundaring	WA	\N	-31.9006681	116.1667639	https://www.coles.com.au/	osm:node/567375048	t	2026-11-18 05:53:55.180371+00
31	4	IGA Cottesloe	Cottesloe	WA	\N	-31.9893206	115.7570638	\N	osm:node/571457770	t	2026-11-18 05:53:55.180371+00
32	4	IGA Nedlands	Nedlands	WA	\N	-31.9810747	115.7949756	\N	osm:node/583312274	t	2026-11-18 05:53:55.180371+00
33	8	BP Kardinya	Kardinya	WA	\N	-32.0690363	115.8200935	https://map.bp.com/en-AU/AU/gas-station/kardinya/bp-kardinya/6207	osm:node/585127612	t	2026-11-18 05:53:55.180371+00
34	8	BP Willetton	Willetton	WA	\N	-32.0582345	115.8819465	https://map.bp.com/en-AU/AU/gas-station/willetton/bp-burrendah/1812	osm:node/585127625	t	2026-11-18 05:53:55.180371+00
35	2	Coles West Leederville	West Leederville	WA	\N	-31.9409408	115.833644	https://www.coles.com.au/	osm:node/600291937	t	2026-11-18 05:53:55.180371+00
36	7	Ampol Belmont	Ascot	WA	\N	-31.9376479	115.9331621	\N	osm:node/606288940	t	2026-11-18 05:53:55.180371+00
39	1	Woolworths Subiaco	Subiaco	WA	\N	-31.9439149	115.8238993	https://www.woolworths.com.au/	osm:node/606771186	t	2026-11-18 05:53:55.180371+00
41	2	Coles Mindarie	Mindarie	WA	\N	-31.690367	115.717247	https://www.coles.com.au/	osm:node/628498696	t	2026-11-18 05:53:55.180371+00
42	7	Ampol Murdoch	Murdoch	WA	\N	-32.0632539	115.8355649	\N	osm:node/634961621	t	2026-11-18 05:53:55.180371+00
43	7	Ampol Warwick	Warwick	WA	\N	-31.846276	115.7955266	\N	osm:node/634961758	t	2026-11-18 05:53:55.180371+00
44	7	EG Ampol	Morley	WA	\N	-31.8962595	115.8950926	\N	osm:node/634961885	t	2026-11-18 05:53:55.180371+00
45	4	Como IGA	Como	WA	\N	-31.9942992	115.8588372	\N	osm:node/638210070	t	2026-11-18 05:53:55.180371+00
46	4	South Fremantle IGA	South Fremantle	WA	\N	-32.070499	115.7575342	\N	osm:node/662688678	t	2026-11-18 05:53:55.180371+00
111	4	IGA Nollamara	Nollamara	WA	6061	-31.8808544	115.8416482	\N	osm:node/2372939407	t	2026-11-18 05:53:55.180371+00
47	1	Woolworths South Fremantle	South Fremantle	WA	\N	-32.0747386	115.7593784	https://www.woolworths.com.au/	osm:node/662714517	t	2026-11-18 05:53:55.180371+00
49	4	Huntingdale IGA	Huntingdale	WA	\N	-32.0819239	115.9674809	\N	osm:node/697352042	t	2026-11-18 05:53:55.180371+00
50	4	Helena Valley IGA	Helena Valley	WA	\N	-31.9156695	116.0288814	\N	osm:node/702492538	t	2026-11-18 05:53:55.180371+00
51	1	Woolworths Forest Lakes	Thornlie	WA	\N	-32.068476	115.9491666	https://www.woolworths.com.au/	osm:node/703160534	t	2026-11-18 05:53:55.180371+00
52	4	IGA Mount Hawthorn	Mount Hawthorn	WA	6016	-31.921053	115.83786	\N	osm:node/729465529	t	2026-11-18 05:53:55.180371+00
53	4	Royal Street IGA	East Perth	WA	\N	-31.9533634	115.8773036	https://www.iga.com.au/stores/#view=storedetail&storeId=15337	osm:node/738801163	t	2026-11-18 05:53:55.180371+00
54	4	Supa IGA	Kinross	WA	\N	-31.7181564	115.7415809	\N	osm:node/741059550	t	2026-11-18 05:53:55.180371+00
55	1	Woolworths Victoria Park	Victoria Park	WA	\N	-31.9734714	115.8980718	https://www.woolworths.com.au/	osm:node/761868380	t	2026-11-18 05:53:55.180371+00
56	4	Woodlake IGA	Ellenbrook	WA	\N	-31.7920135	115.9737497	\N	osm:node/778167277	t	2026-11-18 05:53:55.180371+00
57	4	IGA Swan View	Swan View	WA	\N	-31.8854805	116.0422634	\N	osm:node/822127155	t	2026-11-18 05:53:55.180371+00
59	4	IGA Doubleview	Doubleview	WA	\N	-31.8943826	115.7772813	\N	osm:node/860203453	t	2026-11-18 05:53:55.180371+00
61	4	Stratton Supa IGA	Stratton	WA	\N	-31.8692377	116.0349755	\N	osm:node/888701481	t	2026-11-18 05:53:55.180371+00
62	4	IGA North Lake	North Lake	WA	\N	-32.0923839	115.8410908	\N	osm:node/1129460057	t	2026-11-18 05:53:55.180371+00
63	2	Coles Bibra Lake	Bibra Lake	WA	\N	-32.1062755	115.8275641	https://www.coles.com.au/	osm:node/1143263494	t	2026-11-18 05:53:55.180371+00
64	2	Coles Cockburn Central	Cockburn Central	WA	\N	-32.1319974	115.8565183	https://www.coles.com.au/	osm:node/1143293760	t	2026-11-18 05:53:55.180371+00
65	1	Woolworths Cockburn Central	Cockburn Central	WA	\N	-32.1326292	115.8581238	https://www.woolworths.com.au/	osm:node/1143293765	t	2026-11-18 05:53:55.180371+00
66	4	IGA Canning Vale	Canning Vale	WA	\N	-32.0941684	115.9252729	\N	osm:node/1226368472	t	2026-11-18 05:53:55.180371+00
69	1	Woolworths Morley	Morley	WA	\N	-31.8985868	115.8998824	https://www.woolworths.com.au/	osm:node/1361315776	t	2026-11-18 05:53:55.180371+00
70	2	Coles Morley	Morley	WA	\N	-31.8966831	115.8988417	https://www.coles.com.au/	osm:node/1361315803	t	2026-11-18 05:53:55.180371+00
71	4	IGA Tuart Hill	Tuart Hill	WA	\N	-31.8976781	115.8287535	\N	osm:node/1361337831	t	2026-11-18 05:53:55.180371+00
72	6	Vibe Pinjarra	Pinjarra	WA	\N	-32.6309471	115.8726087	\N	osm:node/1447943197	t	2026-11-18 05:53:55.180371+00
73	2	Coles Cloverdale	Cloverdale	WA	\N	-31.9645245	115.934358	https://www.coles.com.au/	osm:node/1456898271	t	2026-11-18 05:53:55.180371+00
74	1	Woolworths Ellenbrook	Ellenbrook	WA	\N	-31.7831214	115.968499	https://www.woolworths.com.au/	osm:node/1473222546	t	2026-11-18 05:53:55.180371+00
75	2	Coles Ellenbrook	Ellenbrook	WA	\N	-31.781925	115.970274	https://www.coles.com.au/	osm:node/1473222548	t	2026-11-18 05:53:55.180371+00
76	4	IGA Langford	Langford	WA	\N	-32.0454848	115.9527195	\N	osm:node/1564597728	t	2026-11-18 05:53:55.180371+00
77	7	Caltex	Mount Lawley	WA	\N	-31.9345268	115.8840759	\N	osm:node/1596154053	t	2026-11-18 05:53:55.180371+00
79	4	Supa IGA	Midland	WA	\N	-31.8909404	116.0040084	\N	osm:node/1708116703	t	2026-11-18 05:53:55.180371+00
80	1	Woolworths Peppermint Grove	Peppermint Grove	WA	\N	-31.9981521	115.7637511	https://www.woolworths.com.au/	osm:node/1800662996	t	2026-11-18 05:53:55.180371+00
81	8	BP Clarkson	Clarkson	WA	\N	-31.6770231	115.7111153	https://map.bp.com/en-AU/AU/gas-station/mindarie/bp-mindarie/7737	osm:node/1951595836	t	2026-11-18 05:53:55.180371+00
82	1	Woolworths Mindarie	Mindarie	WA	\N	-31.6919219	115.7173226	https://www.woolworths.com.au/	osm:node/1953180303	t	2026-11-18 05:53:55.180371+00
83	7	Caltex	Mindarie	WA	\N	-31.6936511	115.7137009	\N	osm:node/1959195576	t	2026-11-18 05:53:55.180371+00
84	4	Shoalwater IGA	Shoalwater	WA	\N	-32.2931138	115.7100726	\N	osm:node/1960750820	t	2026-11-18 05:53:55.180371+00
85	4	IGA Shoalwater	Shoalwater	WA	\N	-32.2924268	115.7218529	\N	osm:node/1960750862	t	2026-11-18 05:53:55.180371+00
86	1	Woolworths Rockingham	Rockingham	WA	\N	-32.2900588	115.7451351	https://www.woolworths.com.au/	osm:node/1960888124	t	2026-11-18 05:53:55.180371+00
87	2	Coles Rockingham	Rockingham	WA	\N	-32.2905521	115.7422694	https://www.coles.com.au/	osm:node/1960888133	t	2026-11-18 05:53:55.180371+00
89	2	Coles Maylands	Maylands	WA	6051	-31.9297804	115.8976296	https://www.coles.com.au/	osm:node/1973347834	t	2026-11-18 05:53:55.180371+00
90	7	Caltex	Malaga	WA	\N	-31.8529376	115.8820294	\N	osm:node/1976209749	t	2026-11-18 05:53:55.180371+00
91	4	IGA Merriwa	Merriwa	WA	\N	-31.6723085	115.7077782	\N	osm:node/1994421678	t	2026-11-18 05:53:55.180371+00
92	1	Woolworths Kalamunda	Kalamunda	WA	\N	-31.9839625	116.0647749	https://www.woolworths.com.au/	osm:node/1994975943	t	2026-11-18 05:53:55.180371+00
93	7	Ampol Foodary	Byford	WA	\N	-32.2264249	116.0079827	https://locations.ampol.com.au/en/ampol-foodary-byford	osm:node/1996942892	t	2026-11-18 05:53:55.180371+00
94	6	Vibe Service Station	Byford	WA	\N	-32.2212262	116.0091485	\N	osm:node/1996942908	t	2026-11-18 05:53:55.180371+00
95	7	Ampol Canning Vale	Canning Vale	WA	\N	-32.0730149	115.9255932	\N	osm:node/2010742965	t	2026-11-18 05:53:55.180371+00
96	8	BP Pearsall	Pearsall	WA	\N	-31.7821274	115.8084952	\N	osm:node/2030052980	t	2026-11-18 05:53:55.180371+00
97	4	IGA Port Kennedy	Port Kennedy	WA	\N	-32.3671282	115.7546703	\N	osm:node/2099258315	t	2026-11-18 05:53:55.180371+00
98	8	BP Warnbro	Warnbro	WA	\N	-32.3481689	115.7616999	https://map.bp.com/en-AU/AU/gas-station/warnbro/bp-palm-springs/6255	osm:node/2099307809	t	2026-11-18 05:53:55.180371+00
99	7	Ampol Warnbro	Warnbro	WA	\N	-32.3288065	115.7588568	\N	osm:node/2099309534	t	2026-11-18 05:53:55.180371+00
100	7	Caltex Warnbro	Waikiki	WA	\N	-32.3261299	115.74976	\N	osm:node/2099602770	t	2026-11-18 05:53:55.180371+00
101	2	Coles Warnbro	Warnbro	WA	\N	-32.3470702	115.7628321	https://www.coles.com.au/	osm:node/2100155735	t	2026-11-18 05:53:55.180371+00
102	1	Woolworths Warnbro	Warnbro	WA	\N	-32.3465195	115.7629528	https://www.woolworths.com.au/	osm:node/2100155804	t	2026-11-18 05:53:55.180371+00
103	4	Manning IGA	Manning	WA	\N	-32.0149034	115.8685258	\N	osm:node/2147152562	t	2026-11-18 05:53:55.180371+00
104	2	Coles Cannington	Cannington	WA	\N	-32.0211161	115.9396085	https://www.coles.com.au/find-stores/coles/wa/cannington-322	osm:node/2206032459	t	2026-11-18 05:53:55.180371+00
105	1	Woolworths Cannington	Cannington	WA	\N	-32.0173448	115.9398308	https://www.woolworths.com.au/	osm:node/2206032575	t	2026-11-18 05:53:55.180371+00
106	1	Woolworths Willetton	Willetton	WA	\N	-32.0570524	115.8793498	https://www.woolworths.com.au/	osm:node/2216225133	t	2026-11-18 05:53:55.180371+00
107	2	Coles Willetton	Willetton	WA	\N	-32.0583869	115.8802194	https://www.coles.com.au/	osm:node/2216225139	t	2026-11-18 05:53:55.180371+00
108	1	Woolworths Canning Vale	Canning Vale	WA	\N	-32.0855719	115.9163773	https://www.woolworths.com.au/	osm:node/2256539081	t	2026-11-18 05:53:55.180371+00
109	4	IGA Duncraig	Duncraig	WA	\N	-31.8314443	115.7694218	\N	osm:node/2287705832	t	2026-11-18 05:53:55.180371+00
110	4	IGA Hamilton Hill	Hamilton Hill	WA	\N	-32.0891422	115.7910916	\N	osm:node/2337818722	t	2026-11-18 05:53:55.180371+00
112	4	Rostrata IGA X-press	Willetton	WA	\N	-32.0497673	115.8981359	http://stores.iga.com.au/store/rostrata-iga-x-press.html	osm:node/2467962937	t	2026-11-18 05:53:55.180371+00
113	2	Coles Halls Head	Halls Head	WA	\N	-32.5487322	115.7036291	https://www.coles.com.au/	osm:node/2470724940	t	2026-11-18 05:53:55.180371+00
115	4	IGA Halls Head	Halls Head	WA	\N	-32.5361318	115.713985	\N	osm:node/2490899321	t	2026-11-18 05:53:55.180371+00
116	4	Rossmoyne IGA	Rossmoyne	WA	\N	-32.0390439	115.8682845	\N	osm:node/2498430142	t	2026-11-18 05:53:55.180371+00
117	1	Woolworths Currambine	Currambine	WA	\N	-31.741396	115.7397111	https://www.woolworths.com.au/	osm:node/2509205803	t	2026-11-18 05:53:55.180371+00
118	1	Woolworths Joondalup	Joondalup	WA	\N	-31.7431511	115.7667287	https://www.woolworths.com.au/	osm:node/2509339458	t	2026-11-18 05:53:55.180371+00
119	2	Coles Joondalup	Joondalup	WA	\N	-31.7442395	115.7665936	https://www.coles.com.au/	osm:node/2509339459	t	2026-11-18 05:53:55.180371+00
120	4	Sisters Supa IGA	Joondalup	WA	\N	-31.7438335	115.7693295	\N	osm:node/2509339463	t	2026-11-18 05:53:55.180371+00
121	4	IGA Heathridge	Heathridge	WA	\N	-31.7599846	115.7624362	\N	osm:node/2511138472	t	2026-11-18 05:53:55.180371+00
122	4	IGA Ocean Reef	Ocean Reef	WA	\N	-31.7507481	115.7343508	\N	osm:node/2511138473	t	2026-11-18 05:53:55.180371+00
123	4	IGA Edgewater	Edgewater	WA	\N	-31.7728699	115.7885974	\N	osm:node/2511138481	t	2026-11-18 05:53:55.180371+00
124	4	Bentley IGA	Bentley	WA	\N	-32.0090841	115.9023283	\N	osm:node/2513004346	t	2026-11-18 05:53:55.180371+00
125	4	Riverton Fresh IGA	Shelley	WA	\N	-32.0392803	115.8872701	\N	osm:node/2530633811	t	2026-11-18 05:53:55.180371+00
126	4	IGA East Victoria Park	East Victoria Park	WA	\N	-31.984866	115.9037543	https://www.iga.com.au/stores/#view=storedetail&storeId=15338	osm:node/2555547480	t	2026-11-18 05:53:55.180371+00
127	4	IGA Express	Kensington	WA	\N	-31.9830417	115.8884845	\N	osm:node/2555547490	t	2026-11-18 05:53:55.180371+00
128	7	Ampol North Dandalup	North Dandalup	WA	6207	-32.5225732	115.9700648	\N	osm:node/2573027392	t	2026-11-18 05:53:55.180371+00
132	8	BP Kewdale Truckstop	Wattle Grove	WA	\N	-31.9816489	115.9752026	https://map.bp.com/en-AU/AU/gas-station/kewdale/bp-kewdale/2498	osm:node/2669042192	t	2026-11-18 05:53:55.180371+00
133	7	Caltex Star Mart	Malaga	WA	\N	-31.863266	115.8939098	\N	osm:node/2701431576	t	2026-11-18 05:53:55.180371+00
134	4	Pearsall IGA	Pearsall	WA	\N	-31.781085	115.8186154	\N	osm:node/2724808650	t	2026-11-18 05:53:55.180371+00
135	8	BP Cannington	Cannington	WA	\N	-32.0257587	115.941875	https://map.bp.com/en-AU/AU/gas-station/cannington/bp-cannington/6204	osm:node/2949123330	t	2026-11-18 05:53:55.180371+00
136	2	Coles Kardinya	Kardinya	WA	\N	-32.06733	115.8157605	https://www.coles.com.au/	osm:node/2953883893	t	2026-11-18 05:53:55.180371+00
137	4	IGA Beeliar	Beeliar	WA	\N	-32.1320333	115.8167652	\N	osm:node/2983168386	t	2026-11-18 05:53:55.180371+00
138	8	BP Cockburn Central	Cockburn Central	WA	\N	-32.1270576	115.8430712	\N	osm:node/2983168427	t	2026-11-18 05:53:55.180371+00
139	4	IGA Bull Creek	Bull Creek	WA	\N	-32.0572925	115.8647504	\N	osm:node/3071265014	t	2026-11-18 05:53:55.180371+00
141	2	Coles Beldon	Beldon	WA	\N	-31.770053	115.7651747	https://www.coles.com.au/	osm:node/3217078721	t	2026-11-18 05:53:55.180371+00
142	7	Ampol Alfred Cove	Alfred Cove	WA	\N	-32.0312503	115.8152429	\N	osm:node/3266895940	t	2026-11-18 05:53:55.180371+00
143	7	Caltex	Lynwood	WA	\N	-32.0356181	115.927075	\N	osm:node/3267092359	t	2026-11-18 05:53:55.180371+00
144	4	IGA Lynwood	Lynwood	WA	\N	-32.035457	115.9280011	https://lynwood.foodiesmarket.com.au	osm:node/3270608763	t	2026-11-18 05:53:55.180371+00
145	4	IGA Rivervale	Rivervale	WA	\N	-31.9561067	115.9081326	\N	osm:node/3306441774	t	2026-11-18 05:53:55.180371+00
146	8	BP Aveley	Aveley	WA	\N	-31.7960606	115.9784376	https://map.bp.com/en-AU/AU/gas-station/henley-brook/bp-henley-brook/7497	osm:node/3331341424	t	2026-11-18 05:53:55.180371+00
147	8	BP Midvale	Midvale	WA	\N	-31.8864987	116.031064	https://map.bp.com/en-AU/AU/gas-station/midvale/bp-morrison-road/6092	osm:node/3612031598	t	2026-11-18 05:53:55.180371+00
148	1	Woolworths Yanchep	Yanchep	WA	\N	-31.5493145	115.639196	https://www.woolworths.com.au/	osm:node/3741103908	t	2026-11-18 05:53:55.180371+00
149	1	Woolworths Madeley	Madeley	WA	\N	-31.8182438	115.8229764	https://www.woolworths.com.au/	osm:node/3750531779	t	2026-11-18 05:53:55.180371+00
150	1	Woolworths Midland	Midland	WA	\N	-31.8892586	116.008303	https://www.woolworths.com.au/	osm:node/3846802315	t	2026-11-18 05:53:55.180371+00
151	2	Coles Midland	Midland	WA	\N	-31.8890555	116.0122292	https://www.coles.com.au/	osm:node/3846824556	t	2026-11-18 05:53:55.180371+00
152	7	Caltex	Scarborough	WA	\N	-31.894062	115.7645264	\N	osm:node/4024765307	t	2026-11-18 05:53:55.180371+00
153	5	7-Eleven Perth Cultural Centre	Perth Cultural Centre	WA	\N	-31.954665	115.8600282	\N	osm:node/4306851289	t	2026-11-18 05:53:55.180371+00
154	1	Woolworths Mullaloo	Mullaloo	WA	\N	-31.7766987	115.7553281	https://www.woolworths.com.au/	osm:node/4315516148	t	2026-11-18 05:53:55.180371+00
155	4	IGA Craigie	Craigie	WA	\N	-31.784188	115.7668206	\N	osm:node/4315609339	t	2026-11-18 05:53:55.180371+00
156	2	Coles North Perth	North Perth	WA	\N	-31.9322152	115.8584308	https://www.coles.com.au/	osm:node/4393253275	t	2026-11-18 05:53:55.180371+00
157	1	Woolworths Mirrabooka	Mirrabooka	WA	\N	-31.869823	115.860944	https://www.woolworths.com.au/	osm:node/4400693423	t	2026-11-18 05:53:55.180371+00
158	2	Coles Mirrabooka	Mirrabooka	WA	\N	-31.8711626	115.8627733	https://www.coles.com.au/	osm:node/4400693424	t	2026-11-18 05:53:55.180371+00
159	8	BP Highgate	Highgate	WA	\N	-31.942514	115.8673641	https://map.bp.com/en-AU/AU/gas-station/highgate/bp-highgate/9558	osm:node/4444842177	t	2026-11-18 05:53:55.180371+00
161	4	Supa IGA	Perth Cultural Centre	WA	\N	-31.9471458	115.8637928	https://www.iga.com.au/stores/#view=storedetail&storeId=15427	osm:node/4476377462	t	2026-11-18 05:53:55.180371+00
162	8	BP Carlisle	Carlisle	WA	6101	-31.9720577	115.918851	https://map.bp.com/en-AU/AU/gas-station/carlisle/bp-carlisle/6218	osm:node/4488416989	t	2026-11-18 05:53:55.180371+00
163	4	Roleystone Super IGA	Roleystone	WA	\N	-32.1124023	116.0700844	\N	osm:node/4537374679	t	2026-11-18 05:53:55.180371+00
164	8	BP Baldivis	Baldivis	WA	\N	-32.3088332	115.832848	https://map.bp.com/en-AU/AU/gas-station/baldivis/bp-baldivis-southbound/7374	osm:node/4564222614	t	2026-11-18 05:53:55.180371+00
165	2	Coles Balcatta	Balcatta	WA	\N	-31.87312	115.8297914	https://www.coles.com.au/	osm:node/4589261070	t	2026-11-18 05:53:55.180371+00
166	8	BP Baldivis	Baldivis	WA	\N	-32.3098931	115.8301652	https://map.bp.com/en-AU/AU/gas-station/baldivis/bp-baldivis-northbound/7375	osm:node/4599081589	t	2026-11-18 05:53:55.180371+00
167	8	BP Gwelup	Gwelup	WA	\N	-31.8655295	115.8080632	https://map.bp.com/en-AU/AU/gas-station/balcatta/bp-balcatta/1843	osm:node/4606997455	t	2026-11-18 05:53:55.180371+00
168	5	7-Eleven Fremantle	Fremantle	WA	\N	-32.0543621	115.7465238	\N	osm:node/4637126795	t	2026-11-18 05:53:55.180371+00
169	8	BP Safety Bay	Safety Bay	WA	\N	-32.3100354	115.7324261	\N	osm:node/4644302706	t	2026-11-18 05:53:55.180371+00
170	2	Coles Local	Mosman Park	WA	\N	-32.0085539	115.7616232	https://www.coles.com.au/	osm:node/4646407492	t	2026-11-18 05:53:55.180371+00
171	7	EG Ampol	Aveley	WA	\N	-31.7774661	115.9872639	https://eg-australia.com/eg-store-locator/	osm:node/4703398360	t	2026-11-18 05:53:55.180371+00
172	1	Woolworths Aveley	Aveley	WA	\N	-31.7779451	115.9880348	\N	osm:node/4703398367	t	2026-11-18 05:53:55.180371+00
173	4	IGA Woodvale	Woodvale	WA	\N	-31.7826427	115.7889746	\N	osm:node/4714968145	t	2026-11-18 05:53:55.180371+00
174	4	IGA Willagee	Willagee	WA	\N	-32.0529511	115.8071047	\N	osm:node/4726070876	t	2026-11-18 05:53:55.180371+00
175	1	Woolworths Aubin Grove	Aubin Grove	WA	\N	-32.1568309	115.860352	https://www.woolworths.com.au/	osm:node/4726284820	t	2026-11-18 05:53:55.180371+00
177	5	7-Eleven Haynes	Haynes	WA	\N	-32.1475884	115.9844227	https://7eleven.com.au/	osm:node/4870040574	t	2026-11-18 05:53:55.180371+00
178	4	IGA Falcon	Falcon	WA	\N	-32.5816507	115.6624222	\N	osm:node/4919966115	t	2026-11-18 05:53:55.180371+00
179	4	IGA Silver Sands	Silver Sands	WA	\N	-32.5206714	115.7310453	\N	osm:node/4935165149	t	2026-11-18 05:53:55.180371+00
180	4	IGA Seascapes	Erskine	WA	\N	-32.5572255	115.6764449	\N	osm:node/4967916076	t	2026-11-18 05:53:55.180371+00
181	4	IGA Noranda	Noranda	WA	6062	-31.8798974	115.8810388	\N	osm:node/4974849021	t	2026-11-18 05:53:55.180371+00
183	1	Woolworths Spearwood	Spearwood	WA	\N	-32.0980647	115.7848084	https://www.woolworths.com.au/	osm:node/5048023331	t	2026-11-18 05:53:55.180371+00
184	7	Caltex Petrol Station	Yokine	WA	6060	-31.9045951	115.8496804	\N	osm:node/5219123949	t	2026-11-18 05:53:55.180371+00
185	1	Woolworths Cloverdale	Cloverdale	WA	\N	-31.9638372	115.9351524	https://www.woolworths.com.au/	osm:node/5275860526	t	2026-11-18 05:53:55.180371+00
186	2	Coles Wanneroo	Wanneroo	WA	\N	-31.7527835	115.8048485	https://www.coles.com.au/	osm:node/5490038607	t	2026-11-18 05:53:55.180371+00
187	7	Ampol Bentley	Bentley	WA	6102	-32.0122416	115.9143021	https://ampol.com.au	osm:node/5499138482	t	2026-11-18 05:53:55.180371+00
189	1	Woolworths St James	St James	WA	\N	-32.0019903	115.9217056	https://www.woolworths.com.au/	osm:node/5580591758	t	2026-11-18 05:53:55.180371+00
190	1	Woolworths Coolbinia	Coolbinia	WA	\N	-31.9104114	115.847619	https://www.woolworths.com.au/	osm:node/5649806273	t	2026-11-18 05:53:55.180371+00
191	8	BP Coolbinia	Coolbinia	WA	\N	-31.911463	115.8468589	https://map.bp.com/en-AU/AU/gas-station/yokine/bp-dog-swamp/6234	osm:node/5649806274	t	2026-11-18 05:53:55.180371+00
198	5	7-Eleven Wangara	Madeley	WA	\N	-31.8019249	115.8277827	\N	osm:node/6075344159	t	2026-11-18 05:53:55.180371+00
199	8	BP Silver Sands	Silver Sands	WA	\N	-32.5198956	115.7312787	https://map.bp.com/en-AU/AU/gas-station/mandurah/bp-silver-sands/1993	osm:node/6133472015	t	2026-11-18 05:53:55.180371+00
200	1	Woolworths Inglewood	Inglewood	WA	\N	-31.9225099	115.8839646	https://www.woolworths.com.au/	osm:node/6144120585	t	2026-11-18 05:53:55.180371+00
201	2	Coles East Victoria Park	East Victoria Park	WA	6101	-31.9850501	115.9007256	https://www.coles.com.au/	osm:node/6152746378	t	2026-11-18 05:53:55.180371+00
202	7	Caltex Forrestdale	Haynes	WA	\N	-32.1426496	115.9740498	https://www.caltex.com/au/en.html	osm:node/6237531956	t	2026-11-18 05:53:55.180371+00
203	7	Ampol Ascot	Ascot	WA	\N	-31.9408689	115.9262414	\N	osm:node/6243480578	t	2026-11-18 05:53:55.180371+00
204	8	BP Ascot	Ascot	WA	\N	-31.9403032	115.9274447	https://map.bp.com/en-AU/AU/gas-station/belmont/bp-ascot/2244	osm:node/6243480579	t	2026-11-18 05:53:55.180371+00
205	8	BP North Perth	North Perth	WA	\N	-31.9257846	115.8494154	\N	osm:node/6247091955	t	2026-11-18 05:53:55.180371+00
206	1	Woolworths Piara Waters	Piara Waters	WA	\N	-32.1275359	115.9268316	https://www.woolworths.com.au/	osm:node/6332368285	t	2026-11-18 05:53:55.180371+00
207	1	Woolworths Riverton	Riverton	WA	\N	-32.0405245	115.9049788	https://www.woolworths.com.au/	osm:node/6359670033	t	2026-11-18 05:53:55.180371+00
208	8	BP Sawyers Valley	Sawyers Valley	WA	\N	-31.9032849	116.2049273	\N	osm:node/6634470775	t	2026-11-18 05:53:55.180371+00
209	4	IGA High Wycombe	High Wycombe	WA	\N	-31.9391496	116.002979	\N	osm:node/6742208319	t	2026-11-18 05:53:55.180371+00
210	4	IGA High Wycombe	High Wycombe	WA	\N	-31.9397744	115.9924607	https://www.iga.com.au/stores/#view=storedetail&storeId=15361	osm:node/6742226470	t	2026-11-18 05:53:55.180371+00
212	7	Ampol Shelley	Shelley	WA	\N	-32.0390962	115.8840301	\N	osm:node/7085743094	t	2026-11-18 05:53:55.180371+00
213	5	7-Eleven Rockingham	Hillman	WA	\N	-32.276548	115.7776467	\N	osm:node/7105904839	t	2026-11-18 05:53:55.180371+00
220	6	Vibe West Swan	West Swan	WA	\N	-31.8389998	115.9906236	\N	osm:node/7660622838	t	2026-11-18 05:53:55.180371+00
222	5	7-Eleven Mobil	Heathridge	WA	\N	-31.754028	115.7651635	\N	osm:node/7677095049	t	2026-11-18 05:53:55.180371+00
223	8	BP Beldon	Beldon	WA	\N	-31.7707419	115.7671884	https://map.bp.com/en-AU/AU/gas-station/beldon/bp-beldon/6533	osm:node/7862251314	t	2026-11-18 05:53:55.180371+00
224	8	BP East Perh	East Perth	WA	\N	-31.9507564	115.8765371	https://map.bp.com/en-AU/AU/gas-station/east-perth/bp-east-perth/5365	osm:node/8167030008	t	2026-11-18 05:53:55.180371+00
225	2	Coles Jindalee	Jindalee	WA	\N	-31.6496435	115.6973146	\N	osm:node/8311537823	t	2026-11-18 05:53:55.180371+00
226	4	IGA Mullaloo	Mullaloo	WA	\N	-31.7795159	115.7450518	\N	osm:node/8311595450	t	2026-11-18 05:53:55.180371+00
227	8	BP Mullaloo	Mullaloo	WA	\N	-31.7798899	115.7440647	https://map.bp.com/en-AU/AU/gas-station/mullaloo/bp-mullaloo/6202	osm:node/8311602644	t	2026-11-18 05:53:55.180371+00
228	8	BP Edgewater	Edgewater	WA	\N	-31.763446	115.7734061	https://map.bp.com/en-AU/AU/gas-station/edgewater/bp-edgewater/9070	osm:node/8311675600	t	2026-11-18 05:53:55.180371+00
229	5	7-Eleven Cockburn	Cockburn Central	WA	6164	-32.1200534	115.8467146	\N	osm:node/8313774517	t	2026-11-18 05:53:55.180371+00
230	4	IGA Dalkeith	Dalkeith	WA	\N	-31.9944499	115.7983929	\N	osm:node/8463404053	t	2026-11-18 05:53:55.180371+00
231	6	Vibe Gidgegannup	Gidgegannup	WA	\N	-31.7942384	116.193159	\N	osm:node/8481459755	t	2026-11-18 05:53:55.180371+00
234	4	The Market Place Ballajura IGA	Alexander Heights	WA	\N	-31.8269276	115.8783637	\N	osm:node/8878593054	t	2026-11-18 05:53:55.180371+00
236	1	Woolworths The Vines	The Vines	WA	\N	-31.7645929	115.9868762	https://www.woolworths.com.au/	osm:node/8899582894	t	2026-11-18 05:53:55.180371+00
237	5	7-Eleven Malvern Springs	The Vines	WA	\N	-31.7662731	115.98557	\N	osm:node/8899582895	t	2026-11-18 05:53:55.180371+00
238	2	Coles Brabham	Brabham	WA	6055	-31.8304133	115.9690352	https://www.coles.com.au/	osm:node/8901294282	t	2026-11-18 05:53:55.180371+00
239	1	Woolworths Applecross	Applecross	WA	\N	-32.0159521	115.8430587	\N	osm:node/8918080355	t	2026-11-18 05:53:55.180371+00
240	1	Woolworths Thornlie Square	Thornlie	WA	\N	-32.0559132	115.9637033	\N	osm:node/8926738186	t	2026-11-18 05:53:55.180371+00
241	5	7-Eleven Southern River	Southern River	WA	\N	-32.1237209	115.9562266	\N	osm:node/8926754470	t	2026-11-18 05:53:55.180371+00
242	2	Coles Maddington	Maddington	WA	\N	-32.0529588	115.9788575	\N	osm:node/8926779305	t	2026-11-18 05:53:55.180371+00
243	1	Woolworths Maddington	Maddington	WA	\N	-32.0539947	115.9787362	\N	osm:node/8926779306	t	2026-11-18 05:53:55.180371+00
244	7	Caltex Armadale	Armadale	WA	\N	-32.1512561	116.0140948	\N	osm:node/8926816784	t	2026-11-18 05:53:55.180371+00
245	2	Coles Seville Grove	Seville Grove	WA	\N	-32.1316827	116.0011742	\N	osm:node/8926841153	t	2026-11-18 05:53:55.180371+00
246	4	IGA Kelmscott	Kelmscott	WA	\N	-32.1145229	116.0152477	\N	osm:node/8926874786	t	2026-11-18 05:53:55.180371+00
247	1	Woolworths Kelmscott	Kelmscott	WA	\N	-32.1168085	116.0148488	\N	osm:node/8926882148	t	2026-11-18 05:53:55.180371+00
248	2	Coles Kelmscott	Kelmscott	WA	\N	-32.1125237	116.0147812	\N	osm:node/8929772133	t	2026-11-18 05:53:55.180371+00
249	4	IGA Baldivis	Baldivis	WA	\N	-32.3436984	115.8183767	\N	osm:node/8948732317	t	2026-11-18 05:53:55.180371+00
251	4	IGA Maida Vale	Maida Vale	WA	\N	-31.9526384	116.0190765	\N	osm:node/8986262953	t	2026-11-18 05:53:55.180371+00
253	8	BP Thornlie	Thornlie	WA	\N	-32.0637815	115.9357159	https://map.bp.com/en-AU/AU/gas-station/canning-vale/bp-thornlie/9804	osm:node/9364761547	t	2026-11-18 05:53:55.180371+00
254	7	Ampol Greenfields	Greenfields	WA	\N	-32.5296125	115.7644838	\N	osm:node/9412510871	t	2026-11-18 05:53:55.180371+00
256	1	Woolworths Highgate	Highgate	WA	\N	-31.9427174	115.8681577	https://www.woolworths.com.au/	osm:node/9436810444	t	2026-11-18 05:53:55.180371+00
257	2	Coles Claremont	Claremont	WA	6010	-31.9823154	115.7791106	\N	osm:node/9465241471	t	2026-11-18 05:53:55.180371+00
258	1	Woolworths Hamersley	Hamersley	WA	\N	-31.8440362	115.811653	\N	osm:node/9481772893	t	2026-11-18 05:53:55.180371+00
259	2	Coles Hamersley	Hamersley	WA	\N	-31.844616	115.8102813	\N	osm:node/9481789274	t	2026-11-18 05:53:55.180371+00
260	2	Coles Booragoon	Booragoon	WA	\N	-32.0340686	115.8342306	\N	osm:node/9526576733	t	2026-11-18 05:53:55.180371+00
261	1	Woolworths Booragoon	Booragoon	WA	\N	-32.0333215	115.8344677	\N	osm:node/9526576734	t	2026-11-18 05:53:55.180371+00
262	8	BP Sorrento	Sorrento	WA	\N	-31.8323814	115.747688	https://map.bp.com/en-AU/AU/gas-station/sorrento/bp-sorrento/6512	osm:node/9665942270	t	2026-11-18 05:53:55.180371+00
263	4	IGA Fremantle	Fremantle	WA	\N	-32.0544981	115.749252	\N	osm:node/9717067495	t	2026-11-18 05:53:55.180371+00
264	4	The Good Grocer	South Perth	WA	\N	-31.9720023	115.8518892	\N	osm:node/9729581020	t	2026-11-18 05:53:55.180371+00
265	4	The Good Grocer	Myaree	WA	\N	-32.0390071	115.8148293	https://myaree.thegoodgrocer.com.au/	osm:node/9734386617	t	2026-11-18 05:53:55.180371+00
266	2	Coles Bicton	Bicton	WA	\N	-32.033956	115.7912758	\N	osm:node/9739204034	t	2026-11-18 05:53:55.180371+00
267	4	IGA Claremont	Claremont	WA	\N	-31.9796298	115.7821082	\N	osm:node/9873878472	t	2026-11-18 05:53:55.180371+00
269	5	7-Eleven Kardinya	Kardinya	WA	\N	-32.0671495	115.8152447	\N	osm:node/9932826381	t	2026-11-18 05:53:55.180371+00
270	5	7-Eleven Banksia Grove	Banksia Grove	WA	\N	-31.7035962	115.8041947	\N	osm:node/9935048316	t	2026-11-18 05:53:55.180371+00
271	1	Woolworths Tapping	Tapping	WA	\N	-31.711906	115.7881074	\N	osm:node/9961078598	t	2026-11-18 05:53:55.180371+00
272	1	Woolworths Southern River	Huntingdale	WA	\N	-32.0898293	115.9421797	\N	osm:node/10050790417	t	2026-11-18 05:53:55.180371+00
273	7	Caltex Balvdivis	Baldivis	WA	\N	-32.3537278	115.8077808	\N	osm:node/10107452079	t	2026-11-18 05:53:55.180371+00
274	5	7 Eleven	St James	WA	\N	-32.001772	115.918496	\N	osm:node/10111100868	t	2026-11-18 05:53:55.180371+00
275	4	Beckenham IGA	Beckenham	WA	\N	-32.0142042	115.9655108	\N	osm:node/10669515871	t	2026-11-18 05:53:55.180371+00
276	6	Vibe Forrestfield	High Wycombe	WA	\N	-31.9615002	115.9920547	\N	osm:node/10669590537	t	2026-11-18 05:53:55.180371+00
277	7	Caltex	Kenwick	WA	\N	-32.0346169	116.0009457	\N	osm:node/10673530674	t	2026-11-18 05:53:55.180371+00
278	2	Coles Haynes	Haynes	WA	\N	-32.148061	115.9866245	\N	osm:node/10682977533	t	2026-11-18 05:53:55.180371+00
279	4	IGA Camillo	Camillo	WA	\N	-32.1191745	116.0008425	\N	osm:node/10685811662	t	2026-11-18 05:53:55.180371+00
280	7	Atlas Fuel, Thornlie	Thornlie	WA	\N	-32.0610646	115.9391186	https://atlasfuel.com.au/	osm:node/10692433084	t	2026-11-18 05:53:55.180371+00
281	2	Coles Southern River	Southern River	WA	\N	-32.1002219	115.9656603	\N	osm:node/10692456394	t	2026-11-18 05:53:55.180371+00
282	5	7-Eleven Wattle Grove	Wattle Grove	WA	\N	-32.0000118	115.9856923	\N	osm:node/10709729733	t	2026-11-18 05:53:55.180371+00
283	7	Ampol Wangara	Wangara	WA	\N	-31.7876301	115.828298	\N	osm:node/10742715916	t	2026-11-18 05:53:55.180371+00
284	1	Woolworths Midvale	Midvale	WA	\N	-31.8851453	116.0308726	https://www.woolworths.com.au/shop/storelocator/wa-midvale-4686	osm:node/10744607128	t	2026-11-18 05:53:55.180371+00
285	4	IGA Dawesville	Dawesville	WA	\N	-32.6344936	115.6389572	\N	osm:node/10747854655	t	2026-11-18 05:53:55.180371+00
286	4	Naturally Fresh IGA	Mosman Park	WA	\N	-32.0157194	115.7691653	\N	osm:node/10790414294	t	2026-11-18 05:53:55.180371+00
287	8	BP Shop	Riverton	WA	\N	-32.0391328	115.9043162	\N	osm:node/10791876700	t	2026-11-18 05:53:55.180371+00
288	4	Tucker Fresh IGA	Thornlie	WA	\N	-32.0633283	115.9356064	\N	osm:node/10870947306	t	2026-11-18 05:53:55.180371+00
291	7	EG Ampol	Mirrabooka	WA	\N	-31.8735347	115.8612529	\N	osm:node/10936227646	t	2026-11-18 05:53:55.180371+00
292	1	Woolworths Kallaroo	Kallaroo	WA	\N	-31.7965758	115.7478172	\N	osm:node/10983598025	t	2026-11-18 05:53:55.180371+00
293	2	Coles Karrinyup	Karrinyup	WA	\N	-31.8775736	115.7776645	\N	osm:node/11090786327	t	2026-11-18 05:53:55.180371+00
295	4	Tucker Fresh IGA Exchange	Karawara	WA	6102	-32.0017228	115.8913581	https://tuckerfreshiga.com.au/	osm:node/11252134432	t	2026-11-18 05:53:55.180371+00
296	5	7-Eleven Bibra Lake	Bibra Lake	WA	\N	-32.1015215	115.8018858	\N	osm:node/11271554341	t	2026-11-18 05:53:55.180371+00
297	4	Tucker Fresh IGA	Piara Waters	WA	\N	-32.1171015	115.9156746	https://tuckerfreshiga.com.au/	osm:node/11297495624	t	2026-11-18 05:53:55.180371+00
298	1	Woolworths Karrinyup	Karrinyup	WA	\N	-31.8774685	115.7788147	\N	osm:node/11391778362	t	2026-11-18 05:53:55.180371+00
299	7	EG Ampol	Osborne Park	WA	\N	-31.9106457	115.8140616	https://eg-australia.com/eg-store-locator/	osm:node/11581293254	t	2026-11-18 05:53:55.180371+00
302	2	Coles Kallaroo	Kallaroo	WA	\N	-31.7971194	115.7502799	https://www.coles.com.au/find-stores/coles/wa/hillarys-489	osm:node/11806194534	t	2026-11-18 05:53:55.180371+00
304	8	BP Singleton	Singleton	WA	\N	-32.4469574	115.7631651	https://map.bp.com/en-AU/AU/gas-station/singleton/bp-singleton/1151	osm:node/11813449356	t	2026-11-18 05:53:55.180371+00
305	2	Coles Madora Bay	Madora Bay	WA	\N	-32.4708362	115.7595534	\N	osm:node/11818520804	t	2026-11-18 05:53:55.180371+00
306	2	Coles Kwinana Town Centre	Kwinana Town Centre	WA	\N	-32.2454841	115.8138877	\N	osm:node/11826874479	t	2026-11-18 05:53:55.180371+00
307	1	Woolworths Kwinana Town Centre	Kwinana Town Centre	WA	\N	-32.2460106	115.8147294	\N	osm:node/11826874480	t	2026-11-18 05:53:55.180371+00
308	2	Coles Erskine	Erskine	WA	\N	-32.5614132	115.6886714	\N	osm:node/11834093840	t	2026-11-18 05:53:55.180371+00
309	2	Coles Kiara	Kiara	WA	\N	-31.8765744	115.9259113	\N	osm:node/11834095403	t	2026-11-18 05:53:55.180371+00
310	2	Coles Noranda	Noranda	WA	\N	-31.8769266	115.8961439	\N	osm:node/11834167628	t	2026-11-18 05:53:55.180371+00
311	1	Woolworths Noranda	Noranda	WA	\N	-31.8769478	115.8945958	\N	osm:node/11834167629	t	2026-11-18 05:53:55.180371+00
312	2	Coles Greenwood	Greenwood	WA	\N	-31.831252	115.8029527	\N	osm:node/11834181804	t	2026-11-18 05:53:55.180371+00
313	2	Coles Swan View	Swan View	WA	\N	-31.8886649	116.0470939	\N	osm:node/11834184542	t	2026-11-18 05:53:55.180371+00
314	2	Coles San Remo	San Remo	WA	\N	-32.4926529	115.7483645	\N	osm:node/11834188176	t	2026-11-18 05:53:55.180371+00
316	2	Coles Munster	Munster	WA	\N	-32.1280906	115.7980553	\N	osm:node/11834192916	t	2026-11-18 05:53:55.180371+00
317	2	Coles Alexander Heights	Alexander Heights	WA	\N	-31.8299267	115.8542105	\N	osm:node/11834275550	t	2026-11-18 05:53:55.180371+00
318	1	Woolworths Alexander Heights	Alexander Heights	WA	\N	-31.8291508	115.8539763	\N	osm:node/11834275556	t	2026-11-18 05:53:55.180371+00
319	2	Coles Alkimos	Alkimos	WA	\N	-31.628096	115.6925016	\N	osm:node/11834328360	t	2026-11-18 05:53:55.180371+00
320	2	Coles Banksia Grove	Banksia Grove	WA	\N	-31.7055668	115.8011981	\N	osm:node/11834411783	t	2026-11-18 05:53:55.180371+00
321	1	Woolworths Banksia Grove	Banksia Grove	WA	\N	-31.7045669	115.8026672	\N	osm:node/11834411795	t	2026-11-18 05:53:55.180371+00
325	2	Coles Byford	Byford	WA	\N	-32.2199142	116.0068198	\N	osm:node/11834417685	t	2026-11-18 05:53:55.180371+00
326	2	Coles Bassendean	Bassendean	WA	\N	-31.9028546	115.9533914	\N	osm:node/11834430075	t	2026-11-18 05:53:55.180371+00
327	4	IGA Padbury	Padbury	WA	\N	-31.8108441	115.7670947	\N	osm:node/11842723367	t	2026-11-18 05:53:55.180371+00
328	1	Woolworths Singleton	Singleton	WA	\N	-32.4479491	115.7646814	\N	osm:node/11861594858	t	2026-11-18 05:53:55.180371+00
329	1	Woolworths Byford	Byford	WA	\N	-32.2209349	116.004573	\N	osm:node/11861629964	t	2026-11-18 05:53:55.180371+00
330	1	Woolworths Ballajura	Ballajura	WA	\N	-31.846455	115.9066402	\N	osm:node/11861653791	t	2026-11-18 05:53:55.180371+00
331	1	Woolworths Greenfields	Greenfields	WA	\N	-32.5208306	115.7525022	\N	osm:node/11861656908	t	2026-11-18 05:53:55.180371+00
332	1	Woolworths Stirling	Stirling	WA	\N	-31.8893506	115.8205665	\N	osm:node/11861660234	t	2026-11-18 05:53:55.180371+00
333	1	Woolworths Midland	Midland	WA	6056	-31.8903639	116.0023163	https://www.woolworths.com.au/	osm:node/11861672210	t	2026-11-18 05:53:55.180371+00
334	1	Woolworths Butler	Butler	WA	\N	-31.6366312	115.6995156	\N	osm:node/11861751246	t	2026-11-18 05:53:55.180371+00
335	1	Woolworths Westminster	Westminster	WA	\N	-31.8623097	115.8295369	\N	osm:node/11861796046	t	2026-11-18 05:53:55.180371+00
337	1	Woolworths Floreat	Floreat	WA	\N	-31.9387559	115.7925616	\N	osm:node/11861804173	t	2026-11-18 05:53:55.180371+00
338	1	Woolworths Bennett Springs	Bennett Springs	WA	\N	-31.8593041	115.9260375	\N	osm:node/11861949375	t	2026-11-18 05:53:55.180371+00
339	1	Woolworths Leda	Leda	WA	\N	-32.2632085	115.8159419	\N	osm:node/11862007063	t	2026-11-18 05:53:55.180371+00
340	1	Woolworths Waikiki	Waikiki	WA	\N	-32.3132434	115.753506	\N	osm:node/11862055220	t	2026-11-18 05:53:55.180371+00
341	1	Woolworths Falcon	Falcon	WA	\N	-32.5842423	115.6615295	\N	osm:node/11862064985	t	2026-11-18 05:53:55.180371+00
342	7	EG Australia	Falcon	WA	\N	-32.5848504	115.6603865	\N	osm:node/11862064986	t	2026-11-18 05:53:55.180371+00
343	1	Woolworths Mount Hawthorn	Mount Hawthorn	WA	\N	-31.9211814	115.8397095	\N	osm:node/11862153338	t	2026-11-18 05:53:55.180371+00
344	1	Woolworths Beechboro	Beechboro	WA	\N	-31.8699277	115.9458814	\N	osm:node/11862154384	t	2026-11-18 05:53:55.180371+00
345	4	The Good Grocer (Shenton Park IGA)	Shenton Park	WA	\N	-31.9610622	115.8134827	https://thegoodgrocer.com.au	osm:node/11982688703	t	2026-11-18 05:53:55.180371+00
346	7	Caltex	Karragullen	WA	\N	-32.1001099	116.1167014	\N	osm:node/12009036909	t	2026-11-18 05:53:55.180371+00
347	4	IGA Waikiki	Waikiki	WA	\N	-32.3128661	115.7454139	\N	osm:node/12043018539	t	2026-11-18 05:53:55.180371+00
348	4	IGA Express	Yokine	WA	\N	-31.8931166	115.8490217	\N	osm:node/12064223169	t	2026-11-18 05:53:55.180371+00
349	1	Woolworths Baldivis	Baldivis	WA	\N	-32.3126459	115.814707	\N	osm:node/12076137465	t	2026-11-18 05:53:55.180371+00
350	2	Coles Currambine	Currambine	WA	\N	-31.7254649	115.7446186	\N	osm:node/12163168101	t	2026-11-18 05:53:55.180371+00
351	2	Coles Yanchep	Yanchep	WA	\N	-31.5505199	115.6400145	\N	osm:node/12201926606	t	2026-11-18 05:53:55.180371+00
352	4	The Good Grocer	Mount Lawley	WA	\N	-31.9275142	115.8781945	https://www.iga.com.au/stores/#view=storedetail&storeId=15501	osm:node/12249795166	t	2026-11-18 05:53:55.180371+00
353	5	7 eleven	Greenfields	WA	\N	-32.5203283	115.7535645	\N	osm:node/12259889401	t	2026-11-18 05:53:55.180371+00
354	7	EG Ampol service	Coodanup	WA	\N	-32.5362865	115.7404988	\N	osm:node/12273495087	t	2026-11-18 05:53:55.180371+00
355	7	EG Australia	Silver Sands	WA	\N	-32.5095616	115.7408825	\N	osm:node/12273507968	t	2026-11-18 05:53:55.180371+00
356	7	Ampol Foodary Karrinyup	Gwelup	WA	\N	-31.8820481	115.7961671	https://locations.ampol.com.au/en/ampol-foodary-karrinyup	osm:node/12273548251	t	2026-11-18 05:53:55.180371+00
357	7	Foodary	Glendalough	WA	\N	-31.9223309	115.8195853	\N	osm:node/12273571163	t	2026-11-18 05:53:55.180371+00
359	7	Ampol Munster	Munster	WA	\N	-32.127442	115.7990156	\N	osm:node/12273577566	t	2026-11-18 05:53:55.180371+00
360	7	Ampol Madora Bay	Madora Bay	WA	\N	-32.4790636	115.7578332	\N	osm:node/12273587672	t	2026-11-18 05:53:55.180371+00
361	8	BP Piara Waters	Piara Waters	WA	\N	-32.1171225	115.9148349	\N	osm:node/12292678097	t	2026-11-18 05:53:55.180371+00
365	7	Caltex	Wangara	WA	\N	-31.7861583	115.8191073	\N	osm:node/12944432744	t	2026-11-18 05:53:55.180371+00
366	2	Coles Fremantle	Fremantle	WA	\N	-32.052281	115.7470577	\N	osm:node/13005682896	t	2026-11-18 05:53:55.180371+00
367	8	BP South Perth	South Perth	WA	\N	-31.9726789	115.8517271	\N	osm:node/13109369748	t	2026-11-18 05:53:55.180371+00
368	8	BP Alkimos	Alkimos	WA	\N	-31.6213425	115.6887241	\N	osm:node/13112073666	t	2026-11-18 05:53:55.180371+00
369	4	Scarvaci IGA	Hamilton Hill	WA	\N	-32.0825343	115.7689043	\N	osm:node/13130571338	t	2026-11-18 05:53:55.180371+00
370	1	Woolworths Mindarie	Mindarie	WA	\N	-31.6927619	115.7170351	\N	osm:node/13195222242	t	2026-11-18 05:53:55.180371+00
373	2	Coles Local	Daglish	WA	\N	-31.9558069	115.8041291	\N	osm:node/13395201646	t	2026-11-18 05:53:55.180371+00
374	5	7-Eleven Coodanup	Coodanup	WA	\N	-32.5376441	115.7575706	\N	osm:node/13417392839	t	2026-11-18 05:53:55.180371+00
376	8	BP Shop	Wembley	WA	\N	-31.9403077	115.8202188	\N	osm:node/13607617381	t	2026-11-18 05:53:55.180371+00
377	6	Vibe Hamilton Hill	Hamilton Hill	WA	\N	-32.0861627	115.777262	\N	osm:node/13657595001	t	2026-11-18 05:53:55.180371+00
378	7	Foodary	Perth Cultural Centre	WA	\N	-31.9483681	115.8693189	\N	osm:node/13699193278	t	2026-11-18 05:53:55.180371+00
379	6	Vibe Oakford	Oakford	WA	6121	-32.207855	115.9524178	\N	osm:node/13763566201	t	2026-11-18 05:53:55.180371+00
380	1	Woolworths Hilbert	Hilbert	WA	\N	-32.1642609	115.9759324	\N	osm:node/13773013263	t	2026-11-18 05:53:55.180371+00
381	6	Vibe Brookdale	Brookdale	WA	\N	-32.1581424	116.001864	\N	osm:node/13809206454	t	2026-11-18 05:53:55.180371+00
382	7	Caltex Nambeelup	Stake Hill	WA	\N	-32.5104402	115.8157152	\N	osm:node/13943145721	t	2026-11-18 05:53:55.180371+00
383	6	Vibe Port Kennedy	Port Kennedy	WA	\N	-32.3715442	115.762417	\N	osm:node/13970574805	t	2026-11-18 05:53:55.180371+00
384	1	Woolworths Mandurah Central	Halls Head	WA	\N	-32.5330143	115.7206772	\N	osm:node/14028823411	t	2026-11-18 05:53:55.180371+00
387	7	Foodary	Bellevue	WA	\N	-31.8946669	116.0314853	\N	osm:node/14256926969	t	2026-11-18 05:53:55.180371+00
388	5	7-Eleven Byford	Byford	WA	\N	-32.2220652	116.0059062	\N	osm:node/14339753872	t	2026-11-18 05:53:55.180371+00
389	6	VIBE Pertrol	Edgewater	WA	\N	-31.7719842	115.7893235	\N	osm:way/45068289	t	2026-11-18 05:53:55.180371+00
391	4	IGA Applecross	Applecross	WA	\N	-32.0115376	115.8504733	\N	osm:way/47435394	t	2026-11-18 05:53:55.180371+00
394	4	The Good Grocer	Leederville	WA	\N	-31.9366502	115.8405416	https://thegoodgrocer.com.au/store_location/leederville/	osm:way/58756141	t	2026-11-18 05:53:55.180371+00
397	4	The Market Place	Highgate	WA	\N	-31.9349931	115.871463	https://www.iga.com.au/stores/#view=storedetail&storeId=15412	osm:way/147409577	t	2026-11-18 05:53:55.180371+00
398	7	Caltex Stratton	Stratton	WA	\N	-31.8655909	116.0328384	\N	osm:way/158540596	t	2026-11-18 05:53:55.180371+00
399	7	Ampol Foodary Kewdale	Kewdale	WA	\N	-31.9834875	115.9560045	https://locations.ampol.com.au/en/ampol-foodary-kewdale	osm:way/162115632	t	2026-11-18 05:53:55.180371+00
401	7	Caltex Munster	Lake Coogee	WA	\N	-32.1224774	115.7843117	https://www.caltex.com/au	osm:way/164843213	t	2026-11-18 05:53:55.180371+00
402	7	Ginger's Roadhouse	Upper Swan	WA	\N	-31.7709534	116.0285368	\N	osm:way/174695506	t	2026-11-18 05:53:55.180371+00
403	7	Foodary	Mindarie	WA	\N	-31.6891211	115.7153929	\N	osm:way/184797721	t	2026-11-18 05:53:55.180371+00
404	8	BP Tuart Hill	Tuart Hill	WA	\N	-31.8962156	115.8288476	https://map.bp.com/en-AU/AU/gas-station/osborne-park/bp-main-street/6213	osm:way/199343502	t	2026-11-18 05:53:55.180371+00
406	7	Ampol High Wycombe	High Wycombe	WA	\N	-31.9515744	115.9875871	\N	osm:way/214229494	t	2026-11-18 05:53:55.180371+00
408	7	EG Australia	Currambine	WA	\N	-31.7421894	115.7403971	https://eg-australia.com/eg-store-locator/	osm:way/243511265	t	2026-11-18 05:53:55.180371+00
409	7	Yule Du Road House	Bedfordale	WA	\N	-32.1819921	116.0756243	\N	osm:way/258998367	t	2026-11-18 05:53:55.180371+00
410	8	BP Kinross	Kinross	WA	\N	-31.7237681	115.7463928	https://map.bp.com/en-AU/AU/gas-station/currambine/bp-currambine/6427	osm:way/264862544	t	2026-11-18 05:53:55.180371+00
411	7	EG Ampol	Joondalup	WA	\N	-31.7445337	115.7631377	https://eg-australia.com/eg-store-locator/	osm:way/264863055	t	2026-11-18 05:53:55.180371+00
412	7	Ampol Joondalup	Joondalup	WA	\N	-31.7412236	115.7641682	\N	osm:way/264863056	t	2026-11-18 05:53:55.180371+00
414	8	BP Scarborough	Scarborough	WA	\N	-31.8947037	115.7582697	\N	osm:way/292155694	t	2026-11-18 05:53:55.180371+00
415	1	Woolworths Palmyra	Palmyra	WA	\N	-32.0481579	115.7944977	https://www.woolworths.com.au/	osm:way/299445507	t	2026-11-18 05:53:55.180371+00
416	8	BP Bull Creek	Bull Creek	WA	\N	-32.0570905	115.8659153	https://map.bp.com/en-AU/AU/gas-station/bull-creek/bp-bull-creek/6521	osm:way/302848782	t	2026-11-18 05:53:55.180371+00
417	4	IGA Supermarket	Hammond Park	WA	\N	-32.1603846	115.8470361	\N	osm:way/306234025	t	2026-11-18 05:53:55.180371+00
418	4	IGA Dwellingup	Dwellingup	WA	\N	-32.7141732	116.0622492	\N	osm:way/317551791	t	2026-11-18 05:53:55.180371+00
419	8	BP Fremantle	Fremantle	WA	\N	-32.0454503	115.7531206	\N	osm:way/341104306	t	2026-11-18 05:53:55.180371+00
423	7	EG Ampol	Dianella	WA	\N	-31.8965668	115.8716185	https://eg-australia.com/eg-store-locator/	osm:way/423877325	t	2026-11-18 05:53:55.180371+00
426	4	IGA Ashfield	Ashfield	WA	\N	-31.9144676	115.9361099	\N	osm:way/447814532	t	2026-11-18 05:53:55.180371+00
427	2	Coles South Perth	South Perth	WA	\N	-31.9810751	115.8623381	\N	osm:way/463590329	t	2026-11-18 05:53:55.180371+00
428	4	IGA Stirling	Stirling	WA	\N	-31.8809444	115.8106048	\N	osm:way/468315798	t	2026-11-18 05:53:55.180371+00
431	7	Caltex	Erskine	WA	\N	-32.5601511	115.6895516	\N	osm:way/502576477	t	2026-11-18 05:53:55.180371+00
432	4	IGA Two Rocks	Two Rocks	WA	\N	-31.4955504	115.5848141	\N	osm:way/516834206	t	2026-11-18 05:53:55.180371+00
433	6	Vibe Piara Waters	Forrestdale	WA	\N	-32.1467951	115.9220697	\N	osm:way/552492312	t	2026-11-18 05:53:55.180371+00
434	2	Coles Gosnells	Gosnells	WA	\N	-32.0686276	116.0004393	https://www.coles.com.au/	osm:way/553155802	t	2026-11-18 05:53:55.180371+00
435	7	Ampol Dawesville	Dawesville	WA	\N	-32.6306071	115.6323622	\N	osm:way/554609306	t	2026-11-18 05:53:55.180371+00
436	4	IGA Rockingham	Rockingham	WA	\N	-32.2769286	115.7290751	\N	osm:way/600733549	t	2026-11-18 05:53:55.180371+00
437	2	Coles Coodanup	Coodanup	WA	\N	-32.5353403	115.7443545	https://www.coles.com.au/	osm:way/655517290	t	2026-11-18 05:53:55.180371+00
438	1	Woolworths Coodanup	Coodanup	WA	\N	-32.5346745	115.741911	https://www.woolworths.com.au/	osm:way/655517595	t	2026-11-18 05:53:55.180371+00
439	8	BP Dwellingup	Dwellingup	WA	\N	-32.7139233	116.0627082	https://map.bp.com/en-AU/AU/gas-station/dwellingup/bp-dwellingup/7377	osm:way/689128697	t	2026-11-18 05:53:55.180371+00
440	8	BP Rockingham	Rockingham	WA	\N	-32.2896962	115.7413244	https://map.bp.com/en-AU/AU/gas-station/rockingham/bp-rockingham-park/6172	osm:way/705695613	t	2026-11-18 05:53:55.180371+00
441	7	Ampol Beechboro	Beechboro	WA	\N	-31.871162	115.9450124	\N	osm:way/706091612	t	2026-11-18 05:53:55.180371+00
442	7	EG Australia	Ballajura	WA	\N	-31.8475755	115.907061	\N	osm:way/707970282	t	2026-11-18 05:53:55.180371+00
443	7	Caltex	Dayton	WA	\N	-31.8510702	115.9686757	\N	osm:way/708699106	t	2026-11-18 05:53:55.180371+00
445	7	Caltex High Wycombe	High Wycombe	WA	\N	-31.936953	116.0080382	\N	osm:way/718384008	t	2026-11-18 05:53:55.180371+00
446	8	BP Shop	Maida Vale	WA	\N	-31.9535955	116.0240888	\N	osm:way/719388888	t	2026-11-18 05:53:55.180371+00
447	8	BP Shop	Forrestfield	WA	\N	-31.9906254	116.0000689	\N	osm:way/720160328	t	2026-11-18 05:53:55.180371+00
448	8	BP Cockburn Central	Cockburn Central	WA	\N	-32.1291687	115.8537215	https://map.bp.com/en-AU/AU/gas-station/success/bp-thomsons-lake/5992	osm:way/738220296	t	2026-11-18 05:53:55.180371+00
449	7	Caltex	Kalamunda	WA	\N	-31.9679616	116.0530495	\N	osm:way/740974957	t	2026-11-18 05:53:55.180371+00
451	7	Burk Bassendean	Bassendean	WA	\N	-31.9011637	115.9592252	\N	osm:way/793705140	t	2026-11-18 05:53:55.180371+00
452	7	Ampol Secret Harbour	Secret Harbour	WA	\N	-32.4071024	115.7593171	\N	osm:way/794389316	t	2026-11-18 05:53:55.180371+00
453	6	Vibe Bullsbrook	Bullsbrook	WA	\N	-31.6719062	116.0314142	\N	osm:way/808246709	t	2026-11-18 05:53:55.180371+00
456	1	Woolworths Forrestfield	Forrestfield	WA	\N	-31.9866278	116.0081259	\N	osm:way/835224325	t	2026-11-18 05:53:55.180371+00
457	2	Coles Forrestfield	Forrestfield	WA	\N	-31.9874328	116.0101477	https://www.coles.com.au/	osm:way/835224336	t	2026-11-18 05:53:55.180371+00
458	4	IGA Butler	Butler	WA	\N	-31.6473005	115.7074043	\N	osm:way/835243944	t	2026-11-18 05:53:55.180371+00
459	8	BP Kwinana Town Centre	Kwinana Town Centre	WA	6167	-32.244495	115.8129139	https://map.bp.com/en-AU/AU/gas-station/parmelia/bp-kwinana-hub/6178	osm:way/837781761	t	2026-11-18 05:53:55.180371+00
460	4	IGA Burns Beach	Burns Beach	WA	\N	-31.73337	115.7240322	\N	osm:way/852588751	t	2026-11-18 05:53:55.180371+00
461	5	7-Eleven Carlisle	Carlisle	WA	\N	-31.9717905	115.9185343	https://www.7eleven.com.au/	osm:way/878451279	t	2026-11-18 05:53:55.180371+00
462	5	7-Eleven Bellevue	Bellevue	WA	\N	-31.8980235	116.0153341	\N	osm:way/909853753	t	2026-11-18 05:53:55.180371+00
463	7	Ampol Thornlie	Thornlie	WA	\N	-32.0558843	115.9619586	\N	osm:way/917387266	t	2026-11-18 05:53:55.180371+00
464	7	Ampol Cannington	Cannington	WA	\N	-32.0175652	115.9348812	\N	osm:way/956204363	t	2026-11-18 05:53:55.180371+00
465	7	Foodary	Cannington	WA	\N	-32.0174495	115.93509	\N	osm:way/956204364	t	2026-11-18 05:53:55.180371+00
469	7	Caltex Murdoch	North Lake	WA	\N	-32.0791592	115.8430575	https://www.caltex.com/au/find-us.html?currentLocation=Murdoch+	osm:way/967690001	t	2026-11-18 05:53:55.180371+00
470	8	Muchea BP	Muchea	WA	\N	-31.5680537	115.9952197	https://map.bp.com/en-AU/AU/gas-station/muchea/bp-muchea/9964	osm:way/979735437	t	2026-11-18 05:53:55.180371+00
471	7	Caltex Dianella	Bedford	WA	\N	-31.9064681	115.8818741	\N	osm:way/991629510	t	2026-11-18 05:53:55.180371+00
472	1	Woolworths Coolbellup	Coolbellup	WA	\N	-32.0808731	115.8074955	\N	osm:way/998643306	t	2026-11-18 05:53:55.180371+00
474	8	BP Rosegarden	Nedlands	WA	\N	-31.9797308	115.7982564	https://map.bp.com/en-AU/AU/gas-station/nedlands/bp-rosegarden/6161	osm:way/1037479669	t	2026-11-18 05:53:55.180371+00
475	7	EG Australia	South Fremantle	WA	\N	-32.0736784	115.7589872	\N	osm:way/1038797807	t	2026-11-18 05:53:55.180371+00
476	8	BP South Beach	South Beach	WA	\N	-32.0768439	115.7608983	https://map.bp.com/en-AU/AU/gas-station/south-fremantle/bp-south-fremantle/9802	osm:way/1038797808	t	2026-11-18 05:53:55.180371+00
477	5	7-Eleven Piara Waters	Piara Waters	WA	\N	-32.1255729	115.9259513	\N	osm:way/1050457937	t	2026-11-18 05:53:55.180371+00
478	7	Ampol O'Connor	O'Connor	WA	\N	-32.0554115	115.7931909	\N	osm:way/1059785131	t	2026-11-18 05:53:55.180371+00
479	8	BP Spearwood	Spearwood	WA	\N	-32.0945551	115.7832059	https://map.bp.com/en-AU/AU/gas-station/spearwood/bp-phoenix/6443	osm:way/1067478400	t	2026-11-18 05:53:55.180371+00
480	4	Vibe Ascot IGA Xpress	Redcliffe	WA	\N	-31.9359514	115.9344258	https://vibepetroleum.com/locations/	osm:way/1080426213	t	2026-11-18 05:53:55.180371+00
481	5	7-Eleven Thornlie	Thornlie	WA	\N	-32.0695044	115.952117	\N	osm:way/1084172482	t	2026-11-18 05:53:55.180371+00
482	5	7-Eleven Myaree	Myaree	WA	\N	-32.0396353	115.8225353	\N	osm:way/1085281276	t	2026-11-18 05:53:55.180371+00
483	8	BP Shop	Wattle Grove	WA	\N	-32.0061026	115.9806902	https://map.bp.com/en-AU/AU/gas-station/wattle-grove/bp-kenwick/9030	osm:way/1096960059	t	2026-11-18 05:53:55.180371+00
484	8	BP Huntingdale	Huntingdale	WA	\N	-32.0715135	115.9664944	https://map.bp.com/en-AU/AU/gas-station/huntingdale/bp-huntingdale/6117	osm:way/1100817398	t	2026-11-18 05:53:55.180371+00
485	5	7-Eleven Kelmscott	Kelmscott	WA	\N	-32.1190209	116.0177732	\N	osm:way/1137516992	t	2026-11-18 05:53:55.180371+00
486	5	7-Eleven Seville Grove	Seville Grove	WA	\N	-32.1284907	115.9999963	\N	osm:way/1148507179	t	2026-11-18 05:53:55.180371+00
488	7	Ampol Subiaco	Subiaco	WA	\N	-31.9506684	115.8242379	https://www.ampol.com.au/	osm:way/1153965479	t	2026-11-18 05:53:55.180371+00
489	2	Coles Hilton	Hilton	WA	\N	-32.0637463	115.7817919	\N	osm:way/1156834170	t	2026-11-18 05:53:55.180371+00
491	8	BP Applecross	Applecross	WA	6153	-32.014896	115.8432484	https://map.bp.com/en-AU/AU/gas-station/applecross/bp-applecross/6200	osm:way/1167486283	t	2026-11-18 05:53:55.180371+00
492	6	Vibe Canning Vale	Canning Vale	WA	\N	-32.0752392	115.9227437	\N	osm:way/1179020194	t	2026-11-18 05:53:55.180371+00
493	8	BP Parkwood	Parkwood	WA	\N	-32.0596999	115.9307896	\N	osm:way/1182825818	t	2026-11-18 05:53:55.180371+00
494	5	7-Eleven Harrisdale	Harrisdale	WA	\N	-32.1077803	115.9399031	https://7eleven.com.au/	osm:way/1193079891	t	2026-11-18 05:53:55.180371+00
495	7	Caltex	Hamilton Hill	WA	\N	-32.0754711	115.7795033	\N	osm:way/1215084653	t	2026-11-18 05:53:55.180371+00
496	5	7-Eleven Cockburn Central	Cockburn Central	WA	\N	-32.1262239	115.83927	\N	osm:way/1215928206	t	2026-11-18 05:53:55.180371+00
497	7	Ampol Foodary Forrestdale	Haynes	WA	\N	-32.1463362	115.9655454	https://locations.ampol.com.au/en/ampol-foodary-forrestdale	osm:way/1239633449	t	2026-11-18 05:53:55.180371+00
498	8	BP Clarkson	Somerly	WA	\N	-31.6940246	115.724687	https://map.bp.com/en-AU/AU/gas-station/clarkson/bp-clarkson/9969	osm:way/1250227054	t	2026-11-18 05:53:55.180371+00
499	7	Ampol East Fremantle	East Fremantle	WA	6158	-32.0406604	115.7663399	\N	osm:way/1261413978	t	2026-11-18 05:53:55.180371+00
500	7	Ampol Gosnells	Gosnells	WA	\N	-32.0641259	115.9994944	\N	osm:way/1289518135	t	2026-11-18 05:53:55.180371+00
501	5	7-Eleven Golden Bay	Golden Bay	WA	\N	-32.4205726	115.7611672	\N	osm:way/1290164549	t	2026-11-18 05:53:55.180371+00
503	2	Coles Secret Harbour	Secret Harbour	WA	\N	-32.4095765	115.7596181	\N	osm:way/1298946079	t	2026-11-18 05:53:55.180371+00
504	7	EG Australia	Port Kennedy	WA	\N	-32.3737906	115.7560255	\N	osm:way/1300517996	t	2026-11-18 05:53:55.180371+00
505	7	Ampol Maddington	Maddington	WA	\N	-32.0493096	115.9774739	\N	osm:way/1303000737	t	2026-11-18 05:53:55.180371+00
506	7	Ampol Gosnells	Gosnells	WA	\N	-32.0799099	115.9879808	\N	osm:way/1308846524	t	2026-11-18 05:53:55.180371+00
507	7	Caltex	Walliston	WA	\N	-31.9913957	116.0642704	\N	osm:way/1308950272	t	2026-11-18 05:53:55.180371+00
508	4	All Foods Market Cooloonganup IGA	Cooloongup	WA	\N	-32.2955266	115.7627532	https://www.allfoodsmarket.com.au/#our-stores	osm:way/1313761958	t	2026-11-18 05:53:55.180371+00
509	5	7-Eleven Baldivis	Baldivis	WA	\N	-32.3083353	115.8216918	\N	osm:way/1314159945	t	2026-11-18 05:53:55.180371+00
510	5	7-Eleven Maddington	Maddington	WA	\N	-32.0554842	115.9886516	\N	osm:way/1318106890	t	2026-11-18 05:53:55.180371+00
511	2	Coles Southern River	Harrisdale	WA	\N	-32.1059288	115.9383757	https://www.coles.com.au/	osm:way/1319572454	t	2026-11-18 05:53:55.180371+00
512	1	Woolworths Bull Creek	Bull Creek	WA	\N	-32.0643625	115.8575327	https://www.woolworths.com.au/	osm:way/1320078094	t	2026-11-18 05:53:55.180371+00
513	7	Ampol Woodlands	Woodlands	WA	\N	-31.9013362	115.7942264	\N	osm:way/1326523317	t	2026-11-18 05:53:55.180371+00
514	8	BP Shop	Armadale	WA	\N	-32.1484348	116.020209	\N	osm:way/1355928758	t	2026-11-18 05:53:55.180371+00
515	7	EG Southern River	Canning Vale	WA	\N	-32.0964841	115.9360472	\N	osm:way/1356171607	t	2026-11-18 05:53:55.180371+00
516	4	Armadale IGA Local Grocer	Armadale	WA	\N	-32.1576472	116.0084238	\N	osm:way/1361604645	t	2026-11-18 05:53:55.180371+00
517	4	IGA Doubleview	Doubleview	WA	\N	-31.8881751	115.7799165	\N	osm:way/1363485784	t	2026-11-18 05:53:55.180371+00
544	7	Caltex Midvale	Midvale	WA	\N	-31.8862802	116.0317444	\N	osm:way/1527902994	t	2026-11-18 05:53:55.180371+00
545	6	Vibe Kwinana	Kwinana Town Centre	WA	\N	-32.2445786	115.8155663	\N	osm:way/1530388472	t	2026-11-18 05:53:55.180371+00
547	7	Caltex	Silver Sands	WA	\N	-32.512455	115.7372578	\N	osm:way/1531031777	t	2026-11-18 05:53:55.180371+00
548	2	Coles Pinjarra	Pinjarra	WA	\N	-32.6283986	115.8734443	https://www.coles.com.au/	osm:way/1534922052	t	2026-11-18 05:53:55.180371+00
549	1	Woolworths Eglinton	Eglinton	WA	\N	-31.5919912	115.6721939	https://www.woolworths.com.au/shop/storelocator/wa-eglinton-4851	osm:way/1546202410	t	2026-11-18 05:53:55.180371+00
550	2	Coles Armadale	Armadale	WA	\N	-32.1524701	116.0157866	\N	osm:way/1565170486	t	2026-11-18 05:53:55.180371+00
551	7	EG Australia	Banksia Grove	WA	\N	-31.7044863	115.8037712	https://eg-australia.com/eg-store-locator/	osm:way/1567230381	t	2026-11-18 05:53:55.180371+00
552	7	EG Australia	Ellenbrook	WA	\N	-31.7809067	115.9691283	https://eg-australia.com/eg-store-locator/	osm:way/1567236599	t	2026-11-18 05:53:55.180371+00
553	2	Coles Northbridge	Northbridge	WA	\N	-31.9512539	115.857153	https://www.coles.com.au/	osm:way/1572329654	t	2026-11-18 05:53:55.180371+00
\.


--
-- Name: caffeine_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.caffeine_entries_id_seq', 6, true);


--
-- Name: chains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.chains_id_seq', 8, true);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.devices_id_seq', 27, true);


--
-- Name: listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.listings_id_seq', 1111, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.notifications_id_seq', 3, true);


--
-- Name: observations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.observations_id_seq', 23634, true);


--
-- Name: photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.photos_id_seq', 12, true);


--
-- Name: price_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.price_alerts_id_seq', 6, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.products_id_seq', 356, true);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.reports_id_seq', 1, false);


--
-- Name: scrape_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.scrape_runs_id_seq', 21, true);


--
-- Name: stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drinkwatch
--

SELECT pg_catalog.setval('public.stores_id_seq', 563, true);


--
-- Name: barcode_cache barcode_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.barcode_cache
    ADD CONSTRAINT barcode_cache_pkey PRIMARY KEY (barcode);


--
-- Name: barcodes barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_pkey PRIMARY KEY (barcode);


--
-- Name: caffeine_entries caffeine_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.caffeine_entries
    ADD CONSTRAINT caffeine_entries_pkey PRIMARY KEY (id);


--
-- Name: chains chains_code_key; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.chains
    ADD CONSTRAINT chains_code_key UNIQUE (code);


--
-- Name: chains chains_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.chains
    ADD CONSTRAINT chains_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: devices devices_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_token_hash_key UNIQUE (token_hash);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: observation_votes observation_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observation_votes
    ADD CONSTRAINT observation_votes_pkey PRIMARY KEY (observation_id, device_id);


--
-- Name: observations observations_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_pkey PRIMARY KEY (id);


--
-- Name: photos photos_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT photos_pkey PRIMARY KEY (id);


--
-- Name: photos photos_token_key; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT photos_token_key UNIQUE (token);


--
-- Name: price_alerts price_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_alerts
    ADD CONSTRAINT price_alerts_pkey PRIMARY KEY (id);


--
-- Name: price_daily price_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_daily
    ADD CONSTRAINT price_daily_pkey PRIMARY KEY (day, chain_id, product_id);


--
-- Name: products products_barcode_key; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_barcode_key UNIQUE (barcode);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_slug_key; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_key UNIQUE (slug);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (name);


--
-- Name: scrape_runs scrape_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.scrape_runs
    ADD CONSTRAINT scrape_runs_pkey PRIMARY KEY (id);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: listings uq_listings_chain_sku; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT uq_listings_chain_sku UNIQUE (chain_id, external_sku);


--
-- Name: observations uq_obs_dedupe; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT uq_obs_dedupe UNIQUE (dedupe_key);


--
-- Name: stores uq_stores_chain_extref; Type: CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT uq_stores_chain_extref UNIQUE (chain_id, external_ref);


--
-- Name: ix_alerts_active; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_alerts_active ON public.price_alerts USING btree (is_active);


--
-- Name: ix_alerts_device; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_alerts_device ON public.price_alerts USING btree (device_id);


--
-- Name: ix_barcodes_product; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_barcodes_product ON public.barcodes USING btree (product_id);


--
-- Name: ix_caffeine_device_day; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_caffeine_device_day ON public.caffeine_entries USING btree (device_id, consumed_at DESC);


--
-- Name: ix_notifications_device; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_notifications_device ON public.notifications USING btree (device_id, created_at DESC);


--
-- Name: ix_obs_chain_product_time; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_obs_chain_product_time ON public.observations USING btree (chain_id, product_id, observed_at);


--
-- Name: ix_obs_product_time; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_obs_product_time ON public.observations USING btree (product_id, observed_at);


--
-- Name: ix_obs_store_product_time; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_obs_store_product_time ON public.observations USING btree (store_id, product_id, observed_at);


--
-- Name: ix_photos_sha; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_photos_sha ON public.photos USING btree (sha256);


--
-- Name: ix_price_daily_product; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_price_daily_product ON public.price_daily USING btree (product_id, day DESC);


--
-- Name: ix_products_brand_trgm; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_products_brand_trgm ON public.products USING gin (lower((brand)::text) public.gin_trgm_ops);


--
-- Name: ix_products_canonical; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_products_canonical ON public.products USING btree (canonical_product_id);


--
-- Name: ix_products_family; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_products_family ON public.products USING btree (family_slug);


--
-- Name: ix_products_norm_barcode; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_products_norm_barcode ON public.products USING btree (normalised_barcode);


--
-- Name: ix_products_search_trgm; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_products_search_trgm ON public.products USING gin (lower((((((brand)::text || ' '::text) || (name)::text) || ' '::text) || (COALESCE(variant, ''::character varying))::text)) public.gin_trgm_ops);


--
-- Name: ix_products_status; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_products_status ON public.products USING btree (status);


--
-- Name: ix_stores_lat_lon; Type: INDEX; Schema: public; Owner: drinkwatch
--

CREATE INDEX ix_stores_lat_lon ON public.stores USING btree (lat, lon);


--
-- Name: barcodes barcodes_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: caffeine_entries caffeine_entries_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.caffeine_entries
    ADD CONSTRAINT caffeine_entries_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: caffeine_entries caffeine_entries_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.caffeine_entries
    ADD CONSTRAINT caffeine_entries_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: listings listings_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.chains(id) ON DELETE CASCADE;


--
-- Name: listings listings_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: observation_votes observation_votes_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observation_votes
    ADD CONSTRAINT observation_votes_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: observation_votes observation_votes_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observation_votes
    ADD CONSTRAINT observation_votes_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES public.observations(id) ON DELETE CASCADE;


--
-- Name: observations observations_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.chains(id) ON DELETE CASCADE;


--
-- Name: observations observations_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: observations observations_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: observations observations_photo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_photo_id_fkey FOREIGN KEY (photo_id) REFERENCES public.photos(id) ON DELETE SET NULL;


--
-- Name: observations observations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: observations observations_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: photos photos_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT photos_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: price_alerts price_alerts_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_alerts
    ADD CONSTRAINT price_alerts_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: price_alerts price_alerts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_alerts
    ADD CONSTRAINT price_alerts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: price_alerts price_alerts_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_alerts
    ADD CONSTRAINT price_alerts_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: price_daily price_daily_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_daily
    ADD CONSTRAINT price_daily_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.chains(id) ON DELETE CASCADE;


--
-- Name: price_daily price_daily_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.price_daily
    ADD CONSTRAINT price_daily_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_canonical_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_canonical_product_id_fkey FOREIGN KEY (canonical_product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: reports reports_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: reports reports_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES public.observations(id) ON DELETE CASCADE;


--
-- Name: scrape_runs scrape_runs_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.scrape_runs
    ADD CONSTRAINT scrape_runs_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE SET NULL;


--
-- Name: stores stores_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: drinkwatch
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.chains(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict YPRpNgUqCDmiRvDcuC5twFSOhBddap89hacxEJA28jGMvkDkiAayp6gUBVhkuzK

